
#include "gausstables.h"

#include "defines.h"

#include "parms.h"
// #include "state.h"
// #include "md.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static
void Gauss00DH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB/rij*exp(-kappa*rij);
  // Force divided by rij
  *F_r=(*U)*(kappa+1/rij)/rij;
}


static
void Gauss00DHwR(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB*(1/rij-0.5*kappa)*exp(-kappa*rij);
  // Force divided by rij
  *F_r=kT*lB*(1/rij/rij+kappa/rij-0.5*kappa*kappa)*exp(-kappa*rij)/rij;
}


static
void GaussDH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  double Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm;
  Ap=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma+kappa*rij);
  Am=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma-kappa*rij);
  dAp=(-1.0/rij+kappa)*Ap;
  dAm=(-1.0/rij-kappa)*Am;
  bp=(rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  bm=(-rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/sigma;
  dBm=sqrt(2/M_PI)*exp(-bm*bm)/sigma;
  *U=-Ap*Bp+Am*Bm;
  // Force divided by rij
  *F_r=(Ap*dBp+dAp*Bp-Am*dBm-dAm*Bm)/rij;
}


static
void GaussDH0(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB*(-kappa*exp(0.5*kappa*kappa*sigma*sigma)*(1-erf(kappa*sigma/sqrt(2)))+sqrt(2/M_PI)/sigma);
  *F_r=0;
}


#ifdef POLARIZE
static
void gGaussDH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  double Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm,P,dP;
  double ddAp,ddBp,ddAm,ddBm,ddP;
  // double dddAp,dddBp,dddAm,dddBm,dddP;
  Ap=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma+kappa*rij);
  Am=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma-kappa*rij);
  dAp=(-1.0/rij+kappa)*Ap;
  dAm=(-1.0/rij-kappa)*Am;
  ddAp=(-1.0/rij+kappa)*dAp+(1.0/(rij*rij))*Ap;
  ddAm=(-1.0/rij-kappa)*dAm+(1.0/(rij*rij))*Am;
  // dddAp=(-1.0/rij+kappa)*ddAp+(2.0/(rij*rij))*dAp+(-2.0/(rij*rij*rij))*Am;
  // dddAm=(-1.0/rij-kappa)*ddAm+(2.0/(rij*rij))*dAm+(-2.0/(rij*rij*rij))*Am;

  bp=(rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  bm=(-rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/sigma;
  dBm=sqrt(2/M_PI)*exp(-bm*bm)/sigma;
  ddBp=(-2.0*bp/(sigma*sqrt(2)))*dBp;
  ddBm=(2.0*bm/(sigma*sqrt(2)))*dBm;
  // dddBp=(-2.0*bp/(sigma*sqrt(2)))*ddBp-(1.0/(sigma*sigma))*dBp;
  // dddBm=(2.0*bm/(sigma*sqrt(2)))*ddBm-(1.0/(sigma*sigma))*dBm;
  
  P=-Ap*Bp+Am*Bm;
  dP=-(Ap*dBp+dAp*Bp)+(Am*dBm+dAm*Bm);
  ddP=-(Ap*ddBp+2.0*dAp*dBp+ddAp*Bp)+(Am*ddBm+2.0*dAm*dBm+ddAm*Bm);
  // dddP=-(Ap*dddBp+3.0*dAp*ddBp+3.0*ddAp*dBp+dddAp*Bp)+(Am*dddBm+3.0*dAm*ddBm+3.0*ddAm*dBm+dddAm*Bm);
  // *U=P;
  *U=dP/rij;
  // *U=ddP/(rij*rij)-dP/(rij*rij*rij);
  // Force divided by rij
  // *F_r=-dP/rij
  *F_r=-ddP/(rij*rij)+dP/(rij*rij*rij);
  // *F_r=-dddP/(rij*rij*rij)+3.0*ddP/(rij*rij*rij*rij)-3.0*dP/(rij*rij*rij*rij*rij);
}


static
void gGaussDH0(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  // *U=kT*lB*(-kappa*exp(0.5*kappa*kappa*sigma*sigma)*(1-erf(kappa*sigma/sqrt(2)))+sqrt(2/M_PI)/sigma);
  *U=-(1.0/3.0)*kT*lB*(kappa*kappa*kappa*exp(0.5*kappa*kappa*sigma*sigma)*(1-erf(kappa*sigma/sqrt(2)))+(sqrt(2/M_PI)/sigma)*(1/(sigma*sigma)-kappa*kappa));
  *F_r=0;
}


static
void ggGaussDH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  double Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm,P,dP;
  double ddAp,ddBp,ddAm,ddBm,ddP;
  double dddAp,dddBp,dddAm,dddBm,dddP;
  Ap=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma+kappa*rij);
  Am=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma-kappa*rij);
  dAp=(-1.0/rij+kappa)*Ap;
  dAm=(-1.0/rij-kappa)*Am;
  ddAp=(-1.0/rij+kappa)*dAp+(1.0/(rij*rij))*Ap;
  ddAm=(-1.0/rij-kappa)*dAm+(1.0/(rij*rij))*Am;
  dddAp=(-1.0/rij+kappa)*ddAp+(2.0/(rij*rij))*dAp+(-2.0/(rij*rij*rij))*Am;
  dddAm=(-1.0/rij-kappa)*ddAm+(2.0/(rij*rij))*dAm+(-2.0/(rij*rij*rij))*Am;

  bp=(rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  bm=(-rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/sigma;
  dBm=sqrt(2/M_PI)*exp(-bm*bm)/sigma;
  ddBp=(-2.0*bp/(sigma*sqrt(2)))*dBp;
  ddBm=(2.0*bm/(sigma*sqrt(2)))*dBm;
  dddBp=(-2.0*bp/(sigma*sqrt(2)))*ddBp-(1.0/(sigma*sigma))*dBp;
  dddBm=(2.0*bm/(sigma*sqrt(2)))*ddBm-(1.0/(sigma*sigma))*dBm;
  
  P=-Ap*Bp+Am*Bm;
  dP=-(Ap*dBp+dAp*Bp)+(Am*dBm+dAm*Bm);
  ddP=-(Ap*ddBp+2.0*dAp*dBp+ddAp*Bp)+(Am*ddBm+2.0*dAm*dBm+ddAm*Bm);
  dddP=-(Ap*dddBp+3.0*dAp*ddBp+3.0*ddAp*dBp+dddAp*Bp)+(Am*dddBm+3.0*dAm*ddBm+3.0*ddAm*dBm+dddAm*Bm);
  // *U=P;
  // *U=dP/rij;
  *U=ddP/(rij*rij)-dP/(rij*rij*rij);
  // Force divided by rij
  // *F_r=-dP/rij
  // *F_r=-ddP/(rij*rij)+dP/(rij*rij*rij);
  *F_r=-dddP/(rij*rij*rij)+3.0*ddP/(rij*rij*rij*rij)-3.0*dP/(rij*rij*rij*rij*rij);
}
#endif


static
void GaussDHwR(double kT,double lB,double k,double s,double rij,double* U,double* F_r)
{
  double PF,ap,am,Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm;
  PF=-0.5*kT*lB;
  ap=PF*exp(0.5*k*k*s*s+k*rij);
  am=PF*exp(0.5*k*k*s*s-k*rij);
  Ap=(0.5*k+(1.0+0.5*k*k*s*s)/rij)*ap;
  Am=(0.5*k-(1.0+0.5*k*k*s*s)/rij)*am;
  dAp= (-0.5*k*k-(1.0+0.5*k*k*s*s)*k/rij-(1.0+0.5*k*k*s*s)/rij/rij)*ap;
  dAm=-(-0.5*k*k+(1.0+0.5*k*k*s*s)*k/rij-(1.0+0.5*k*k*s*s)/rij/rij)*am;
  bp=( rij+k*s*s)/(s*sqrt(2));
  bm=(-rij+k*s*s)/(s*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/s;
  dBm= sqrt(2/M_PI)*exp(-bm*bm)/s;
  *U=Ap*Bp+Am*Bm;
  // Force divided by rij
  *F_r=-(Ap*dBp+dAp*Bp+Am*dBm+dAm*Bm)/rij;
}


static
void GaussDHwR0(double kT,double lB,double k,double s,double* U,double* F_r)
{
  *U=kT*lB*((1.0+0.5*k*k*s*s)*sqrt(2/M_PI)/s
    -k*(1.5+0.5*k*k*s*s)*exp(0.5*k*k*s*s)*(1-erf(k*s/sqrt(2))));
  *F_r=0;
}


static
void Gaussian(double kT,double lB,double k,double s,double rij,double* U,double* F_r)
{
  *U=1/(M_SQRT8PI3*s*s*s)*exp(-rij*rij/(2*s*s));
  *F_r=(*U)/(s*s);
}


static
void Lazy0(double kT,double lB,double k,double s,double rij,double* U,double* F_r)
{
  fprintf(stderr,"Warning, 0 point of an electrostatic force table not set\n");
  *U=0;
  *F_r=0;
}


// void tables_interp(struct_tables* tabs,struct_nldata* data,struct_md* md)
int tables_interp(struct_tables* tabs,struct_nldata* data)
{
  double hinv=tabs->hinv;
  int i,t; // index, type
  double x,x2,x3;
  struct_point *p; // point

  i=((int) (data->r*hinv));
  if ( i >= tabs->N ) {
    return 1;
    // fprintf(stderr,"Fatal error: neighbor interaction distance is longer than table cutoff\n");
    // if (md->state->abortflag==0) {
    //   md->state->abortflag=1;
    //   printgroframe(md,"crash");
    // }
    // omp4.0 - not available: #pragma omp cancel parallel
    // #ifndef NOMPI
    // MPI_Finalize();
    // #endif
    // exit(0);
  }
  p=tabs->point[i];
  x=data->r*hinv-i;
  x2=x*x;
  x3=x2*x;

  for (t=0; t<eT_MAX; t++) {
    data->Eij[t]=p[t].A0+x*p[t].A1+x2*p[t].A2+x3*p[t].A3;
    data->Frij[t]=(p[t].A1+2*x*p[t].A2+3*x2*p[t].A3)*(-hinv/data->r);
  }

  return 0;
}


struct_tables* alloc_tables(double cut,struct_parms* parms)
{
  struct_tables *tables;
  double kT=parms->kT;
  double lB=parms->lB;
  double kappa=parms->kappa;
  double hinv=1000.0; // CONST
  int N=((int) (hinv*(cut+TABEXT)))+2;
  double r,E,F,E1,F1;
  int i,j;

  potfunc f0[eT_MAX]={Gauss00DH,GaussDH0,GaussDH0,GaussDH0,GaussDH0,GaussDH0,Gaussian,Gaussian
#ifdef POLARIZE
    ,gGaussDH0,gGaussDH0,gGaussDH0,Lazy0
#endif
};
  potfunc f[eT_MAX]={Gauss00DH,GaussDH,GaussDH,GaussDH,GaussDH,GaussDH,Gaussian,Gaussian
#ifdef POLARIZE
    ,gGaussDH,gGaussDH,gGaussDH,ggGaussDH
#endif
};
  double s[eT_MAX]={parms->gauss_00,parms->gauss_01,parms->gauss_02,parms->gauss_11,
    parms->gauss_12,parms->gauss_22,parms->gauss_01,parms->gauss_02
#ifdef POLARIZE
    ,parms->gauss_01,parms->gauss_11,parms->gauss_12,parms->gauss_11
#endif
};
  double s1=parms->gauss_01;
  double fac[eT_MAX]={1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0
#ifdef POLARIZE
    , 1.0, 1.0, 1.0, 1.0
    // , s1*s1, s1*s1, s1*s1, s1*s1*s1*s1
#endif
};

  tables=malloc(sizeof(struct_tables));
  tables->hinv=hinv;
  tables->N=N;
  tables->point=calloc(N,sizeof(struct_point[eT_MAX]));

  for (i=0; i<eT_MAX; i++) {
    f0[i](kT,lB,kappa,s[i],0,&E1,&F1);
    E1*=fac[i];
    F1*=0;
    for (j=0; j<N; j++) {
      r=(j+1)/hinv;
      E=E1;
      F=F1;
      f[i](kT,lB,kappa,s[i],r,&E1,&F1);
      E1*=fac[i];
      F1*=(fac[i]*r);
      tables->point[j][i].A0=E;
      tables->point[j][i].A1=-F/hinv;
      tables->point[j][i].A2=3*(E1-E+F/hinv)+(F1-F)/hinv;
      tables->point[j][i].A3=-2*(E1-E+F/hinv)-(F1-F)/hinv;
    }
  }

  return tables;
}


void free_tables(struct_tables* tables)
{
  free(tables->point);
  free(tables);
}

