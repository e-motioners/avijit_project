#ifndef MD_RNA_IONS_CHECKPT_H
#define MD_RNA_IONS_CHECKPT_H

#include "md.h"

void printcheckpoint(struct_md *md);

int readcheckpoint(struct_md *md);

#endif

