#ifndef MD_RNA_IONS_PRINT_H
#define MD_RNA_IONS_PRINT_H

#include "version.h"
#include "md.h"
#include "times.h"

void printgroframe(struct_md* md,char* tag);

void printheader(struct_md* md);

// void printmoreheader(struct_md *md);

void printoutput(struct_md* md);

void printsummary(struct_md* md,gmx_cycles_t start);

#endif
