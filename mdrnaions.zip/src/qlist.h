#ifndef MD_RNA_IONS_QLIST_H
#define MD_RNA_IONS_QLIST_H

#include "state.h"

struct struct_collate;

typedef struct struct_qlist
{
  int *qlist;
  int nqlist;
  int nqlist_th;
  double *x;
  double *theta;
  double *theta_cl;
  double *eta;
  double *eta_cl;
#ifdef POLARIZE
  double *polar;
  double *polar_cl;
#endif
  double *bP;
  struct struct_collate *condens_tk;
  struct struct_collate *condens_tcl;
  struct struct_collate *condens_ek;
  struct struct_collate *condens_ecl;
#ifdef POLARIZE
  struct struct_collate *condens_pk;
  struct struct_collate *condens_pcl;
  struct struct_collate *condens_vpk;
  struct struct_collate *condens_vpcl;
#endif
  double *dens_tk;
  double *dens_tcl;
  double *dens_ek;
  double *dens_ecl;
  struct struct_collate *pot_t;
  struct struct_collate *pot_e;
  struct struct_collate *V1eff_inv;
  struct struct_collate *V2eff_inv;
#ifdef POLARIZE
  double *polar_0;
  double *polar_cl_0;
  double *k_polar;
  double *k_polar_cl;
#endif
  double *dGsoftdt_tk;
  double *dGsoftdt_tcl;
  double *dGsoftde_ek;
  double *dGsoftde_ecl;
  double *G;
  double *dGdtk;
  double *dGdtcl;
  double *dGdek;
  double *dGdecl;
  double *dGdtpot;
  double *dGdepot;
  double *dGdV1;
  double *dGdV2;
#ifdef POLARIZE
  double *dGdpk;
  double *dGdpcl;
  double *gGdvpk;
  double *gGdvpcl;
#endif
} struct_qlist;

struct_qlist* alloc_qlist(struct_state* state);

void update_qlist(struct_qlist* qlist,struct_state* state);

void free_qlist(struct_qlist* qlist);

#endif

