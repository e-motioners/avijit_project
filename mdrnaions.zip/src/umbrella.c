
#include "umbrella.h"

#include "defines.h"

#include "vec.h"
#include "md.h"
#include "state.h"
#include "atoms.h"
#include "collate.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static double umbrella_switch_tgt( const struct_umbrella* const umbrella,
                                   int step )
  {
  double efac = exp( -step / umbrella->Q_steps ) ;
  double tgt  = umbrella->Q_ref * ( 1-efac ) + umbrella->Q_start * efac ;
  return tgt ;
  }

static double umbrella_potential( const struct_umbrella* const umbrella,
                                  double tgt )
  {
  return - ( umbrella->Q_act->master[0] - tgt ) * umbrella->k_umb ;
  }

struct_umbrella* alloc_umbrella()
  {
  int i, ai, aj ;
  double r_N, fac ;
  FILE *umbrella_file = NULL ;
  umbrella_file = fopen("umbrella_params","r") ;

  struct_umbrella* umbrella = NULL ;

  if ( umbrella_file )
    {
    umbrella = malloc(sizeof(struct_umbrella)) ;
    fscanf(umbrella_file,"%lf %lf %lf %lf %lf %d %lf",  
           &umbrella->Q_ref,
           &umbrella->k_umb,
           &umbrella->kappa,
           &umbrella->cut,
           &umbrella->Q_start,
           &umbrella->Q_nc,
           &umbrella->Q_steps ) ;
    umbrella->first=calloc(umbrella->Q_nc,sizeof(int));
    umbrella->second=calloc(umbrella->Q_nc,sizeof(int));
    umbrella->r_native=calloc(umbrella->Q_nc,sizeof(double));
    umbrella->factor=calloc(umbrella->Q_nc,sizeof(double));
    for (i=0;i<umbrella->Q_nc;++i)
      {
      fscanf( umbrella_file, "%d %d %lf %lf", &ai, &aj, &r_N, &fac ) ;
      umbrella->first[i] = ai - 1 ;
      umbrella->second[i] = aj - 1 ;
      umbrella->r_native[i] = r_N ;
      umbrella->factor[i] = fac ;
      }
    fclose(umbrella_file); 
    
  
  umbrella->Q_act=alloc_collate(1,0,1);
    }

  return umbrella ;
  }

void free_umbrella(struct_umbrella* umbrella)
  {
  if (umbrella) {
  free(umbrella->factor) ;
  free(umbrella->r_native) ;
  free(umbrella->second) ;
  free(umbrella->first) ;

  free(umbrella->Q_act);

  free(umbrella) ;
  }
}

void calc_umbrella( struct_md* const md )
  {
  if(md->state->umbrella) {

  struct_umbrella* const umbrella = md->state->umbrella ;
  double kappa = umbrella->kappa ;
  double cut = umbrella->cut ;
  double *x = md->state->x ; 

  int i, ii, jj, imin, imax ;

  double r_N, fac ;
  vec dr ;
  double r ;
  double arg ;
  double Q_act = 0 ;

  int ID,NID ;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads(); 
  imin=(umbrella->Q_nc * ID)/NID;
  imax=(umbrella->Q_nc * (ID+1))/NID;

  for (i=imin;i<imax;++i)
    {
    ii = umbrella->first[i] ;
    jj = umbrella->second[i] ;
    r_N = umbrella->r_native[i] ;
    fac = umbrella->factor[i] ;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr); 
    arg = kappa * ( r - (1.0+cut) * r_N ) ; // Ryan had issues with factor 1.2
    Q_act += 0.5 * ( 1-tanh( arg ) ) * fac ;
    }

  md->state->umbrella->Q_act->local[ID][0] = Q_act ;

  #pragma omp barrier
  sumlocal_collate(umbrella->Q_act,ID) ;
  #pragma omp barrier
  } // if umbrella
  }

// need a barrier between these two

void apply_umbrella( struct_md* const md )
  {
  if (md->state->umbrella) {

  struct_umbrella* const umbrella = md->state->umbrella ;
  double kappa = umbrella->kappa ;
  double cut = umbrella->cut ;
  double *x = md->state->x ;
  double *f ;  

  int i, ii, jj, imin, imax ;
  
  double r_N, fac ;
  vec dr ;
  double r ;
  double tgt, potl ;
  double arg, cosh1, Qderiv, iforce ;

  int ID,NID ;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(umbrella->Q_nc * ID)/NID;
  imax=(umbrella->Q_nc * (ID+1))/NID;

  f = md->state->atoms->f->local[ID] ;

  tgt = umbrella_switch_tgt( umbrella, md->state->step ) ;
  potl = umbrella_potential( umbrella, tgt ) ;

  for (i=imin;i<imax;++i)
    {
    ii = umbrella->first[i] ;
    jj = umbrella->second[i] ;
    r_N = umbrella->r_native[i] ;
    fac = umbrella->factor[i] ;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    arg = kappa * ( r - (1.0+cut) * r_N ) ;
    cosh1 = cosh( arg ) ;
    Qderiv = -0.5 * fac * kappa / r / (cosh1 * cosh1) ;
    iforce = potl* Qderiv ;
    vec_scaleinc(f+DIM3*ii,  iforce, dr);
    vec_scaleinc(f+DIM3*jj, -iforce, dr);
    }
    
  } // if umbrella
  }


void getforce_umbrella(struct_md* md)
{
  calc_umbrella(md);
  apply_umbrella(md);
}


void start_umbrella( struct_md* const md )
  {
  if (md->state->umbrella) {
  int ID = omp_get_thread_num();
  struct_umbrella* const umbrella = md->state->umbrella ;
  calc_umbrella(md);
  #pragma omp master
  umbrella->Q_start = umbrella->Q_act->master[0] ;
  }
  }

