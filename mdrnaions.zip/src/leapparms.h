#ifndef MD_RNA_IONS_LEAPPARMS_H
#define MD_RNA_IONS_LEAPPARMS_H

typedef struct struct_leapparms
{
  double dt;
  double gamma;
  double kT;
  double mDiff;
  double SigmaVsVs;
  double XsVsCoeff;
  double CondSigmaXsXs;
  double SigmaVrVr;
  double XrVrCoeff;
  double CondSigmaXrXr;
  double vhalf_vscale;
  double vhalf_ascale;
  double vhalf_Vsscale;
  double v_vscale;
  double v_ascale;
  double v_Vsscale;
  double x_vscale;
  double x_Xrscale;
} struct_leapparms;

struct_leapparms* alloc_leapparms(double dt,double gamma,double kT);

void free_leapparms(struct_leapparms* leapparms) ;

#endif

