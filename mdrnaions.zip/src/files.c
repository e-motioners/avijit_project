
#include "files.h"

#include "defines.h"
#include "xdr/xdrfile.h"

#include <stdlib.h>

struct_files* alloc_files(void)
{
  struct_files *files;
  int i;

  files=malloc(sizeof(struct_files));
  files->N=eF_MAX;
  files->fps=calloc(files->N,sizeof(FILE*));
  for (i=0; i<files->N; i++) {
    files->fps[i]=NULL;
  }
  files->xtc=NULL;

  return files;
}


void free_files(struct_files* files)
{
  int i;
  for (i=0; i<files->N; i++) {
    if (files->fps[i] != NULL) {
      // if (i==eF_xtc) {
      //   xdrfile_close((XDRFILE*) files->fps[i]);
      // } else {
      fclose(files->fps[i]);
      // }
    }
  }
  if (files->xtc != NULL) {
    xdrfile_close(files->xtc);
  }
  free(files);
}

