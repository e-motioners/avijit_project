#include "umbrella.h"

#include "defines.h"

#include "vec.h"
#include "md.h"
#include "state.h"
#include "parms.h"
#include "topol.h"
#include "atoms.h"
#include "collate.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static __inline__ gmx_cycles_t gmx_cycles_read(void)
{
    unsigned long low, high1, high2;
    do
    {
        __asm__ __volatile__ ("mftbu %0" : "=r" (high1) : );
        __asm__ __volatile__ ("mftb %0" : "=r" (low) : );
        __asm__ __volatile__ ("mftbu %0" : "=r" (high2) : );
    }
    while (high1 != high2);

    return (((gmx_cycles_t)high2) << 32) | (gmx_cycles_t)low;
}



static double umbrella_switch_tgt( const struct_umbrella* const umbrella,
                                   int step )
{
  double efac = exp( -step / umbrella->Q_steps ) ;
  double tgt  = umbrella->Q_ref * ( 1-efac ) + umbrella->Q_start * efac ;
  return tgt ;
}

struct_umbrella* alloc_umbrella(struct_md *md)
  {
  int i;
  struct_umbrella *umbrella = NULL;
  FILE *umbrella_file = NULL;
  umbrella_file = fopen("umbrella_params","r");

  if ( umbrella_file ) {
    umbrella = malloc(sizeof(struct_umbrella));
    fscanf(umbrella_file,"freq_out %d\n",&umbrella->freq_out);
    for (i=0; i<=md->parms->id; i++) {
      fscanf(umbrella_file,"%lf %lf %lf %lf",
             &umbrella->k_umb,
             &umbrella->Q_ref,
             &umbrella->Q_start,
             &umbrella->Q_steps);

      umbrella->Q_act=alloc_collate(1,0,1);
    }
    fclose(umbrella_file);
    
  }

  return umbrella;
}

void free_umbrella(struct_umbrella* umbrella)
{
  if (umbrella) {
    free_collate(umbrella->Q_act);
    free(umbrella);
  }
}


void getforce_pair8(struct_md* md)
{
 if (md->parms->umbrella) {
  int i,ii,jj,imin,imax;
  struct_pair8parms *pair8parms=md->parms->pair8parms;
  double A,mu,sig;
  double elon, elonsq, twosigsq, F;
  double k_Q, Q_0, F_Q;
  double *Q_local, *Q_global;
  double r2, r;
  vec dr;
  double fbond;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair8 * ID)/NID;
  imax=(md->parms->N_pair8 * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  Q_local=resetlocal_collate(md->parms->umbrella->Q_act,ID);

  for (i=imin; i<imax; i++) {
    ii=pair8parms[i].i;
    jj=pair8parms[i].j;
    A=pair8parms[i].amp;
    mu=pair8parms[i].mu;
    sig=pair8parms[i].sigma;

    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r2=vec_mag2(dr);
    r=sqrt(r2);

    if (r<mu) {
      *Q_local+=A;
    } else {
      elon=r-mu;
      elonsq=elon*elon;
      twosigsq=2*sig*sig;
      F=exp(-elonsq/twosigsq);
      *Q_local+=A*F;
    }
  }

  #pragma omp barrier
  Q_global=sumlocal_collate(md->parms->umbrella->Q_act,ID);
  #pragma omp barrier
  k_Q=md->parms->umbrella->k_umb;
  Q_0=umbrella_switch_tgt(md->parms->umbrella,md->state->step);

  F_Q=-k_Q*(*Q_global-Q_0);
  #pragma omp master
  {
    md->parms->umbrella->EQ=0.5*k_Q*(*Q_global-Q_0)*(*Q_global-Q_0);
    md->state->Gts->local[ID][eE_pair8]=0.5*k_Q*(*Q_global-Q_0)*(*Q_global-Q_0);
  }

  for (i=imin; i<imax; i++) {
    ii=pair8parms[i].i;
    jj=pair8parms[i].j;
    A=pair8parms[i].amp;
    mu=pair8parms[i].mu;
    sig=pair8parms[i].sigma;

    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r2=vec_mag2(dr);
    r=sqrt(r2);

    if (r<mu) {
      fbond=0; // Force is 0
    } else {
      elon=r-mu;
      elonsq=elon*elon;
      twosigsq=2*sig*sig;
      F=exp(-elonsq/twosigsq);
      fbond=F_Q*(-2.0*elon/twosigsq)*A*F;
    }

    fbond/=r;

    vec_scaleinc(f+DIM3*ii, fbond,dr);
    vec_scaleinc(f+DIM3*jj,-fbond,dr);
  }

  // md->state->Gt->local[ID][0]+=Gt;
  #pragma omp master
    md->times->force_pair+=(gmx_cycles_read()-start);
 }
}

