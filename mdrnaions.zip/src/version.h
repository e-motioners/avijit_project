#ifndef MD_RNA_IONS_VERSION_H
#define MD_RNA_IONS_VERSION_H

#include <stdio.h>

void printversion(FILE* fp);

#endif
