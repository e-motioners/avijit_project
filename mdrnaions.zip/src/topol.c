
#include "topol.h"

#include "defines.h"

#include "md.h"
#include "parms.h"
#include "state.h"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>


static
void checkatom(int i,int N,char* line)
{
  if (i-1<0 || i-1>=N) {
    fprintf(stderr,"Fatal error: atom %d in top file does not exist\n%s\n",i,line);
    exit(0);
  }
}


static
void topseek(char directive[],FILE *fp)
{
  char s[MAXLENGTH];
  if (fp==NULL) {
    fprintf(stderr,"Fatal error: top file does not exist\n");
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }
  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if ((strcmp(s,directive) == 0) || (strcmp(s+1,directive) == 0)) {
      break;
    }
  }
}


static
int topbond(int bSave,int Natom,struct_bondparms *bondparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j;
  double k0,r0;
  int type;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg",&i,&j,&type,&r0,&k0)>=3) {
      if (bSave) {
        if (type==1) {
          // great
        } else if (type==5) {
          k0=0;
          r0=0;
        } else {
          fprintf(stderr,"Warning, unrecognized bond type %d\n",type);
        }
        checkatom(i,Natom,s);
        checkatom(j,Natom,s);
        bondparms[N].i=i-1;
        bondparms[N].j=j-1;
        bondparms[N].k0=k0;
        bondparms[N].r0=r0;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


static
struct_bondparms* alloc_bondparms(int *N,int Natom,char fnm[])
{
  struct_bondparms *bondparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  *N=topbond(0,Natom,NULL,fp);
  fclose(fp);

  bondparms=calloc(*N,sizeof(struct_bondparms));

  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  *N=topbond(1,Natom,bondparms,fp);
  fclose(fp);

  return bondparms;
}


static
int topangle(int bSave,int Natom,struct_angleparms *angleparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,k;
  double k0,t0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d 1 %lg %lg",&i,&j,&k,&t0,&k0)==5) {
      if (bSave) {
        checkatom(i,Natom,s);
        checkatom(j,Natom,s);
        checkatom(k,Natom,s);
        angleparms[N].i=i-1;
        angleparms[N].j=j-1;
        angleparms[N].k=k-1;
        angleparms[N].k0=k0;
        angleparms[N].t0=(M_PI/180)*t0;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


static
struct_angleparms* alloc_angleparms(int *N,int Natom,char fnm[])
{
  struct_angleparms *angleparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ angles ]\n",fp);
  *N=topangle(0,Natom,NULL,fp);
  fclose(fp);

  angleparms=calloc(*N,sizeof(struct_angleparms));

  fp=fopen(fnm,"r");
  topseek("[ angles ]\n",fp);
  *N=topangle(1,Natom,angleparms,fp);
  fclose(fp);

  return angleparms;
}


static
int topdih(int bSave,int Natom,struct_dihparms *dihparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,k,l,ty,n;
  int ip=0;
  int jp=0;
  int kp=0;
  int lp=0;
  double k0,p0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %d %d %lg %lg %d",
                         &i,&j,&k,&l,&ty,&p0,&k0,&n)>=7) {
      if (ty==1) {
       // if (i==ip && j==jp && k==kp && l==lp && dihparms[N-1].n2==0) {
       if (i==ip && j==jp && k==kp && l==lp) {
        if (bSave) {
          dihparms[N-1].k02=k0;
          dihparms[N-1].p02=(M_PI/180)*p0;
          dihparms[N-1].n2=(double) n;
        }
        ip=0; jp=0; kp=0; lp=0; // Reset the previous indices so a third won't be added
        // No N++;
       } else {
        if (bSave) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          checkatom(k,Natom,s);
          checkatom(l,Natom,s);
          dihparms[N].i=i-1;
          dihparms[N].j=j-1;
          dihparms[N].k=k-1;
          dihparms[N].l=l-1;
          dihparms[N].k0=k0;
          dihparms[N].p0=(M_PI/180)*p0;
          dihparms[N].n=(double) n;
          dihparms[N].n2=0;
        }
        ip=i; jp=j; kp=k; lp=l; // Set previous indices so a second can be added
        N++;
       }
      } else if (ty==2) {
        if (bSave) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          checkatom(k,Natom,s);
          checkatom(l,Natom,s);
          dihparms[N].i=i-1;
          dihparms[N].j=j-1;
          dihparms[N].k=k-1;
          dihparms[N].l=l-1;
          dihparms[N].k0=k0;
          dihparms[N].p0=(M_PI/180)*p0;
          dihparms[N].n=0;
          dihparms[N].n2=0;
        }
        ip=0; jp=0; kp=0; lp=0; // Reset previous indices
        N++;
      } else {
        fprintf(stderr,"Unrecognized Dihedral Type\n");
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_dihparms* alloc_dihparms(int *N,int Natom,char fnm[])
{
  struct_dihparms *dihparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ dihedrals ]\n",fp);
  *N=topdih(0,Natom,NULL,fp);
  fclose(fp);

  dihparms=calloc(*N,sizeof(struct_dihparms));

  fp=fopen(fnm,"r");
  topseek("[ dihedrals ]\n",fp);
  *N=topdih(1,Natom,dihparms,fp);
  fclose(fp);

  return dihparms;
}


static
int toppair1(int bSave,int Natom,struct_pair1parms *pair1parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double C6,C12;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg",&i,&j,&ty,&C6,&C12)>=5) {
      if (bSave) {
        if (ty==1) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          pair1parms[N].i=i-1;
          pair1parms[N].j=j-1;
          pair1parms[N].C6=C6;
          pair1parms[N].C12=C12;
        } else if (ty!=5 && ty!=6 && ty!=7 && ty!=8) {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      if (ty==1) {
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_pair1parms* alloc_pair1parms(int *N,int Natom,char fnm[])
{
  struct_pair1parms *pair1parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair1(0,Natom,NULL,fp);
  fclose(fp);

  pair1parms=calloc(*N,sizeof(struct_pair1parms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair1(1,Natom,pair1parms,fp);
  fclose(fp);

  return pair1parms;
}


// bare Gaussian potential:
// V_ij = -A exp( - ( r - mu )^2 / ( 2 sigma^2 ) )
// selected in the [ pairs ] section;
// ; i j ftype A mu sigma
// with ftype = 5
// note that the amplitude of the Gaussian is -A.
// This can be used with a separate repulsion term or without it.
static
int toppair5(int bSave,int Natom,struct_pair5parms *pair5parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double eps,r0,sigma,eps12;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg %lg",&i,&j,&ty,&eps,&r0,&sigma)>=5) {
      if (bSave) {
        if (ty==5) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          pair5parms[N].i=i-1;
          pair5parms[N].j=j-1;
          pair5parms[N].eps=eps;
          pair5parms[N].r0=r0;
          pair5parms[N].sigma=sigma;
        } else if (ty!=1 && ty!=6 && ty!=7 && ty!=8) {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      if (ty==5) {
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_pair5parms* alloc_pair5parms(int *N,int Natom,char fnm[])
{
  struct_pair5parms *pair5parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair5(0,Natom,NULL,fp);
  fclose(fp);

  pair5parms=calloc(*N,sizeof(struct_pair5parms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair5(1,Natom,pair5parms,fp);
  fclose(fp);

  return pair5parms;
}


static
int toppair6(int bSave,int Natom,struct_pair6parms *pair6parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double eps,r0,sigma,eps12;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg %lg %lg",&i,&j,&ty,&eps,&r0,&sigma,&eps12)>=5) {
      if (bSave) {
        if (ty==6) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          pair6parms[N].i=i-1;
          pair6parms[N].j=j-1;
          pair6parms[N].eps=eps;
          pair6parms[N].r0=r0;
          pair6parms[N].sigma=sigma;
          pair6parms[N].eps12=eps12;
        } else if (ty!=1 && ty!=5 && ty!=7 && ty!=8) {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      if (ty==6) {
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_pair6parms* alloc_pair6parms(int *N,int Natom,char fnm[])
{
  struct_pair6parms *pair6parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair6(0,Natom,NULL,fp);
  fclose(fp);

  pair6parms=calloc(*N,sizeof(struct_pair6parms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair6(1,Natom,pair6parms,fp);
  fclose(fp);

  return pair6parms;
}


static
int toppair7(int bSave,int Natom,struct_pair7parms *pair7parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double eps,r01,sigma1,r02,sigma2,eps12;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg %lg %lg %lg %lg", \
                      &i,&j,&ty,&eps,&r01,&sigma1,&r02,&sigma2,&eps12)>=5) {
      if (bSave) {
        if (ty==7) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          pair7parms[N].i=i-1;
          pair7parms[N].j=j-1;
          pair7parms[N].eps=eps;
          pair7parms[N].r01=r01;
          pair7parms[N].sigma1=sigma1;
          pair7parms[N].r02=r02;
          pair7parms[N].sigma2=sigma2;
          pair7parms[N].eps12=eps12;
        } else if (ty!=1 && ty!=5 && ty!=6 && ty!=8) {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      if (ty==7) {
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_pair7parms* alloc_pair7parms(int *N,int Natom,char fnm[])
{
  struct_pair7parms *pair7parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair7(0,Natom,NULL,fp);
  fclose(fp);

  pair7parms=calloc(*N,sizeof(struct_pair7parms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair7(1,Natom,pair7parms,fp);
  fclose(fp);

  return pair7parms;
}


static
int toppair8(int bSave,int Natom,struct_pair8parms *pair8parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double amp,mu,sigma;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg %lg", \
                      &i,&j,&ty,&amp,&mu,&sigma)>=5) {
      if (bSave) {
        if (ty==8) {
          checkatom(i,Natom,s);
          checkatom(j,Natom,s);
          pair8parms[N].i=i-1;
          pair8parms[N].j=j-1;
          pair8parms[N].amp=amp;
          pair8parms[N].mu=mu;
          pair8parms[N].sigma=sigma;
        } else if (ty!=1 && ty!=5 && ty!=6 && ty!=7) {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      if (ty==8) {
        N++;
      }
    } else {
      break;
    }
  }
  return N;
}


static
struct_pair8parms* alloc_pair8parms(int *N,int Natom,char fnm[])
{
  struct_pair8parms *pair8parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair8(0,Natom,NULL,fp);
  fclose(fp);

  pair8parms=calloc(*N,sizeof(struct_pair8parms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair8(1,Natom,pair8parms,fp);
  fclose(fp);

  return pair8parms;
}


#ifdef VIRTUAL
static
int topvirt2(int bSave,struct_virt2parms *virt2parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int v,i,j;
  double a;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d 1 %lg",&v,&i,&j,&a)==4) {
      if (bSave) {
        virt2parms[N].v=v-1;
        virt2parms[N].i=i-1;
        virt2parms[N].j=j-1;
        virt2parms[N].Ci=1-a;
        virt2parms[N].Cj=a;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


static
struct_virt2parms* alloc_virt2parms(int *N,char fnm[])
{
  struct_virt2parms *virt2parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ virtual_sites2 ]\n",fp);
  *N=topvirt2(0,NULL,fp);
  fclose(fp);

  virt2parms=calloc(*N,sizeof(struct_virt2parms));

  fp=fopen(fnm,"r");
  topseek("[ virtual_sites2 ]\n",fp);
  *N=topvirt2(1,virt2parms,fp);
  fclose(fp);

  return virt2parms;
}


static
int topvirt3(int bSave,struct_virt3parms *virt3parms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int v,i,j,k;
  double a,b;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %d 1 %lg %lg",&v,&i,&j,&k,&a,&b)==6) {
      if (bSave) {
        virt3parms[N].v=v-1;
        virt3parms[N].i=i-1;
        virt3parms[N].j=j-1;
        virt3parms[N].k=k-1;
        virt3parms[N].Ci=1-a-b;
        virt3parms[N].Cj=a;
        virt3parms[N].Ck=b;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


static
struct_virt3parms* alloc_virt3parms(int *N,char fnm[])
{
  struct_virt3parms *virt3parms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ virtual_sites3 ]\n",fp);
  *N=topvirt3(0,NULL,fp);
  fclose(fp);

  virt3parms=calloc(*N,sizeof(struct_virt3parms));

  fp=fopen(fnm,"r");
  topseek("[ virtual_sites3 ]\n",fp);
  *N=topvirt3(1,virt3parms,fp);
  fclose(fp);

  return virt3parms;
}
#endif


static
void addexcl(int in,struct_exclparms *exclparms,int i,int j)
{
  int ij;

  // See if we already have j in i's list
  for (ij=0; ij<exclparms[i].N[in]; ij++) {
    if (exclparms[i].j[ij]==j) {
      return;
    }
  }

  // If not, add j to i's list
  if (exclparms[i].N[in]==exclparms[i].Nmax) {
    exclparms[i].Nmax+=5;
    exclparms[i].j=realloc(exclparms[i].j,exclparms[i].Nmax*sizeof(int));
  }
  exclparms[i].j[exclparms[i].N[in]]=j;
  exclparms[i].N[in]++;
}


static
int topcount(FILE *fp)
{
  char s[MAXLENGTH];
  int i,N;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d",&i)==1) {
      N=i;
    } else {
      break;
    }
  }
  return N;
}


static
void topexcl(int in,int Natom,struct_exclparms *exclparms,FILE *fp)
{
  char s[MAXLENGTH];
  int i,j;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d",&i,&j)==2) {
      checkatom(i,Natom,s);
      checkatom(j,Natom,s);
      addexcl(in,exclparms,i-1,j-1);
      addexcl(in,exclparms,j-1,i-1);
    } else {
      break;
    }
  }
}


static
void updateexcl(int in,int N,struct_exclparms *exclparms)
{
  int i,j,k,j1,j2;

  for (i=0; i<N; i++) {
    exclparms[i].N[in]=exclparms[i].N[in-1];
    for (j=0; j<exclparms[i].N[in-1]; j++) {
      j1=exclparms[i].j[j];
      for (k=0; k<exclparms[j1].N[0]; k++) {
        j2=exclparms[j1].j[k];
        addexcl(in,exclparms,i,j2);
      }
    }
  }
}


static
struct_exclparms* alloc_exclparms(int *N,int Natom,char fnm[])
{
  struct_exclparms *exclparms;
  FILE *fp;
  int i;

  // Allocate for each atom
  exclparms=calloc(*N,sizeof(struct_exclparms));
  
  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  topexcl(0,Natom,exclparms,fp);
  fclose(fp);

  updateexcl(1,*N,exclparms);
  updateexcl(2,*N,exclparms);

  fp=fopen(fnm,"r");
  topseek("[ exclusions ]\n",fp);
  topexcl(2,Natom,exclparms,fp);
  fclose(fp);

  return exclparms;
}


#ifdef VIRTUAL
static
void topgroupndx(int key,int *groupndx,FILE *fp)
{
  char s[MAXLENGTH];
  char *sbuf;
  int spos;
  int i;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (s[0] == '[' || s[1] == '[') {
      break;
    } else {
      sbuf=s;
      while(sscanf(sbuf,"%d%n",&i,&spos)>0) {
        groupndx[i-1]=key;
        sbuf+=spos;
      }
    }
  }
}


static
int* alloc_groupndx(int *N,char fnm[])
{
  int *groupndx;
  FILE *fp;
  int i;

  // Allocate for each atom
  groupndx=calloc(*N,sizeof(int));
  
  fp=fopen(fnm,"r");
  topseek("[ Donor ]\n",fp);
  topgroupndx(1,groupndx,fp);
  fclose(fp);

  fp=fopen(fnm,"r");
  topseek("[ Acceptor ]\n",fp);
  topgroupndx(2,groupndx,fp);
  fclose(fp);

  fp=fopen(fnm,"r");
  topseek("[ OtherBase ]\n",fp);
  topgroupndx(3,groupndx,fp);
  fclose(fp);

  // // DEBUG
  // for (i=0; i<*N; i++) {
  //   fprintf(stderr,"%d\n",groupndx[i]);
  // }

  return groupndx;
}
#endif


struct_parms* alloc_topparms(struct_md *md)
{
  // char topfile[]="system/PK_NoNextLocal/PK_NoNextLocal.top";
  // char topfile[]="system/PK/PK.top"; // CONST
  struct_parms *parms=md->parms;
  char *topfile=parms->arg_topfile;
  int Natom=md->state->N_all; // probably should be N_rna

  // fprintf(stderr,"Warning, uncorrected unit mismatch\n");
  parms->bondparms=alloc_bondparms(&(parms->N_bond),Natom,topfile);
  parms->angleparms=alloc_angleparms(&(parms->N_angle),Natom,topfile);
  parms->dihparms=alloc_dihparms(&(parms->N_dih),Natom,topfile);
  parms->pair1parms=alloc_pair1parms(&(parms->N_pair1),Natom,topfile);
  parms->pair5parms=alloc_pair5parms(&(parms->N_pair5),Natom,topfile);
  parms->pair6parms=alloc_pair6parms(&(parms->N_pair6),Natom,topfile);
  parms->pair7parms=alloc_pair7parms(&(parms->N_pair7),Natom,topfile);
//  parms->pair8parms=alloc_pair8parms(&(parms->N_pair8),Natom,topfile);
//  parms->umbrella=alloc_umbrella(md);
#ifdef VIRTUAL
  parms->virt2parms=alloc_virt2parms(&(parms->N_virt2),Natom,topfile); // intentionally broken
  parms->virt3parms=alloc_virt3parms(&(parms->N_virt3),Natom,topfile);
#endif
  parms->N_excl=md->state->N_all;
  parms->exclparms=alloc_exclparms(&(parms->N_excl),Natom,topfile);

#ifdef VIRTUAL
  parms->groupndx=alloc_groupndx(&(md->state->N_all),parms->arg_ndxfile);
#endif

  return parms;
}


void free_topparms(struct_parms *parms)
{
  int i;
  free(parms->bondparms);
  free(parms->angleparms);
  free(parms->dihparms);
  free(parms->pair1parms);
  free(parms->pair5parms);
  free(parms->pair6parms);
  free(parms->pair7parms);
  free(parms->pair8parms);
  free(parms->umbrella);
#ifdef VIRTUAL
  free(parms->virt2parms);
  free(parms->virt3parms);
#endif
  // fprintf(stderr,"Free exclparms\n");
  for (i=0; i<parms->N_excl; i++) {
    if (parms->exclparms[i].Nmax>0) {
      free(parms->exclparms[i].j);
    }
  }
  free(parms->exclparms);
#ifdef VIRTUAL
  free(parms->groupndx);
#endif
}

