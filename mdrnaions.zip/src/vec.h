#ifndef MD_RNA_IONS_VEC_H
#define MD_RNA_IONS_VEC_H

#include "defines.h"

#include <math.h>

typedef double vec[3];

static inline
void vec_subtract(vec a,vec b,vec c)
{
  c[0]=a[0]-b[0];
  c[1]=a[1]-b[1];
  c[2]=a[2]-b[2];
}


static inline
void vec_subpbc(vec a,vec b,vec box,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    c[i]-=box[i]*floor(c[i]/box[i]+0.5);
  }
}


static inline
void vec_subsaveshift(vec a,vec b,vec box,vec shift,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    shift[i]=-box[i]*floor(c[i]/box[i]+0.5);
    c[i]+=shift[i];
  }
}


static inline
void vec_subshift_ns(vec a,vec b,vec sab,vec c) {
  c[0]=a[0]-b[0]+sab[0];
  c[1]=a[1]-b[1]+sab[1];
  c[2]=a[2]-b[2]+sab[2];
}


static inline
void vec_subshift(vec a,vec b,vec sa,vec sb,vec sab,vec c) {
  c[0]=a[0]+sa[0]-b[0]-sb[0]+sab[0];
  c[1]=a[1]+sa[1]-b[1]-sb[1]+sab[1];
  c[2]=a[2]+sa[2]-b[2]-sb[2]+sab[2];
}


static inline
void vec_subquick(vec a,vec b,vec box,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    c[i]-=box[i]*((c[i]>box[i]/2)-(c[i]<-box[i]/2));
  }
}


static inline
double vec_quickdist2(vec a,vec b,vec box)
{
  int i;
  double c,s=0;
  for (i=0; i<DIM3; i++) {
    c=a[i]-b[i];
    c-=box[i]*((c>box[i]/2)-(c<-box[i]/2));
    s+=c*c;
  }
  return s;
}


static inline
double vec_shiftdist2(vec a,vec b,vec shift)
{
  int i;
  double c,s=0;
  for (i=0; i<DIM3; i++) {
    c=a[i]-b[i]+shift[i];
    s+=c*c;
  }
  return s;
}


static inline
double vec_mag(vec a)
{
  return sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
}


static inline
double vec_mag2(vec a)
{
  return a[0]*a[0]+a[1]*a[1]+a[2]*a[2];
}


static inline
double vec_dot(vec a,vec b)
{
  return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
}


static inline
void vec_cross(vec a,vec b,vec c)
{
  c[0]=a[1]*b[2]-a[2]*b[1];
  c[1]=a[2]*b[0]-a[0]*b[2];
  c[2]=a[0]*b[1]-a[1]*b[0];
}


static inline
void vec__add(vec a,vec b,vec c) // extra underscore needed on BGQ
{
  c[0]=a[0]+b[0];
  c[1]=a[1]+b[1];
  c[2]=a[2]+b[2];
}


static inline
void vec_scale(vec a,double f,vec x)
{
  a[0]=f*x[0];
  a[1]=f*x[1];
  a[2]=f*x[2];
}


static inline
void vec_inc(vec a,vec x)
{
  a[0]+=x[0];
  a[1]+=x[1];
  a[2]+=x[2];
}


static inline
void vec_scaleinc(vec a,double f,vec x)
{
  a[0]+=f*x[0];
  a[1]+=f*x[1];
  a[2]+=f*x[2];
}


static inline
void vec_reset(vec a)
{
  a[0]=0;
  a[1]=0;
  a[2]=0;
}


static inline
void vec_copy(vec a,vec b)
{
  a[0]=b[0];
  a[1]=b[1];
  a[2]=b[2];
}


static inline
void ivec_copy(int* a,int* b)
{
  a[0]=b[0];
  a[1]=b[1];
  a[2]=b[2];
}


static inline
int ivec_eq(int* a,int* b)
{
  return a[0]==b[0] && a[1]==b[1] && a[2]==b[2];
}

#endif

