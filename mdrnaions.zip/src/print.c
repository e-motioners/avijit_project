
#include "print.h"

#include "defines.h"

#include "md.h"
#include "times.h"
#include "files.h"
#include "state.h"
#include "parms.h"
#include "qlist.h"
#include "collate.h"
#include "gausstables.h"
#include "nlist.h"

#include "xdr/xdrfile.h"
#include "xdr/xdrfile_xtc.h"

#include <stdio.h>

#ifndef NOMPI
#include <mpi.h>
#endif
#include <omp.h>
#ifdef BIOU
#include <unistd.h>
// #include <linux/getcpu.h>
#include <sched.h>
#endif


static
void printgro(struct_md* md)
{
  FILE *fp=md->files->fps[eF_gro];
  double *x=md->state->x;
  double *box=md->state->box;
  // char *typeR, *typeA;
  int *res_id=md->state->res_id;
  char (*res_name)[5]=md->state->res_name;
  int *atom_id=md->state->atom_id;
  char (*atom_name)[5]=md->state->atom_name;
  int i;
  int id=0;
  int phase=md->parms->phase;
  char fnm[100];

  if (fp == NULL) {
    #ifndef NOMPI
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    #endif
    id+=md->parms->offset;
    sprintf(fnm,"%s/traj.%d.%d.gro",md->parms->arg_outdir,id,phase);
    fp=fopen(fnm,"w");
    md->files->fps[eF_gro]=fp;
  }

  fprintf(fp,"Manning RNA trajectory, t= %g\n",md->state->step*md->parms->dt);
  // fprintf(fp,"Manning RNA trajectory (Gt= %g , Kt= %g , theta[0]= %g ), t= %g\n",md->state->Gt->master[0],md->state->Kt->master[0],md->state->qqlist->theta[0],md->state->step*md->parms->dt);
  fprintf(fp,"%d\n",md->state->N_all);
  /*for (i=0; i<DIM3*md->state->N_all; i+=3) {
    if (i/3 < md->state->N_rna) {
      typeR="RNA";
      typeA="P";
    } else {
      typeR="MG";
      typeA="MG";
    } // WORKING HERE - Read in atom types...
    fprintf(fp,"%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n",
      // "%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",
      i/3+1,typeR,typeA,i/3+1,x[i],x[i+1],x[i+2]);*/
  for (i=0; i<md->state->N_all; i++) {
    fprintf(fp,"%5d%.5s%.5s%5d%8.3f%8.3f%8.3f\n",
      // "%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",
      res_id[i],res_name[i],atom_name[i],atom_id[i],
      x[DIM3*i],x[DIM3*i+1],x[DIM3*i+2]);
  }
  fprintf(fp,"   %g   %g   %g\n",box[0],box[1],box[2]);
}


void printgroframe(struct_md* md,char* tag)
{
  FILE *fp;
  double *x=md->state->x;
  double *box=md->state->box;
  // char *typeR, *typeA;
  int *res_id=md->state->res_id;
  char (*res_name)[5]=md->state->res_name;
  int *atom_id=md->state->atom_id;
  char (*atom_name)[5]=md->state->atom_name;
  int i;
  int id=0;
  int phase=md->parms->phase;
  char fnm[100];

  #ifndef NOMPI
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  #endif
  id+=md->parms->offset;
  sprintf(fnm,"%s/%s.%d.%d.gro",md->parms->arg_outdir,tag,id,phase);
  fp=fopen(fnm,"w");

  fprintf(fp,"Manning RNA trajectory, t= %g\n",md->state->step*md->parms->dt);
  // fprintf(fp,"Manning RNA trajectory (Gt= %g , Kt= %g , theta[0]= %g ), t= %g\n",md->state->Gt->master[0],md->state->Kt->master[0],md->state->qqlist->theta[0],md->state->step*md->parms->dt);
  fprintf(fp,"%d\n",md->state->N_all);
  /*for (i=0; i<DIM3*md->state->N_all; i+=3) {
    if (i/3 < md->state->N_rna) {
      typeR="RNA";
      typeA="P";
    } else {
      typeR="MG";
      typeA="MG";
    } // WORKING HERE - Read in atom types...
    fprintf(fp,"%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n",
      // "%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",
      i/3+1,typeR,typeA,i/3+1,x[i],x[i+1],x[i+2]);*/
  for (i=0; i<md->state->N_all; i++) {
    fprintf(fp,"%5d%.5s%.5s%5d%8.3f%8.3f%8.3f\n",
      // "%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",
      res_id[i],res_name[i],atom_name[i],atom_id[i],
      x[DIM3*i],x[DIM3*i+1],x[DIM3*i+2]);
  }
  fprintf(fp,"   %g   %g   %g\n",box[0],box[1],box[2]);

  fclose(fp);
}


static
void printxtc(struct_md* md)
{
  // XDRFILE *fp=(XDRFILE*) md->files->fps[eF_xtc];
  XDRFILE *fp=md->files->xtc;
  double *x=md->state->x;
  rvec *fx=(rvec*) md->state->floatx;
  matrix box={{md->state->box[0],0,0},{0,md->state->box[1],0},{0,0,md->state->box[2]}};
  int i,j,N;
  int id=0;
  int phase=md->parms->phase;
  char fnm[100];

  if (fp == NULL) {
    printgroframe(md,"confin");
    #ifndef NOMPI
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    #endif
    id+=md->parms->offset;
    sprintf(fnm,"%s/traj.%d.%d.xtc",md->parms->arg_outdir,id,phase);
    // fp=fopen(fnm,"w");
    fp=xdrfile_open(fnm,"w");
    // md->files->fps[eF_xtc]=(FILE*) fp;
    md->files->xtc=fp;
  }

  N=md->state->N_all;
  for (i=0; i<N; i++) {
    for (j=0; j<DIM3; j++) {
      fx[i][j]=(float) x[DIM3*i+j];
    }
  }
//  extern int write_xtc(XDRFILE *xd,
//                       int natoms,int step,double time,
//                       matrix box,rvec *x,double prec);
  write_xtc(fp,N,md->state->step,(float) (md->state->step*md->parms->dt),
    box,fx,1000.0);
}


/*void printxyz(struct_md* md)
{
  FILE *fp=md->files->fp_xyz;
  double *x=md->state->x;
  int i;

  if (fp == NULL) {
    fp=fopen("pos.xyz","w");
    md->files->fp_xyz=fp;
  }

  fprintf(fp,"%d\nComment - Frame %d\n",md->state->N_all,md->state->step);
  for (i=0; i<DIM3*md->state->N_all; i+=3) {
    fprintf(fp,"P %g %g %g\n",x[i],x[i+1],x[i+2]);
  }

  // fclose(fp); is called in free_files
}*/


// printdata(md->state->qqlist->theta,md->state->qqlist->nqlist_rna,"theta",&(md->files->fp_theta))
static
void printdata(struct_md *md,double* data,int N,char* s,FILE** fp)
{
  int i, id=0;
  int phase=md->parms->phase;
  char fnm[100];

  if (*fp == NULL) {
    #ifndef NOMPI
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    #endif
    id+=md->parms->offset;
    sprintf(fnm,"%s/%s.%d.%d.dat",md->parms->arg_outdir,s,id,phase);
    *fp=fopen(fnm,"w");
  }

  for (i=0; i<N; i++) {
    fprintf(*fp," %12g",data[i]);
  }
  fprintf(*fp,"\n");
}


void printheader(struct_md* md)
{
  int i,id=0;
  int phase=md->parms->phase;
  char fnm[100];
  
  #ifndef NOMPI
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  #endif
  id+=md->parms->offset;
  sprintf(fnm,"%s/md.%d.%d.log",md->parms->arg_outdir,id,phase);
  md->files->fps[eF_log]=fopen(fnm,"w");

  printversion(md->files->fps[eF_log]);
  md->times->secpcyc=gmx_cycles_calibrate(1.0);
  fprintf(md->files->fps[eF_log],"1 second took %g cycles\n",1.0/md->times->secpcyc);
  md->parms->maxc=(gmx_cycles_t) (0.99*3600.0*md->parms->maxh/md->times->secpcyc);

  fprintf(md->files->fps[eF_log],"xyzqfile = %s\n",md->parms->arg_xyzqfile);
  fprintf(md->files->fps[eF_log],"grofile = %s\n",md->parms->arg_grofile);
  fprintf(md->files->fps[eF_log],"topfile = %s\n",md->parms->arg_topfile);
  fprintf(md->files->fps[eF_log],"outdir = %s\n",md->parms->arg_outdir);
  fprintf(md->files->fps[eF_log],"box = %g nm\n",md->parms->arg_box);
  fprintf(md->files->fps[eF_log],"conc_KCl = %g nm^-3\n",md->parms->conc_K);
  fprintf(md->files->fps[eF_log],"N_mg = %d\n",md->parms->arg_N_mg);
  fprintf(md->files->fps[eF_log],"(Reduced) Temperature = %g\n",md->parms->kTr/md->parms->kB);
  fprintf(md->files->fps[eF_log],"sigma_eta = %g\n",md->parms->gauss_02);

  if (md->parms->phase > 0) {
    fprintf(md->files->fps[eF_log],"Read checkpoint file %s/state.%d.%d.cpt\n",md->parms->arg_outdir,md->parms->id,md->parms->phase-1);
  } else {
    fprintf(md->files->fps[eF_log],"Found no checkpoint file, starting a new run.\n");
  }
}

/* Buggy code on biou. Maybe try only printing with the head node?
void printmoreheader(struct_md *md)
{
#ifdef BIOU
  int i;
  int cpu,node;
  int ID,NID;
  FILE *fp=md->files->fps[eF_log];
  char machine[MAXLENGTH];

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  machine[MAXLENGTH-1]='\0';
  // getcpu(&cpu,&node,NULL);
  gethostname(machine,MAXLENGTH-1);
  #pragma omp master
  fflush(fp);
  #pragma omp barrier
  for (i=0;i<NID;i++) {
    if (i==ID) {
      // fprintf(fp,"OpenMP process %d is on machine %s\n",i,machine);
      // fprintf(fp,"OpenMP process %d is on cpu %d node %d machine %s\n",i,cpu,node,machine);
      fprintf(fp,"OpenMP process %d is on cpu %d machine %s\n",i,sched_getcpu(),machine);
      fflush(fp);
    }
    #pragma omp barrier
  }
#endif
}*/


void printoutput(struct_md* md)
{
  FILE **fps=md->files->fps;
  struct_qlist *qqlist=md->state->qqlist;
  // int ndata=qqlist->nqlist_rna;
  // int ndata=qqlist->nqlist;
  int ndata=qqlist->nqlist_th;
  // int ndata=qqlist->nqlist;

  #pragma omp master
  {
    md->times->start=gmx_cycles_read();

    if (md->parms->trajfmt==0) {
      printgro(md);
    } else {
      printxtc(md);
    }
    printdata(md,qqlist->theta,ndata,"theta",&(fps[eF_theta]));
    printdata(md,qqlist->theta_cl,ndata,"theta_cl",&(fps[eF_theta_cl]));
    printdata(md,qqlist->eta,ndata,"eta",&(fps[eF_eta]));
    printdata(md,qqlist->eta_cl,ndata,"eta_cl",&(fps[eF_eta_cl]));
#ifdef POLARIZE
    printdata(md,qqlist->polar,DIM3*ndata,"polar",&(fps[eF_polar]));
    printdata(md,qqlist->polar_cl,DIM3*ndata,"polar_cl",&(fps[eF_polar_cl]));
    printdata(md,qqlist->k_polar,ndata,"k_pk",&(fps[eF_k_pk]));
    printdata(md,qqlist->k_polar_cl,ndata,"k_pcl",&(fps[eF_k_pcl]));
#endif
    fprintf(fps[eF_log],"Step %d\n",md->state->step);

    printdata(md,md->state->Gt->master,1,"Gt",&(fps[eF_Gt]));
    printdata(md,md->state->Gts->master,eE_MAX,"Gts",&(fps[eF_Gts]));
    printdata(md,md->state->Kt->master,1,"Kt",&(fps[eF_Kt]));

    printdata(md,qqlist->dens_tk,ndata,"dens_tk",&(fps[eF_dens_tk]));
    printdata(md,qqlist->dens_tcl,ndata,"dens_tcl",&(fps[eF_dens_tcl]));
    printdata(md,qqlist->dens_ek,ndata,"dens_ek",&(fps[eF_dens_ek]));
    printdata(md,qqlist->dens_ecl,ndata,"dens_ecl",&(fps[eF_dens_ecl]));
    // printdata(qqlist->pot_t->master,ndata,"pot_t",&(fps[eF_pot_t]));
    // printdata(qqlist->pot_e->master,ndata,"pot_e",&(fps[eF_pot_e]));
    // printdata(qqlist->dV,ndata,"dV",&(fps[eF_dV]));

    printdata(md,qqlist->V1eff_inv->master,ndata,"V1eff_inv",&(fps[eF_V1eff_inv]));
    printdata(md,qqlist->V2eff_inv->master,ndata,"V2eff_inv",&(fps[eF_V2eff_inv]));

   // if (md->parms->umbrella) {
   //   printdata(md,md->parms->umbrella->Q_act->master,1,"Q",&(fps[eF_Q]));
   //   printdata(md,&(md->parms->umbrella->EQ),1,"EQ",&(fps[eF_EQ]));
   //  }

    md->times->write+=(gmx_cycles_read()-md->times->start);
  }
  #pragma omp barrier
}


void printsummary(struct_md* md,gmx_cycles_t start)
{
  gmx_cycles_t stop;
  gmx_cycles_t s,si;
  int i,NID;
  FILE *fp=md->files->fps[eF_log];

  NID=omp_get_max_threads();

  stop=gmx_cycles_read();
  fprintf(fp,"Took %lld cycles\n",stop-start);
  fprintf(fp,"Took %g second\n",(stop-start)*md->times->secpcyc);

  fprintf(fp,"Neighbor search %lld cycles\n",md->times->nsearch);
  fprintf(fp,"Force calculation %lld cycles\n",md->times->force);
    fprintf(fp,"  Bond  Force calculation %lld cycles\n",md->times->force_bond);
    fprintf(fp,"  Angle Force calculation %lld cycles\n",md->times->force_angle);
    fprintf(fp,"  Dih   Force calculation %lld cycles\n",md->times->force_dih);
    fprintf(fp,"  Pair  Force calculation %lld cycles\n",md->times->force_pair);
    fprintf(fp,"  Elec  Force calculation %lld cycles\n",md->times->force_elec);
    fprintf(fp,"  Other Force calculation %lld cycles\n",md->times->force_other);
    #ifdef VIRTUAL
    fprintf(fp,"  Virt  Force calculation %lld cycles\n",md->times->force_virtual);
    #endif
    fprintf(fp,"  Sum   Force calculation %lld cycles\n",md->times->force_sum);
  fprintf(fp,"Update %lld cycles\n",md->times->update);
  fprintf(fp,"Writing files %lld cycles\n",md->times->write);
  fprintf(fp,"WORKING HERE - put in percentages\n");

  fprintf(fp,"elec sort   ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_sort[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec check  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec force  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_force[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);

  fprintf(fp,"other sort  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_sort[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other force ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_force[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);

  fprintf(fp,"------------------------------------------------\n");
  fprintf(fp,"elec check1 ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check1[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec check2 ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check2[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check1");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check1[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check2");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check2[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);

  // fprintf(stderr,"Write checkpoint file\n");
  printcheckpoint(md);
  // md->state->step=md->parms->steplim;
}

