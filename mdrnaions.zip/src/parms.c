
#include "parms.h"

#include "defines.h"

#include "gausstables.h"
#include "leapparms.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#ifndef NOMPI
#include <mpi.h>
#endif
#include <sys/stat.h>

static
void read_parameter_b(int *A,FILE *fp,char *token,int def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  char a[MAXLENGTH];
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    // sscanf(s,"%s = %s",&ss,&a);
    sscanf(s,"%s = %s",ss,a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      // sscanf(s,"%s = %n",&ss,&spos);
      sscanf(s,"%s = %n",ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          // sscanf(sbuf,"%s%n",&a,&spos);
          sscanf(sbuf,"%s%n",a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    if (strcmp(a,"yes")==0) {
      *A=1;
    } else if(strcmp(a,"no")==0) {
      *A=0;
    } else {
      *A=def;
    }
  } else {
    *A=def;
  }
}


static
void read_parameter_i(int *A,FILE *fp,char *token,int def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  int a;
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    // sscanf(s,"%s = %d",&ss,&a);
    sscanf(s,"%s = %d",ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      // sscanf(s,"%s = %n",&ss,&spos);
      sscanf(s,"%s = %n",ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%d%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    *A=a;
  } else {
    *A=def;
  }
}


static
void read_parameter_d(double *A,FILE *fp,char *token,double def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  double a;
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    // sscanf(s,"%s = %lg",&ss,&a);
    sscanf(s,"%s = %lg",ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      // sscanf(s,"%s = %n",&ss,&spos);
      sscanf(s,"%s = %n",ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%lg%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    *A=a;
  } else {
    *A=def;
  }
}


static
void read_parameter_s(char **A,FILE *fp,char *token,char *def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  char a[MAXLENGTH];
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    // sscanf(s,"%s = %s",&ss,&a);
    sscanf(s,"%s = %s",ss,a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      // sscanf(s,"%s = %n",&ss,&spos);
      sscanf(s,"%s = %n",ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          // sscanf(sbuf,"%s%n",&a,&spos);
          sscanf(sbuf,"%s%n",a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    strcpy(*A,a);
  } else {
    strcpy(*A,def);
  }
}

// WORKING HERE
// Allocation/free functions
struct_parms* alloc_parms(int argc, char *argv[])
{
  struct_parms *parms;
  FILE *fp;
  char buffer[MAXLENGTH];
  char *bufferp=buffer;
  double gamma;

  int id=0;
  double eps;
  double cMg,cK,cCl;
  double s;
  double T,Tr,Tr0;
  double g2;

  fp=fopen(argv[1],"r");
  if (fp==NULL) {
    fprintf(stderr,"Fatal Error: input file %s could not be opened\n(Probably doesn't exist)\n",argv[1]);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }

  parms=malloc(sizeof(struct_parms));

  #ifndef NOMPI
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  #endif
  // WORKING ERROR
  read_parameter_i(&(parms->offset),fp,"offset",0,id);
  id+=parms->offset;
  parms->id=id;
  parms->phase=0; // Which phase, 0 is no previous checkpoint. Updated elsewhere

  read_parameter_d(&(parms->maxh),fp,"maxh",168000.0,id);

  read_parameter_d(&(parms->arg_box),fp,"box",100,id);
  read_parameter_i(&(parms->arg_N_mg),fp,"N_mg",250,id);
  parms->arg_topfile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_topfile),fp,"topfile","",id);
  parms->arg_xyzqfile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_xyzqfile),fp,"xyzqfile","",id);
  parms->arg_grofile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_grofile),fp,"grofile","",id);
  parms->arg_outdir=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_outdir),fp,"outdir","outfiles",id);
  mkdir(parms->arg_outdir,0777);
  read_parameter_d(&(parms->outputguard),fp,"outputguard",5e10,id);
#ifdef VIRTUAL
  parms->arg_ndxfile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_ndxfile),fp,"ndxfile","",id);
#endif
  read_parameter_s(&(bufferp),fp,"trajfmt","xtc",id);
  if (strcmp(buffer,"gro")==0) {
    parms->trajfmt=0;
  } else if (strcmp(buffer,"xtc")==0) {
    parms->trajfmt=1;
  } else {
    fprintf(stderr,"Fatal Error: unrecognized trajfmt option %s.\nRecognized trajectory formats are gro or xtc\n",parms->trajfmt);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }
  read_parameter_d(&(g2),fp,"sigma_eta",0.34,id);

  // Temperatures
  parms->kB=0.0083144; // Boltzmann Constant
  read_parameter_d(&Tr,fp,"ref_t",90,id);
  read_parameter_d(&Tr0,fp,"ref_t0",90,id);
  T=300*Tr/Tr0;
  parms->kT0=parms->kB*300; // Room temperature (Kelvin)
  parms->kTr0=parms->kB*Tr0; // Room temperature (reduced units - 90 for vanilla)
  parms->kTr=parms->kB*Tr; // System temperature (reduced units)
  parms->kT=parms->kB*T; // System temperature (Kelvin)

  // Electrostatics
  // From Malmberg and Maryott, Journal of Research of the National Bureau of Standards, Vol 56, Research paper 2641 (1956)
  // http://nvlpubs.nist.gov/nistpubs/jres/56/jresv56n1p1_A1b.pdf
  // eps=87.740-0.40008*(T-273.15)+9.398e-4*(T-273.15)^2-1.410e-6*(T-273.15)^3;
  // delta<=0.01 from 0 C to 100 C
  // OR
  // eps=10.^(1.94315-0.0019720*(T-273.15));
  // delta<=0.02 from 0 C to 100 C
  eps=exp(5.71455988-0.004540698*T);
  // parms->lB=0.7; // nm
  // parms->lB=0.71*Tr0/Tr; // nm - temperature dependence is wrong; monotonic decrease instead of monotonic increase
  // lB=1/(4*pi*5.7275e-4*eps*0.0083144*T)
  parms->lB=16710.7/(eps*T); // nm
  cMg=parms->arg_N_mg/(parms->arg_box*parms->arg_box*parms->arg_box); // nm^-3
  read_parameter_d(&cK,fp,"conc_KCl",0.05,id);
  cK*=MOLAR; // nm^-3
  parms->conc_K=cK;
  parms->conc_Cl=cCl=cK+2*cMg; // nm^-3
  parms->conc_KCl=cK+2.0*cK*cMg/(cK+cCl); // nm^-3
  parms->kappa=sqrt(4*M_PI*(cK+cCl)*parms->lB); // nm^-1 - inverse DH length
  parms->gauss_00=0; // nm
  parms->gauss_01=parms->lB; // 0.7 nm is suggested
  parms->gauss_02=g2; // 0.34; // 0.34 nm is suggested
  parms->gauss_11=sqrt(2*parms->gauss_01*parms->gauss_01);
  parms->gauss_12=sqrt(parms->gauss_01*parms->gauss_01+parms->gauss_02*parms->gauss_02);
  parms->gauss_22=sqrt(2*parms->gauss_02*parms->gauss_02);
  // b=0.167; // nm, xi=4.2
  // parms->xi=lB/b;
  // parms->V=4*M_PI*exp(1)*parms->f_KCl*(parms->lB-b)*b*b;
  // parms->V=1.0;
  parms->V1=M_SQRT8PI3*parms->gauss_01*parms->gauss_01*parms->gauss_01;
  parms->V2=M_SQRT8PI3*parms->gauss_02*parms->gauss_02*parms->gauss_02;
  parms->k_prohibit=1e4; // kT0
  parms->k_soft=1.0; // kT0
  parms->rcelec=5/parms->kappa; // nm - electrostatic force cutoff
  parms->elec_tables=alloc_tables(parms->rcelec,parms);
  if (((int) (parms->arg_box/parms->rcelec)) < 3) {
    fprintf(stderr,"Fatal Error: box size %g is less than three times larger than\nelectrostatic cutoff of %g. Increase box size or conc_KCl. It may be\nsafe to run with the box only twice as large as the cutoff if 4*N entries\nare allocated to checklist and shiftlist in alloc_nlist in neigh.c\n",parms->arg_box,parms->rcelec);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }

  // Excluded Volume
  parms->k12=1.0;
  #ifdef VIRTUAL
  parms->s2[0][0]=0.25*0.25;
  #else
  parms->s2[0][0]=pow(5.96046e-10,1.0/6.0);
  #endif
  // s=0.34*pow(,(1.0/12.0));
  parms->s2[0][1]=0.34*0.34;
  parms->s2[1][0]=0.34*0.34;
  parms->s2[1][1]=0.56*0.56;
  parms->rcother=1.5; // nm - excluded volume force cutoff
  if (((int) (parms->arg_box/parms->rcother)) < 3) {
    fprintf(stderr,"Fatal Error: box size %g is less than three times larger than\nexcluded volume cutoff of %g. Increase box size. It may be\nsafe to run with the box only twice as large as the cutoff if 4*N entries\nare allocated to checklist and shiftlist in alloc_nlist in neigh.c\n",parms->arg_box,parms->rcother);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }

  // Run Control
  read_parameter_i(&(parms->t_output),fp,"nstxout",5000,id); // output frequency
  parms->t_ns=20; // neighbor search frequency
  parms->anneal1lim=1000; // Number of steps for electrostatic equilibration
  parms->anneal2lim=20000; // Number of steps for electrostatic equilibration
  read_parameter_i(&(parms->steplim),fp,"nsteps",200000000,id); // Number of steps

  // Leapfrog parameters
  // gamma=1e-5 works well for constantish energy simulations
  read_parameter_d(&(parms->dt),fp,"dt",0.002,id); // ps - timestep
  gamma=1; // ps^-1 - drag coefficient for atoms (60 ps^-1 in water)
  parms->leapparms=alloc_leapparms(parms->dt,gamma,parms->kTr);
  gamma=10; // ps^-1 - drag coefficient condensation during equilibration
  parms->leapparms_anneal1=alloc_leapparms(0.1*parms->dt,gamma,0.01*parms->kT);
  gamma=5; // ps^-1 - drag coefficient condensation during equilibration
  parms->leapparms_anneal2=alloc_leapparms(parms->dt,gamma,0.01*parms->kT);
  gamma=0.05; // ps^-1 - drag coefficient condensation during production
  parms->leapparms_mcc=alloc_leapparms(parms->dt,gamma,parms->kT);

  read_parameter_b(&(parms->flexible),fp,"flexible",0,id);

  fclose(fp);

  return parms;
}


void free_parms(struct_parms* parms)
{
  free_tables(parms->elec_tables);
  free_leapparms(parms->leapparms);
  free_leapparms(parms->leapparms_mcc);
  free_leapparms(parms->leapparms_anneal1);
  free_leapparms(parms->leapparms_anneal2);
  free(parms);
}

