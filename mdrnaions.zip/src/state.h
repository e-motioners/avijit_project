#ifndef MD_RNA_IONS_STATE_H
#define MD_RNA_IONS_STATE_H

#include "vec.h"
#include "md.h"
#include "umbrella.h"

struct struct_qlist;
struct struct_atoms;
struct struct_collate;
struct struct_nlist;
struct struct_mtstate;

typedef enum {
  eE_bond,
  eE_angle,
  eE_dihedral,
  eE_pair1,
  eE_pair5,
  eE_pair6,
  eE_pair7,
  eE_pair8,
  eE_elec,
  eE_lj,
  eE_MAX
} eNRG;

typedef struct struct_state
{
  int step;
  int walltimeleft;
  vec box;
  double *x; // DIM3*N_fixed coordinates followed by DIM3*N_free coordinates
  float *floatx; // xtc output use only
  double *shift;
  double *q;
  int *res_id;
  char (*res_name)[5];
  int *atom_id;
  char (*atom_name)[5];
  int N_fixed;
  int N_free;
  int N_rna;
  int N_mg;
  int N_all;
  int abortflag;
  struct struct_qlist *qqlist;
  struct struct_atoms *atoms;
  struct struct_collate *Gt;
  struct struct_collate *Gts;
  struct struct_collate *Kt;
  struct struct_atoms *manningcc_tk;
  struct struct_atoms *manningcc_tcl;
  struct struct_atoms *manningcc_ek;
  struct struct_atoms *manningcc_ecl;
#ifdef POLARIZE
  struct struct_atoms *manningcc_pk;
  struct struct_atoms *manningcc_pcl;
#endif
  struct struct_nlist *nlelec;
  struct struct_nlist *nlother;
  struct struct_mtstate **mtstate;
  struct struct_umbrella *umbrella;
} struct_state;

struct_state* alloc_state(struct_md* md);

void free_state(struct_state* state);

#endif

