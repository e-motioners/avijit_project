#ifndef MD_RNA_IONS_UMBRELLA_H
#define MD_RNA_IONS_UMBRELLA_H

#include "md.h" 
#include "collate.h"

typedef struct struct_umbrella
{
int freq_out;
double k_umb;
double Q_ref;
double Q_start;
double Q_steps;
struct_collate *Q_act;
double EQ;
} struct_umbrella ;

struct_umbrella* alloc_umbrella();
void free_umbrella(struct_umbrella* umbrella);

void getforce_pair8(struct_md* md);
// void start_umbrella( struct_md* const md );
// void calc_umbrella( struct_md* const md );
// void apply_umbrella( struct_md* const md );
// void getforce_umbrella(struct_md* md);

#endif
