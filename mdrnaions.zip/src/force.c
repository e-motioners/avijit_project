
#include "force.h"

#include "leapparms.h"
#include "specific.h"
#include "unspecific.h"
#include "collate.h"
#include "nlist.h"
#include "times.h"
#include "parms.h"
#include "atoms.h"
#include "md.h"
#include "state.h"

#include "umbrella.h"

#include <omp.h>

static
void loadbalance_f(struct_nlist* nlist)
{
  int i,NID;
  gmx_cycles_t cycles_prev,cycles;
  int boundary;

  NID=omp_get_max_threads();

  for (i=1;i<NID;i++) {
    cycles_prev=nlist->cycles_force[i-1];
    nlist->cumcycles_force[i-1]+=nlist->cycles_force[i-1];
    nlist->cycles_force[i-1]=0;

    cycles=nlist->cycles_force[i];
    boundary=nlist->imin_f[i];
    if (cycles < cycles_prev && boundary > nlist->imin_f[i-1]) {
      boundary--;
    } else if (cycles > cycles_prev && boundary < nlist->imax_f[i]) {
      boundary++;
    }
    nlist->imin_f[i]=boundary;
    nlist->imax_f[i-1]=boundary;
  }
  nlist->cumcycles_force[NID-1]+=nlist->cycles_force[NID-1];
  nlist->cycles_force[NID-1]=0;
}


static
void getkineticcontribution(struct_atoms *atoms,struct_collate *Kt,double unit)
{
  int i,imin,imax;
  int ID,NID;
  int Ni,Nf;
  double *m;
  double *v;
  double *KtL;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  m=atoms->m;
  v=atoms->v;
  Ni=atoms->Ni;
  Nf=atoms->Nf;
  imin=Ni+((Nf-Ni) * ID)/NID;
  imax=Ni+((Nf-Ni) * (ID+1))/NID;

  KtL=Kt->local[ID];
  for (i=imin; i<imax; i++) {
    KtL[0]+=0.5*unit*m[i]*v[i]*v[i];
  }
  
}

static
void getkineticcontribution_new(struct_atoms *atoms,struct_leapparms* leapparms,struct_collate *Kt,double unit)
{
  int i,imin,imax;
  int ID,NID;
  int Ni,Nf;
  double *m=atoms->m;
  double *v=atoms->v;
  double *vhalf=atoms->vhalf;
  double *f=atoms->f->master;
  double *Vs=atoms->Vs_delay;
  double vhalf_vscale=leapparms->vhalf_vscale;
  double vhalf_ascale=leapparms->vhalf_ascale;
  double vhalf_Vsscale=leapparms->vhalf_Vsscale;
  double *KtL;


  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  Ni=atoms->Ni;
  Nf=atoms->Nf;
  imin=Ni+((Nf-Ni) * ID)/NID;
  imax=Ni+((Nf-Ni) * (ID+1))/NID;

  KtL=Kt->local[ID];
  for (i=imin; i<imax; i++) {
    vhalf[i]=vhalf_vscale*v[i]+vhalf_ascale*f[i]/m[i]+vhalf_Vsscale*Vs[i];
    KtL[0]+=0.5*unit*m[i]*vhalf[i]*vhalf[i];
  }
  
}


static
void getkinetic(struct_md *md)
{
  double unit=md->parms->kTr0/md->parms->kT0;

  getkineticcontribution(md->state->atoms,md->state->Kt,1.0);
  getkineticcontribution(md->state->manningcc_tk,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_tcl,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_ek,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_ecl,md->state->Kt,unit);
#ifdef POLARIZE
  getkineticcontribution(md->state->manningcc_pk,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_pcl,md->state->Kt,unit);
#endif

/*
  getkineticcontribution_new(md->state->atoms,md->parms->leapparms,md->state->Kt,1.0);
  getkineticcontribution_new(md->state->manningcc_tk,md->parms->leapparms_mcc,md->state->Kt,unit);
  getkineticcontribution_new(md->state->manningcc_tcl,md->parms->leapparms_mcc,md->state->Kt,unit);
  getkineticcontribution_new(md->state->manningcc_ek,md->parms->leapparms_mcc,md->state->Kt,unit);
  getkineticcontribution_new(md->state->manningcc_ecl,md->parms->leapparms_mcc,md->state->Kt,unit);
#ifdef POLARIZE
  getkineticcontribution_new(md->state->manningcc_pk,md->parms->leapparms_mcc,md->state->Kt,unit);
  getkineticcontribution_new(md->state->manningcc_pcl,md->parms->leapparms_mcc,md->state->Kt,unit);
#endif
*/
}


static
void resetforce(struct_md* md)
{
  int ID;

  ID=omp_get_thread_num();

  resetlocal_collate(md->state->atoms->f,ID);

  resetlocal_collate(md->state->manningcc_tk->f,ID);
  resetlocal_collate(md->state->manningcc_tcl->f,ID);
  resetlocal_collate(md->state->manningcc_ek->f,ID);
  resetlocal_collate(md->state->manningcc_ecl->f,ID);
#ifdef POLARIZE
  resetlocal_collate(md->state->manningcc_pk->f,ID);
  resetlocal_collate(md->state->manningcc_pcl->f,ID);
#endif

  resetlocal_collate(md->state->Gt,ID);
  resetlocal_collate(md->state->Gts,ID);
  resetlocal_collate(md->state->Kt,ID);
}


static
void sumforce(struct_md* md)
{
  int ID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();

  ID=omp_get_thread_num();

  sumlocal_collate(md->state->atoms->f,ID);

  sumlocal_collate(md->state->manningcc_tk->f,ID);
  sumlocal_collate(md->state->manningcc_tcl->f,ID);
  sumlocal_collate(md->state->manningcc_ek->f,ID);
  sumlocal_collate(md->state->manningcc_ecl->f,ID);
#ifdef POLARIZE
  sumlocal_collate(md->state->manningcc_pk->f,ID);
  sumlocal_collate(md->state->manningcc_pcl->f,ID);
#endif

  sumlocal_collate(md->state->Gt,ID);
  sumlocal_collate(md->state->Gts,ID);
// #pragma omp barrier
//   getkinetic(md); // placed here because getkinetic requires forces on half steps
  sumlocal_collate(md->state->Kt,ID);

  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_sum+=(gmx_cycles_read()-start);
}


void getforce(struct_md* md)
{
  #pragma omp master
    md->times->start=gmx_cycles_read();
  #pragma omp sections
  {
    #pragma omp section
      loadbalance_f(md->state->nlelec);
    #pragma omp section
      loadbalance_f(md->state->nlother);
  }
  // There is an implied barrier at the end of a SECTIONS directive, unless the NOWAIT/nowait clause is used
  resetforce(md);
#ifndef NO_ELEC
  // getforce_elec_v2(md);
  #ifdef POLARIZE
  getforce_elec_v3(md);
  #elif MOHANTY
  getforce_elec_v4_mohanty_v32(md);
  #else
  getforce_elec(md);
  #endif
#endif
  getforce_other(md);

  if (md->parms->flexible) {
    getforce_bond(md);
    getforce_angle(md);
    getforce_dih(md);
    getforce_pair1(md);
    getforce_pair5(md);
    getforce_pair6(md);
    getforce_pair7(md);
   // getforce_pair8(md); // umbrella potential
#ifdef VIRTUAL
    getforce_virt3(md);
    getforce_virt2(md);
#endif
  }
  getkinetic(md); // put inside sumforce if using halfstep velocity
  getforce_umbrella(md); // contains barriers
  #pragma omp barrier
  sumforce(md);
  #pragma omp master
    md->times->force+=(gmx_cycles_read()-md->times->start);
  #pragma omp barrier
}

