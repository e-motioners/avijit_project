
#ifndef NOMPI
#ifdef DEBUG

#include "mpidebug.h"

#include "defines.h"

#include <mpi.h>
#include <signal.h>
#include <stdio.h>

void arrested_development(void) {
  int i, id=0, nid=1;
  char hostname[200];
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  MPI_Comm_size(MPI_COMM_WORLD,&nid);
  for (i=0; i<nid; i++) {
    MPI_Barrier(MPI_COMM_WORLD);
    if (i==id) {
      gethostname(hostname,200);
      fprintf(stderr,"PID %d rank %d host %s\n",getpid(),id,hostname);
    }
    MPI_Barrier(MPI_COMM_WORLD);
  }
  raise(SIGSTOP); // Identical behavior, uncatchable.
}
#endif
#endif
