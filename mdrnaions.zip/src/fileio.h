#ifndef MD_RNA_IONS_FILEIO_H
#define MD_RNA_IONS_FILEIO_H

#include "state.h"

void read_gro(char *fnm,struct_state* state);

int read_xyzq(char *fnm,struct_state* state,int N);

void gen_xyzq(struct_state* state,double r01,double r11);

#endif
