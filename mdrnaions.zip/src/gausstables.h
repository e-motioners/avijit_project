#ifndef MD_RNA_IONS_GAUSSTABLES_H
#define MD_RNA_IONS_GAUSSTABLES_H

#include "vec.h"
#include "parms.h"

// CONST
// Table extension
// Maximum distance particles are likely to move between neighbor searches
#define TABEXT 1.0

typedef void (*potfunc)(double,double,double,double,double,double*,double*);

typedef enum {
  eT_DH00,
  eT_DH01,
  eT_DH02,
  eT_DH11,
  eT_DH12,
  eT_DH22,
  eT_G1,
  eT_G2,
#ifdef POLARIZE
  eT_gDH01,
  eT_gDH11,
  eT_gDH12,
  eT_ggDH11,
#endif
  eT_MAX
} eTABLE;


typedef struct struct_nldata
{
  double r;
  vec dr;
  double Eij[eT_MAX];
  double Frij[eT_MAX];
} struct_nldata;


typedef struct struct_point
{
  double A0; // Vi
  double A1; // -h*Fi
  double A2; // 3*(Vi1-Vi+h*Fi)+(h*Fi1-h*Fi)
  double A3; // -2*(Vi1-Vi+h*Fi)-(h*Fi1-h*Fi)
} struct_point;


typedef struct struct_tables
{
  struct_point (*point)[eT_MAX]; // Debye Huckel
  double hinv; // inverse spacing [nm^-1]
  int N; // number of entries
} struct_tables;


struct_tables* alloc_tables(double cut, struct_parms* parms);

// void tables_interp(struct_tables* tabs,struct_nldata* data,struct_md* md);
int tables_interp(struct_tables* tabs,struct_nldata* data);

void free_tables(struct_tables* tables);

#endif

