
#include "qlist.h"

#include "defines.h"

#include "collate.h"

#include <stdlib.h>

/*void inittheta(struct_qlist* qqlist)
{
  int i;
  for (i=0; i<qqlist->nqlist; i++) {
    if (qqlist->bP[i]) {
      qqlist->theta[i]=0.76;
      qqlist->theta_cl[i]=0.76;
    }
  }
}*/


struct_qlist* alloc_qlist(struct_state* state)
{
  struct_qlist *qlist;
  int i,n,n_rna,n_th;

  qlist=malloc(sizeof(struct_qlist));

  n=0;
  for (i=0; i<state->N_rna; i++) {
    if (state->q[i] != 0) {
      n++;
    }
  }
  n_rna=n;
  for (i=state->N_rna; i<state->N_all; i++) {
    if (state->q[i] != 0) {
      n++;
    }
  }
  #ifdef MGTHETA
  // Condensation on Mg too
  n_th=n; // CONST
  #elif defined NOTHETA
  // Condensation on RNA only
  n_th=0; // CONST
  #else
  // Condensation on RNA only
  n_th=n_rna; // CONST
  #endif

  qlist->nqlist=n;
  qlist->nqlist_th=n_th;
  qlist->qlist=calloc(n,sizeof(int));
  qlist->x=calloc(DIM3*n,sizeof(double));
  qlist->theta=calloc(n,sizeof(double));
  qlist->theta_cl=calloc(n,sizeof(double));
  qlist->eta=calloc(n,sizeof(double));
  qlist->eta_cl=calloc(n,sizeof(double));
#ifdef POLARIZE
  qlist->polar=calloc(DIM3*n,sizeof(double));
  qlist->polar_cl=calloc(DIM3*n,sizeof(double));
#endif
  qlist->bP=calloc(n,sizeof(double));
  qlist->condens_tk=alloc_collate(n,0,n_th);
  qlist->condens_tcl=alloc_collate(n,0,n_th);
  qlist->condens_ek=alloc_collate(n,0,n_th);
  qlist->condens_ecl=alloc_collate(n,0,n_th);
#ifdef POLARIZE
  qlist->condens_pk=alloc_collate(n,0,n_th);
  qlist->condens_pcl=alloc_collate(n,0,n_th);
  qlist->condens_vpk=alloc_collate(DIM3*n,0,DIM3*n_th);
  qlist->condens_vpcl=alloc_collate(DIM3*n,0,DIM3*n_th);
#endif
  qlist->dens_tk=calloc(n,sizeof(double));
  qlist->dens_tcl=calloc(n,sizeof(double));
  qlist->dens_ek=calloc(n,sizeof(double));
  qlist->dens_ecl=calloc(n,sizeof(double));
  qlist->pot_t=alloc_collate(n,0,n_th);
  qlist->pot_e=alloc_collate(n,0,n_th);
  qlist->V1eff_inv=alloc_collate(n,0,n_th);
  qlist->V2eff_inv=alloc_collate(n,0,n_th);
#ifdef POLARIZE
  qlist->polar_0=calloc(DIM3*n,sizeof(double));
  qlist->polar_cl_0=calloc(DIM3*n,sizeof(double));
  qlist->k_polar=calloc(n,sizeof(double));
  qlist->k_polar_cl=calloc(n,sizeof(double));
#endif
  qlist->dGsoftdt_tk=calloc(n,sizeof(double));
  qlist->dGsoftdt_tcl=calloc(n,sizeof(double));
  qlist->dGsoftde_ek=calloc(n,sizeof(double));
  qlist->dGsoftde_ecl=calloc(n,sizeof(double));
  qlist->G=calloc(n,sizeof(double));
  qlist->dGdtk=calloc(n,sizeof(double));
  qlist->dGdtcl=calloc(n,sizeof(double));
  qlist->dGdek=calloc(n,sizeof(double));
  qlist->dGdecl=calloc(n,sizeof(double));
  qlist->dGdtpot=calloc(n,sizeof(double));
  qlist->dGdepot=calloc(n,sizeof(double));
  qlist->dGdV1=calloc(n,sizeof(double));
  qlist->dGdV2=calloc(n,sizeof(double));
#ifdef POLARIZE
  qlist->dGdpk=calloc(n,sizeof(double));
  qlist->dGdpcl=calloc(n,sizeof(double));
  qlist->gGdvpk=calloc(DIM3*n,sizeof(double));
  qlist->gGdvpcl=calloc(DIM3*n,sizeof(double));
#endif

  n=0;
  for (i=0; i<state->N_all; i++) {
    if (state->q[i] != 0) {
      qlist->qlist[n]=i;
      qlist->bP[n] = (n<n_th);
      n++;
    }
  }

  return qlist;
}


void update_qlist(struct_qlist* qlist,struct_state* state)
{
  int i,j;
  for (i=0; i<qlist->nqlist; i++) {
    for (j=0; j<DIM3; j++) {
      qlist->x[DIM3*i+j]=state->x[DIM3*qlist->qlist[i]+j];
    }
  }
}


void free_qlist(struct_qlist* qlist)
{
  free(qlist->qlist);
  free(qlist->x);
  free(qlist->theta);
  free(qlist->theta_cl);
  free(qlist->eta);
  free(qlist->eta_cl);
#ifdef POLARIZE
  free(qlist->polar);
  free(qlist->polar_cl);
#endif
  free(qlist->bP);
  free_collate(qlist->condens_tk);
  free_collate(qlist->condens_tcl);
  free_collate(qlist->condens_ek);
  free_collate(qlist->condens_ecl);
#ifdef POLARIZE
  free_collate(qlist->condens_pk);
  free_collate(qlist->condens_pcl);
  free_collate(qlist->condens_vpk);
  free_collate(qlist->condens_vpcl);
#endif
  free(qlist->dens_tk);
  free(qlist->dens_tcl);
  free(qlist->dens_ek);
  free(qlist->dens_ecl);
  free_collate(qlist->pot_t);
  free_collate(qlist->pot_e);
  free_collate(qlist->V1eff_inv);
  free_collate(qlist->V2eff_inv);
#ifdef POLARIZE
  free(qlist->polar_0);
  free(qlist->polar_cl_0);
  free(qlist->k_polar);
  free(qlist->k_polar_cl);
#endif
  free(qlist->dGsoftdt_tk);
  free(qlist->dGsoftdt_tcl);
  free(qlist->dGsoftde_ek);
  free(qlist->dGsoftde_ecl);
  free(qlist->G);
  free(qlist->dGdtk);
  free(qlist->dGdtcl);
  free(qlist->dGdek);
  free(qlist->dGdecl);
  free(qlist->dGdtpot);
  free(qlist->dGdepot);
  free(qlist->dGdV1);
  free(qlist->dGdV2);
#ifdef POLARIZE
  free(qlist->dGdpk);
  free(qlist->dGdpcl);
  free(qlist->gGdvpk);
  free(qlist->gGdvpcl);
#endif

  free(qlist);
}

