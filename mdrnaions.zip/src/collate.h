#ifndef MD_RNA_IONS_COLLATE_H
#define MD_RNA_IONS_COLLATE_H

/* struct_collate allows data to be stored on NID nodes with openMP. The data is
 * stored in the array local[NID][N]. Only the entries from Ni (inclusive) to Nf
 * (exclusive) are used. The local values may be reset with
 * resetlocal_collate(collate,ID), or may be added together to populate the
 * array master[N] with sumlocal_collate(collate,ID)*/
typedef struct struct_collate
{
  double *master;
  double **local;
  int N;
  int Ni;
  int Nf;
  int NID;
} struct_collate;

struct_collate* alloc_collate(int N,int Ni,int Nf);

double* resetlocal_collate(struct_collate* cl,int ID);

double* sumlocal_collate(struct_collate* cl,int ID);

void free_collate(struct_collate* collate);

#endif

