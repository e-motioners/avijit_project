
#include "state.h"

#include "defines.h"

#include "mersenne.h"
#include "fileio.h"
#include "atoms.h"
#include "parms.h"
#include "qlist.h"
#include "collate.h"
#include "nlist.h"

#include "umbrella.h"

#include <stdio.h>
#include <stdlib.h>

static
void set_masses(struct_atoms* atoms,double m)
{
  int i;

  for (i=0; i<atoms->N; i++) {
    atoms->m[i]=m;
    atoms->msqrt[i]=sqrt(atoms->m[i]);
  }
}


static
void set_velocities(struct_atoms *atoms,struct_mtstate **mtstate,double kT)
{
  int i;
  double nu[2];

  for (i=0; i<atoms->N; i++) {
    rand_normal(nu,mtstate[0]);
    atoms->v[i]=sqrt(kT/atoms->m[i])*nu[0];
  }
}


struct_state* alloc_state(struct_md* md)
{
  struct_state *state;
  int N,Nbuf;
  // int id=0;
  int i;
  int *iitype;
  double **rc2;
  double outputproj;

  state=malloc(sizeof(struct_state));

  state->mtstate=alloc_mtstate(time(NULL)); // CONST

  state->step=0;
  state->walltimeleft=1;
  // state->box[0]=state->box[1]=state->box[2]=boxen[id]; // CONST
  state->box[0]=state->box[1]=state->box[2]=md->parms->arg_box;
  // state->box[0]=state->box[1]=state->box[2]=75; // CONST
  // Count atoms in file
  state->N_rna=read_xyzq(md->parms->arg_xyzqfile,state,0);
  state->N_mg=md->parms->arg_N_mg;
  if (md->parms->flexible) {
    state->N_fixed=0; // CONST // Index of first atom that can move in space.
  } else {
    state->N_fixed=state->N_rna; // CONST // Index of first atom that can move in space.
  }
  state->N_all=state->N_rna+state->N_mg;
  state->N_free=state->N_all-state->N_fixed;
  state->abortflag=0;

  state->x=calloc(state->N_all,DIM3*sizeof(double));
  state->floatx=calloc(state->N_all,DIM3*sizeof(float));
  state->shift=calloc(state->N_all,DIM3*sizeof(double));
  state->q=calloc(state->N_all,sizeof(double));
  state->res_id=calloc(state->N_all,sizeof(int));
  state->res_name=calloc(state->N_all,sizeof(char[5]));
  state->atom_id=calloc(state->N_all,sizeof(int));
  state->atom_name=calloc(state->N_all,sizeof(char[5]));

  // Read atoms in file
  read_gro(md->parms->arg_grofile,state);
  read_xyzq(md->parms->arg_xyzqfile,state,1);
  gen_xyzq(state,0.34,0.56); // CONST - RNA-Mg and Mg-Mg excl vol distance

  state->qqlist=alloc_qlist(state);

  // check outputguard
  outputproj=(4.0*state->N_all+130.0*state->qqlist->nqlist_th)*(md->parms->steplim/md->parms->t_output);
  if (outputproj>md->parms->outputguard) {
    fprintf(stderr,"Fatal error: projected output of %g bytes per MPI process\nis greater than %g byte limit\n",outputproj,md->parms->outputguard);
    fprintf(stderr,"\nIf you are sure this is what you want, set\noutputguard = %g in your mdp file\n",2.0*outputproj);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  } else {
    fprintf(stderr,"Projected output is %g bytes per MPI process\n",outputproj);
  }

  state->Gt=alloc_collate(1,0,1);
  state->Gts=alloc_collate(eE_MAX,0,eE_MAX);
  state->Kt=alloc_collate(1,0,1);

  N=DIM3*state->N_all;
  Nbuf=DIM3*state->N_fixed;
  // BUG
  // state->atoms=alloc_atoms(N,Nbuf,N,&(state->x[DIM3*state->N_fixed]));
  state->atoms=alloc_atoms(N,Nbuf,N,state->x);
  state->atoms->shift=state->shift;
  N=state->qqlist->nqlist;
  Nbuf=state->qqlist->nqlist_th;
  state->manningcc_tk=alloc_atoms(N,0,Nbuf,state->qqlist->theta);
  state->manningcc_tcl=alloc_atoms(N,0,Nbuf,state->qqlist->theta_cl);
  state->manningcc_ek=alloc_atoms(N,0,Nbuf,state->qqlist->eta);
  state->manningcc_ecl=alloc_atoms(N,0,Nbuf,state->qqlist->eta_cl);

  set_masses(state->atoms,1); // CONST
  // fprintf(stderr,"Using pseudo-masses that are 15 amu\n");
  set_masses(state->manningcc_tk,15); // CONST
  set_masses(state->manningcc_tcl,15); // CONST
  set_masses(state->manningcc_ek,15); // CONST
  set_masses(state->manningcc_ecl,15); // CONST
  // // fprintf(stderr,"Using pseudo-masses that aren't 15 amu\n");
  // set_masses(state->manningcc_tk,15*(0.06022/md->parms->conc_K)); // CONST
  // set_masses(state->manningcc_tcl,15*(0.06022/md->parms->conc_Cl)); // CONST
  // set_masses(state->manningcc_ek,15*(0.06022/md->parms->conc_K)); // CONST
  // set_masses(state->manningcc_ecl,15*(0.06022/md->parms->conc_Cl)); // CONST

#ifdef POLARIZE
  state->manningcc_pk=alloc_atoms(DIM3*N,0,DIM3*Nbuf,state->qqlist->polar);
  state->manningcc_pcl=alloc_atoms(DIM3*N,0,DIM3*Nbuf,state->qqlist->polar_cl);

  set_masses(state->manningcc_pk,15); // CONST
  set_masses(state->manningcc_pcl,15); // CONST
#endif

  set_velocities(state->atoms,state->mtstate,md->parms->kTr);

  iitype=calloc(state->qqlist->nqlist,sizeof(int));
  rc2=calloc(1,sizeof(double*));
  rc2[0]=calloc(1,sizeof(double));
  rc2[0][0]=md->parms->rcelec*md->parms->rcelec;
  state->nlelec=alloc_nlist(state->qqlist->nqlist,iitype,rc2);

  // WORKING HERE - put rc2 in parms?
  iitype=calloc(state->N_all,sizeof(int));
  for (i=state->N_rna; i<state->N_all; i++) {
    iitype[i]=1;
  }
  rc2=calloc(2,sizeof(double*));
  rc2[0]=calloc(2,sizeof(double));
  rc2[0][0]=0.7*0.7; // CONST
  // fprintf(stderr,"Warning: using rc=0 for RNA-RNA excluded volume\n");
  // rc2[0][0]=0.0*0.0; // CONST
  rc2[0][1]=1.02*1.02; // CONST
  rc2[1]=calloc(2,sizeof(double));
  rc2[1][0]=1.02*1.02; // CONST
  rc2[1][1]=1.5*1.5; // CONST
  state->nlother=alloc_nlist(state->N_all,iitype,rc2);
  state->umbrella = alloc_umbrella(); // this reads file "umbrella_params"

  return state;
}


void free_state(struct_state* state)
{
  free(state->x);
  free(state->floatx);
  free(state->shift);
  free(state->q);
  free_qlist(state->qqlist);
  free_atoms(state->atoms);
  free_atoms(state->manningcc_tk);
  free_atoms(state->manningcc_tcl);
  free_atoms(state->manningcc_ek);
  free_atoms(state->manningcc_ecl);
  // WORKING HERE
  // WARNING state->nlelec->rc2 and state->nlother->rc2 not freed.
  free_nlist(state->nlelec);
  free_nlist(state->nlother);
  free_mtstate(state->mtstate);
  free(state);
}

