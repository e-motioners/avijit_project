#! /bin/bash -l

make clean

OPTLEVEL="-O3"
# OPTLEVEL="-O0 -g"

if [[ `hostname` == "onuchic1.rice.edu" ]] || [[ `hostname` == "susmita-Precision-T1700" ]]
then
  CC="gcc"
  CFLAGS="-DNOMPI -fopenmp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-fopenmp"
elif [[ `hostname` == "login1.stic.rice.edu" ]] || [[ `hostname` == "login2.stic.rice.edu" ]]
then
  module load intel/2013.1.039
  module load openmpi/1.6.5-intel
  CC="mpicc"
  CFLAGS="-fopenmp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-fopenmp"
elif [[ `hostname` == "bgq-fn.rcsg.rice.edu" ]]
then
  module load xl
  module load mpi/xl
  CC="mpixlc_r -DBGQ"
  CFLAGS="-qsmp=omp -qstrict $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-qsmp=omp"
elif [[ `hostname` == "biou1.rice.edu" ]] || [[ `hostname` == "biou2.rice.edu" ]]
then
  module load ibm
  module load openmpi/1.6.5-ibm
  CC="mpixlc_r -DBIOU"
  CFLAGS="-qsmp=omp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-qsmp=omp"
elif [[ `hostname` == "gollum" ]]
then
  module load Intel/15.x
  module load Openmpi/intel-1.8.4
  CC="mpicc"
  CFLAGS="-fopenmp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-fopenmp"
elif [[ `hostname` == "login1.bird.rice.edu" ]]
then
  module load intel/2015.02
  CC="mpicc"
  CFLAGS="-fopenmp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-fopenmp"
else
  echo "Warning, unrecognized machine, using defaults which may not be appropriate"
  CC="gcc"
  CFLAGS="-DNOMPI -fopenmp $OPTLEVEL"
  LDLIBS="-lm"
  LDFLAGS="-fopenmp"
fi
  
# CFLAGS="-DPOLARIZE $CFLAGS"
# CFLAGS="-DPOLARIZE_NOW $CFLAGS"
# CFLAGS="-DMOHANTY $CFLAGS"
# CFLAGS="-DDEBUG $CFLAGS"
# CFLAGS="-DVIRTUAL $CFLAGS"

export CC CFLAGS LDLIBS LDFLAGS

make
