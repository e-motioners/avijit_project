
// Written to try out different ion condensation competition models

#include "defines.h"

#include "runmd.h"
#include "md.h"
#include "times.h"
#include "parms.h"
#include "leapparms.h"
#include "state.h"
#include "nlist.h"
#include "print.h"
#include "umbrella.h"

#ifndef NOMPI
#include <mpi.h>
#endif
#include <omp.h>
#include <stdlib.h>
#include <stdio.h>




void main(int argc, char *argv[])
{
  struct_md *md;
  gmx_cycles_t start,stop;
  int bool_eq;

  #ifndef NOMPI
  MPI_Init(&argc,&argv);
  #ifdef DEBUG
  arrested_development();
  #endif
  #endif

  fprintf(stderr,"Beginning initialization\n");
  md=alloc_md(argc,argv);
  bool_eq=(readcheckpoint(md)==0);
  printheader(md);
  fprintf(stderr,"Initialization complete\nBeginning equlibration\n");
  start=gmx_cycles_read();

  #pragma omp parallel
  {
    // printmoreheader(md); // Buggy
#ifdef VIRTUAL
    leapfrog_virt(md); // Barrier at end
#endif
    boundaryconditions(md);
    #pragma omp barrier
    neighborsearch(md);
    if (bool_eq) {
      eqtheta(md,md->parms->anneal1lim,md->parms->leapparms_anneal1);
      eqtheta(md,md->parms->anneal2lim,md->parms->leapparms_anneal2);
      resetstep(md); // md->state->step=0;
      resetcumcycles(md);
    }
    #pragma omp master
      fprintf(stderr,"Equlibration complete\nBeginning molecular dynamics\n");
    // #pragma omp master
    // {
    // set_velocities(md->state->manningcc_tk,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_tcl,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_ek,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_ecl,md->state->mtstate,md->parms->kTr);
    // }

     start_umbrella(md) ; // checks existence, contains barrier    

    while (md->state->step < md->parms->steplim && md->state->walltimeleft) {
      if (md->state->step % md->parms->t_ns == 0)
        neighborsearch(md);
      getforce(md);
      if (md->state->step % md->parms->t_output == 0)
        printoutput(md);
      if ((md->state->step+1) % md->parms->t_output == 0)
        checkwalltime(md,start);
      update(md);
    }
    // printmoreheader(md); // Buggy
  }
  fprintf(stderr,"Molecular dynamics complete\nBeginning cleanup\n");

  printsummary(md,start);
  free_md(md);
  fprintf(stderr,"Cleanup complete\n");

  #ifndef NOMPI
  MPI_Finalize();
  #endif
  exit(0);

}
