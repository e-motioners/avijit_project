#ifndef MD_RNA_IONS_TOPOL_H
#define MD_RNA_IONS_TOPOL_H

#include "md.h"
#include "parms.h"

typedef struct struct_bondparms
{
  int i;
  int j;
  double k0;
  double r0;
} struct_bondparms;

typedef struct struct_angleparms
{
  int i;
  int j;
  int k;
  double k0;
  double t0;
} struct_angleparms;

typedef struct struct_dihparms
{
  int i;
  int j;
  int k;
  int l;
  double k0;
  double p0;
  double n;
  double k02;
  double p02;
  double n2;
} struct_dihparms;

typedef struct struct_pair1parms
{
  int i;
  int j;
  double C6;
  double C12;
} struct_pair1parms;

typedef struct struct_pair5parms
{
  int i;
  int j;
  double eps;
  double r0;
  double sigma;
} struct_pair5parms;

typedef struct struct_pair6parms
{
  int i;
  int j;
  double eps;
  double r0;
  double sigma;
  double eps12;
} struct_pair6parms;

typedef struct struct_pair7parms
{
  int i;
  int j;
  double eps;
  double r01;
  double sigma1;
  double r02;
  double sigma2;
  double eps12;
} struct_pair7parms;

typedef struct struct_pair8parms
{
  int i;
  int j;
  double amp;
  double mu;
  double sigma;
} struct_pair8parms;

#ifdef VIRTUAL
typedef struct struct_virt2parms
{
  int v;
  int i;
  int j;
  double Ci;
  double Cj;
} struct_virt2parms;

typedef struct struct_virt3parms
{
  int v;
  int i;
  int j;
  int k;
  double Ci;
  double Cj;
  double Ck;
} struct_virt3parms;
#endif

typedef struct struct_exclparms
{ // i is assumed by index of pointer.
  int *j;
  int N[3];
  int Nmax;
} struct_exclparms;


struct_parms* alloc_topparms(struct_md *md);

void free_topparms(struct_parms *parms);

#endif

