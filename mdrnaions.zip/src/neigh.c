
#include "nlist.h"

#include "defines.h"

#include "gausstables.h"
#include "topol.h"
#include "md.h"
#include "state.h"
#include "parms.h"
#include "qlist.h"
#include "vec.h"

#include <omp.h>
#include <stdlib.h>



struct_nlist* alloc_nlist(int N,int *iitype,double **rc2)
{
  struct_nlist *nlist;
  int i, NID;

  NID=omp_get_max_threads();

  nlist=malloc(sizeof(struct_nlist));
  nlist->iimax=N;
  nlist->ii=calloc(N,sizeof(int));
  nlist->jjmax=calloc(N,sizeof(int));
  nlist->sort=calloc(N,sizeof(struct_sortatom));
  nlist->iitype=iitype;

  nlist->div=calloc(3,sizeof(int));
  nlist->rc2=rc2;

  nlist->jjsize=calloc(N,sizeof(int));
  nlist->jj=calloc(N,sizeof(int*));
  nlist->nldata=calloc(N,sizeof(struct_nldata*));
  nlist->shiftij=calloc(N,sizeof(vec*));
  for (i=0; i<N; i++) {
    nlist->jjsize[i]=20;
    nlist->jj[i]=calloc(nlist->jjsize[i],sizeof(int));
    nlist->nldata[i]=calloc(nlist->jjsize[i],sizeof(struct_nldata));
    nlist->shiftij[i]=calloc(nlist->jjsize[i],sizeof(vec));
  }

  nlist->cycles_sort=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cycles_check=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cycles_force=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_sort=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check1=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check2=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_force=calloc(NID,sizeof(gmx_cycles_t));
  nlist->imin=calloc(NID,sizeof(int));
  nlist->imax=calloc(NID,sizeof(int));
  nlist->imin_f=calloc(NID,sizeof(int));
  nlist->imax_f=calloc(NID,sizeof(int));
  nlist->checklist=calloc(NID,sizeof(int*));
  nlist->shiftlist=calloc(NID,sizeof(vec*));
  for (i=0; i<NID; i++) {
    nlist->cycles_sort[i]=1;
    nlist->cycles_check[i]=1;
    nlist->cycles_force[i]=1;
    nlist->cumcycles_sort[i]=0;
    nlist->cumcycles_check[i]=0;
    nlist->cumcycles_check1[i]=0;
    nlist->cumcycles_check2[i]=0;
    nlist->cumcycles_force[i]=0;
    nlist->imin[i]=(N*i)/NID;
    nlist->imax[i]=(N*(i+1))/NID;
    nlist->imin_f[i]=(N*i)/NID;
    nlist->imax_f[i]=(N*(i+1))/NID;
    nlist->checklist[i]=calloc(N,sizeof(int));
    nlist->shiftlist[i]=calloc(N,sizeof(vec));
  }
  
  return nlist;
}


static
void realloc_nlist(struct_nlist* nlist,int i,int N)
{
  nlist->jjsize[i]=N;
  nlist->jj[i]=realloc(nlist->jj[i],nlist->jjsize[i]*sizeof(int));
  nlist->nldata[i]=realloc(nlist->nldata[i],nlist->jjsize[i]*sizeof(struct_nldata));
  nlist->shiftij[i]=realloc(nlist->shiftij[i],nlist->jjsize[i]*sizeof(vec));
}


void free_nlist(struct_nlist* nlist)
{
  int i,N,NID;

  N=nlist->iimax;
  NID=omp_get_max_threads();

  free(nlist->ii);
  free(nlist->jjmax);
  free(nlist->sort);
  free(nlist->iitype);
  free(nlist->div);
  for (i=0; i<N; i++) {
    free(nlist->jj[i]);
    free(nlist->nldata[i]);
    free(nlist->shiftij[i]);
  }
  free(nlist->jjsize);
  free(nlist->jj);
  free(nlist->nldata);
  free(nlist->shiftij);

  for (i=0; i<NID; i++) {
    free(nlist->checklist[i]);
    free(nlist->shiftlist[i]);
  }
  free(nlist->checklist);
  free(nlist->shiftlist);

  free(nlist->cycles_sort);
  free(nlist->cycles_check);
  free(nlist->cycles_force);
  free(nlist->cumcycles_sort);
  free(nlist->cumcycles_check);
  free(nlist->cumcycles_check1);
  free(nlist->cumcycles_check2);
  free(nlist->cumcycles_force);
  free(nlist->imin);
  free(nlist->imax);

  free(nlist);
}


static
int tree2index(struct_sortatom* node,int* list,int i)
{
  if (node->pless != NULL) {
    i=tree2index(node->pless,list,i);
  }
  list[i]=node->index;
  i++;
  if (node->pmore != NULL) {
    i=tree2index(node->pmore,list,i);
  }
  return i;
}


static
void balancenode(void)
{
  // WORKING HERE
}


static
void neighborbin(struct_nlist* nlist,double rc,int N, double* x,double* box)
{
  int i,j;
  int ID;
  gmx_cycles_t start;
  struct_sortatom *head=NULL;
  struct_sortatom **node;
  struct_sortatom *leaf;
  int compare;

  ID=omp_get_thread_num();

  start=gmx_cycles_read();

  for (i=0; i<DIM3; i++) {
    nlist->div[i]=(int) (box[i]/rc);
  }

  for (i=0; i<N; i++) {
    // Initialize each neighbor
    leaf=&(nlist->sort[i]);
    leaf->index=i;
    for (j=0; j<DIM3; j++) {
      leaf->bin[j]=(int) (nlist->div[j]*x[DIM3*i+j]/box[j]);
    }
    leaf->lbin=((long long) leaf->bin[0]);
    leaf->lbin*=nlist->div[1];
    leaf->lbin+=((long long) leaf->bin[1]);
    leaf->lbin*=nlist->div[2];
    leaf->lbin+=((long long) leaf->bin[2]);
    leaf->pless=NULL;
    leaf->pmore=NULL;
    leaf->nless=0;
    leaf->nmore=0;
    // Sort the neighbors into tree
    node=&head;
    while (*node != NULL) {
      if (leaf->lbin > (*node)->lbin) {
        (*node)->nmore++;
        node=&((*node)->pmore);
      } else if (leaf->lbin < (*node)->lbin) { // compare==-1
        (*node)->nless++;
        node=&((*node)->pless);
      } else if ((*node)->nmore < (*node)->nless) {
        (*node)->nmore++;
        node=&((*node)->pmore);
      } else {
        (*node)->nless++;
        node=&((*node)->pless);
      }
    }
    *node=leaf;
    // WORKING HERE - reorganize tree if it's imbalanced using nmore and nless
  }
  // Use recursive functions to order the tree
  tree2index(head,nlist->ii,0);

  nlist->cycles_sort[ID]+=(gmx_cycles_read()-start);
}


// Find first index for which a bin is >= targbin
// int seekindex(int* ii,struct_sortatom* sort,int N,int* targbin)
static
int seekindex(int* ii,struct_sortatom* sort,int N,int* div,int* targbin)
{
  int i;
  long long currlbin;
  long long targlbin;
  int ibelow=-1;
  int iabove=N;
  int itest;
  int compare;

  targlbin=((long long) targbin[0]);
  targlbin*=div[1];
  targlbin+=((long long) targbin[1]);
  targlbin*=div[2];
  targlbin+=((long long) targbin[2]);
  while (iabove - ibelow > 1) {
    itest=ibelow+(iabove-ibelow)/2;
    currlbin=sort[ii[itest]].lbin;
    if (currlbin >= targlbin) {
      // search below
      iabove=itest;
    } else {
      // search above
      ibelow=itest;
    }
  }
  return iabove;
}


static
int addtochecklist(int* checklist,int nchecklist,vec* shiftlist,vec shift,int* ii,int first,int last)
{
  int i;
  for (i=first; i<last; i++) {
    checklist[nchecklist]=ii[i];
    vec_copy(shiftlist[nchecklist],shift);
    nchecklist++;
  }
  return nchecklist;
}


static
int checkexcl(struct_exclparms *excl,int i,int j,int flexible)
{
  if (flexible) {
    int a;
    if (excl != NULL) {
      for (a=0; a<excl[i].N[2]; a++) {
        if (j==excl[i].j[a]) {
          return 0;
        }
      }
    }
    return 1;
  } else {
    return 1;
  }
}


// void screenchecklist(int i,int* jjlist,int njjlist,struct_nlist* nlist,double rc2,int N,double* x,double* box)
// void screenchecklist(int i,int* jjlist,int njjlist,vec* jjshift,struct_nlist* nlist,int N,double* x,double* box)
static
void screenchecklist(int i,int* jjlist,int njjlist,vec* jjshift,struct_nlist* nlist,struct_exclparms *excl,int N,double* x,double* box,int flexible)
{
  int ii,j,jj,jjmax;
  // double *shiftij;
  double *rc2;
  vec dr;

  if (njjlist > nlist->jjsize[i]) {
    realloc_nlist(nlist,i,njjlist);
  }

  ii=nlist->ii[i];
  rc2=nlist->rc2[nlist->iitype[ii]];
  jjmax=0;
  for (j=0; j<njjlist; j++) {
    jj=jjlist[j];
    // shiftij=nlist->shiftij[jjind];
    
    // vec_subsaveshift(x+DIM3*ii,x+DIM3*jj,box,shiftij,dr);
    // vec_subquick(x+DIM3*ii,x+DIM3*jj,box,dr);
    // if (vec_mag2(dr)<=rc2[nlist->iitype[jj]]) {
    // assert( (vec_quickdist2(x+DIM3*ii,x+DIM3*jj,box)<=rc2[nlist->iitype[jj]]) == (vec_shiftdist2(x+DIM3*ii,x+DIM3*jj,jjshift[j])<=rc2[nlist->iitype[jj]]) );
    if (vec_shiftdist2(x+DIM3*ii,x+DIM3*jj,jjshift[j])<=rc2[nlist->iitype[jj]]) {
      if (checkexcl(excl,ii,jj,flexible)) {
      nlist->jj[i][jjmax]=jj;
      vec_copy(nlist->shiftij[i][jjmax],jjshift[j]);
      jjmax++;
      }
    }
  }
  nlist->jjmax[i]=jjmax;
}


static
void neighborcheck(struct_nlist* nlist,struct_exclparms *excl,double rc,int N, double* x,double* box,int flexible)
{
  int ID;
  int *checklist;
  vec *shiftlist;
  double rc2=rc*rc;
  int *div;
  int sbuf;
  int i,j,k;
  int currbin[3],targbin[13][3];
  vec targshift[13];
  vec nullshift={0,0,0};
  int first,last;
  int nchecklist;
  gmx_cycles_t start,stop;
  gmx_cycles_t start_t1,start_t2;

  ID=omp_get_thread_num();
  checklist=nlist->checklist[ID];
  shiftlist=nlist->shiftlist[ID];
  div=nlist->div;

  start=gmx_cycles_read();

  i=nlist->imin[ID];
  nchecklist=0;

  // Set up any other leftovers from earlier in this bin
  ivec_copy(currbin,nlist->sort[nlist->ii[i]].bin);
  first=seekindex(nlist->ii,nlist->sort,N,div,currbin);
  nchecklist=addtochecklist(checklist,nchecklist,shiftlist,nullshift,nlist->ii,first,i);

  while (i<nlist->imax[ID]) {
    start_t1=gmx_cycles_read();
    // copy box index, and indices of 13 boxes to search
    ivec_copy(currbin,nlist->sort[nlist->ii[i]].bin);
    for (j=0; j<13; j++)
      ivec_copy(targbin[j],currbin);
    for (j=0; j<9; j++)
      targbin[j][0]++;
    for (j=0; j<3; j++) {
      targbin[j  ][1]++;
      targbin[j+6][1]--;
      targbin[j+9][1]++;
    }
    for (j=0; j<13; j+=3)
      targbin[j][2]++;
    for (j=2; j<13; j+=3)
      targbin[j][2]--;
    for (j=0; j<13; j++) {
      for (k=0; k<DIM3; k++) {
        sbuf=1-((targbin[j][k]+div[k])/div[k]);
        targbin[j][k]+=div[k]*sbuf;
        targshift[j][k]=box[k]*sbuf;
      }
    }

    // use seekindex again to find bounds of atoms in box and add to checklist
    for (j=0; j<13; j++) {
      first=seekindex(nlist->ii,nlist->sort,N,div,targbin[j]);
      targbin[j][2]++;
      last=seekindex(nlist->ii,nlist->sort,N,div,targbin[j]);
      nchecklist=addtochecklist(checklist,nchecklist,shiftlist,targshift[j],nlist->ii,first,last);
    }
    nlist->cumcycles_check1[ID]+=(gmx_cycles_read()-start_t1);
    // check all atoms on checklist checklist
    start_t2=gmx_cycles_read();
    while (i<nlist->imax[ID] && ivec_eq(currbin,nlist->sort[nlist->ii[i]].bin)) {
      screenchecklist(i,checklist,nchecklist,shiftlist,nlist,excl,N,x,box,flexible);
      nchecklist=addtochecklist(checklist,nchecklist,shiftlist,nullshift,nlist->ii,i,i+1);
      i++;
    }
    nchecklist=0;
    nlist->cumcycles_check2[ID]+=(gmx_cycles_read()-start_t2);
  }

  stop=gmx_cycles_read();
  nlist->cycles_check[ID]+=(stop-start);
}


static
void loadbalance(struct_nlist* nlist)
{
  int i,NID;
  gmx_cycles_t cycles_prev,cycles;
  int boundary;

  NID=omp_get_max_threads();

  for (i=1;i<NID;i++) {
    cycles_prev=nlist->cycles_check[i-1];
    nlist->cumcycles_sort[i-1]+=nlist->cycles_sort[i-1];
    nlist->cumcycles_check[i-1]+=nlist->cycles_check[i-1];
    nlist->cycles_sort[i-1]=0;
    nlist->cycles_check[i-1]=0;

    cycles=nlist->cycles_check[i];
    boundary=nlist->imin[i];
    if (cycles < cycles_prev && boundary > nlist->imin[i-1]) {
      boundary--;
    } else if (cycles > cycles_prev && boundary < nlist->imax[i]) {
      boundary++;
    }
    nlist->imin[i]=boundary;
    nlist->imax[i-1]=boundary;
  }
  nlist->cumcycles_sort[NID-1]+=nlist->cycles_sort[NID-1];
  nlist->cumcycles_check[NID-1]+=nlist->cycles_check[NID-1];
  nlist->cycles_sort[NID-1]=0;
  nlist->cycles_check[NID-1]=0;
}


static
void reset_shifts(struct_md* md)
{
  int i,j;
  for (i=0; i<md->state->N_all; i++) {
    for (j=0; j<DIM3; j++) {
      md->state->shift[DIM3*i+j]=0;
    }
  }
}


void neighborsearch(struct_md* md)
{
#pragma omp master
  md->times->start=gmx_cycles_read();
#pragma omp sections
  {
#pragma omp section
  reset_shifts(md);
#pragma omp section
  {
  update_qlist(md->state->qqlist,md->state);
  neighborbin(md->state->nlelec,md->parms->rcelec,
    md->state->qqlist->nqlist,md->state->qqlist->x,md->state->box);
  }
#pragma omp section
  neighborbin(md->state->nlother,md->parms->rcother,
    md->state->N_all,md->state->x,md->state->box);
#pragma omp section
  loadbalance(md->state->nlelec);
#pragma omp section
  loadbalance(md->state->nlother);
  }
  // There is an implied barrier at the end of a SECTIONS directive, unless the NOWAIT/nowait clause is used

  neighborcheck(md->state->nlelec,NULL,md->parms->rcelec,
    md->state->qqlist->nqlist,md->state->qqlist->x,md->state->box,md->parms->flexible);

  neighborcheck(md->state->nlother,md->parms->exclparms,md->parms->rcother,
    md->state->N_all,md->state->x,md->state->box,md->parms->flexible);

#pragma omp master
  md->times->nsearch+=(gmx_cycles_read()-md->times->start);
#pragma omp barrier
}

