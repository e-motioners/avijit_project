#ifndef MD_RNA_IONS_ATOMS_H
#define MD_RNA_IONS_ATOMS_H

struct struct_collate;

typedef struct struct_atoms
{
  double N; // Number of coordinates, 3 times number of atoms
  double Ni; // atoms before this are frozen
  double Nf; // This and later atoms are frozen
  double *x;
  double *shift;
  double *v;
  double *vhalf;
  struct struct_collate *f;
  double *m;
  double *msqrt;
  double *Vs_delay;
} struct_atoms;

struct_atoms* alloc_atoms(int N,int Ni,int Nf,double* x);

void free_atoms(struct_atoms* atoms);

#endif

