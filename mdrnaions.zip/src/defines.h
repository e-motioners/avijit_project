#ifndef MD_RNA_IONS_DEFINES_H
#define MD_RNA_IONS_DEFINES_H


#define MAXLENGTH 4096
// 1 Molar in nm^-3
#define MOLAR 0.6022
#define DIM3 3
#define M_SQRT8PI3 sqrt(8*M_PI*M_PI*M_PI)


#endif

