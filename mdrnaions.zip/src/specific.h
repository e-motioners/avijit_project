#ifndef MD_RNA_ION_SPECIFIC_H
#define MD_RNA_ION_SPECIFIC_H

#include "md.h"

void getforce_bond(struct_md* md);

void getforce_angle(struct_md* md);

void getforce_dih(struct_md* md);

void getforce_pair1(struct_md* md);

void getforce_pair5(struct_md* md);

void getforce_pair6(struct_md* md);

void getforce_pair7(struct_md* md);

void getforce_pair8(struct_md* md);

#ifdef VIRTUAL
void getforce_virt2(struct_md* md);

void getforce_virt3(struct_md* md);
#endif

#endif
