
#include "specific.h"

#include "defines.h"

#include "md.h"
#include "topol.h"
#include "state.h"
#include "parms.h"
#include "atoms.h"
#include "collate.h"
#include "vec.h"

#include <omp.h>
#include <math.h>



void getforce_bond(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_bondparms *bondparms=md->parms->bondparms;
  double k0,r0;
  double r;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_bond * ID)/NID;
  imax=(md->parms->N_bond * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=bondparms[i].i;
    jj=bondparms[i].j;
    k0=bondparms[i].k0;
    r0=bondparms[i].r0;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    Gt+=0.5*k0*(r-r0)*(r-r0);
    // assert((k0*(r-r0)/r)>-1e6);
    // assert(f[DIM3*ii]>-1e30);
    vec_scaleinc(f+DIM3*ii,-k0*(r-r0)/r,dr);
    vec_scaleinc(f+DIM3*jj, k0*(r-r0)/r,dr);
    // assert(f[DIM3*jj]>-1e30);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_bond]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_bond+=(gmx_cycles_read()-start);
}


void getforce_angle(struct_md* md)
{
  int i,j,ii,jj,kk,imin,imax;
  struct_angleparms *angleparms=md->parms->angleparms;
  double k0,t0;
  double rij,rkj;
  vec drij,drkj;
  double dt,cost,fsint,fsincost;
  vec fi,fj,fk;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_angle * ID)/NID;
  imax=(md->parms->N_angle * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=angleparms[i].i;
    jj=angleparms[i].j;
    kk=angleparms[i].k;
    k0=angleparms[i].k0;
    t0=angleparms[i].t0;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,drij);
    rij=vec_mag(drij);
    vec_subquick(x+DIM3*kk,x+DIM3*jj,md->state->box,drkj);
    rkj=vec_mag(drkj);
    cost=vec_dot(drij,drkj)/(rij*rkj);
    dt=acos(cost)-t0;
    Gt+=0.5*k0*dt*dt;
    // if (cost<1) { // Avoid NaN
      fsint=k0*dt/sqrt(1-cost*cost); // Negatives cancel
      fsincost=fsint*cost;
      for (j=0; j<DIM3; j++) {
        fi[j]=drkj[j]*(fsint/(rij*rkj))-drij[j]*(fsincost/(rij*rij));
        fk[j]=drij[j]*(fsint/(rij*rkj))-drkj[j]*(fsincost/(rkj*rkj));
        fj[j]=-fi[j]-fk[j];
        // assert(fi[j]>-1e6);
        // assert(fk[j]>-1e6);
      }
      vec_inc(f+DIM3*ii,fi);
      vec_inc(f+DIM3*jj,fj);
      vec_inc(f+DIM3*kk,fk);
    // }
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_angle]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_angle+=(gmx_cycles_read()-start);
}


void getforce_dih(struct_md* md)
{
  int i,j,ii,jj,kk,ll,imin,imax;
  struct_dihparms *dihparms=md->parms->dihparms;
  double k0,p0,n;
  double k02,p02,n2;
  double rij,rjk,rkl;
  vec drij,drjk,drkl;
  vec mvec,nvec,uvec,vvec,svec;
  double phi,sign,ipr,dp,dGdp;
  double cosp,sinp;
  vec dsinp;
  // double mmag,nmag;
  double mmag2,nmag2;
  double a,b,p,q;
  vec fi,fj,fk,fl;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_dih * ID)/NID;
  imax=(md->parms->N_dih * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=dihparms[i].i;
    jj=dihparms[i].j;
    kk=dihparms[i].k;
    ll=dihparms[i].l;
    k0=dihparms[i].k0;
    p0=dihparms[i].p0;
    n=dihparms[i].n;
    k02=dihparms[i].k02;
    p02=dihparms[i].p02;
    n2=dihparms[i].n2;
/* GROMACS
// inside dih_angle
    *t1 = pbc_rvec_sub(pbc, xi, xj, r_ij);
    *t2 = pbc_rvec_sub(pbc, xk, xj, r_kj);
    *t3 = pbc_rvec_sub(pbc, xk, xl, r_kl);

    cprod(r_ij, r_kj, m);
    cprod(r_kj, r_kl, n);
    phi     = gmx_angle(m, n);
    ipr     = iprod(r_ij, n);
    (*sign) = (ipr < 0.0) ? -1.0 : 1.0;
    phi     = (*sign)*phi;

// inside dih_do_fup
    iprm  = iprod(m, m);
    iprn  = iprod(n, n);
    nrkj2 = iprod(r_kj, r_kj);
    toler = nrkj2*GMX_REAL_EPS;
    if ((iprm > toler) && (iprn > toler))
    {
        nrkj_1 = gmx_invsqrt(nrkj2);
        nrkj_2 = nrkj_1*nrkj_1;
        nrkj   = nrkj2*nrkj_1;
        a      = -ddphi*nrkj/iprm;
        svmul(a, m, f_i);
        b     = ddphi*nrkj/iprn;
        svmul(b, n, f_l);
        p     = iprod(r_ij, r_kj);
        p    *= nrkj_2;
        q     = iprod(r_kl, r_kj);
        q    *= nrkj_2;
        svmul(p, f_i, uvec);
        svmul(q, f_l, vvec);
        rvec_sub(uvec, vvec, svec);
        rvec_sub(f_i, svec, f_j);
        rvec_add(f_l, svec, f_k);
        rvec_inc(f[i], f_i);
        rvec_dec(f[j], f_j);
        rvec_dec(f[k], f_k);
        rvec_inc(f[l], f_l);
    }
*/

    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,drij);
    vec_subquick(x+DIM3*jj,x+DIM3*kk,md->state->box,drjk);
    vec_subquick(x+DIM3*kk,x+DIM3*ll,md->state->box,drkl);
    vec_cross(drij,drjk,mvec);
    vec_cross(drjk,drkl,nvec);
    // mmag=vec_mag(mvec);
    // nmag=vec_mag(nvec);
    // phi=acos(vec_dot(mvec,nvec)/(mmag*nmag)); // Need sign still
    // Use gmx_angle style instead, acos is unstable
    vec_cross(mvec,nvec,dsinp);
    sinp=vec_mag(dsinp);
    cosp=vec_dot(mvec,nvec);
    phi=atan2(sinp,cosp);
    ipr=vec_dot(drij,nvec);
    sign=(ipr > 0.0) ? -1.0 : 1.0; // Opposite of gromacs because m and n are opposite
    phi=sign*phi;

    if (n==0) {
      dp=phi-p0;
      dp-=(2*M_PI)*floor((dp+M_PI)/(2*M_PI));
      // if (i==36) {
      //  fprintf(stderr,"%5d %5d %5d %5d %g %g\n",ii,jj,kk,ll,phi,dp);
      // }
      Gt+=0.5*k0*dp*dp;
      // assert(0.5*k0*dp*dp>-1e6);
      dGdp=k0*dp;
    } else {
      dp=n*phi-p0;
      Gt+=k0*cos(dp);
      dGdp=-k0*n*sin(dp);
      // Second dihedral if appropriate
      if (n2 != 0) {
        dp=n2*phi-p02;
        Gt+=k02*cos(dp);
        dGdp+=-k02*n2*sin(dp);
      }
      // assert(k0*cos(dp)>-1e6);
    }

    mmag2=vec_mag2(mvec);
    nmag2=vec_mag2(nvec);
    rjk=vec_mag(drjk);
    // a=-dGdp*rjk/(mmag*mmag);
    // a=dGdp*rjk/(mmag*mmag);
    a=dGdp*rjk/mmag2;
    vec_scale(fi,a,mvec);
    // b=dGdp*rjk/(nmag*nmag);
    // b=-dGdp*rjk/(nmag*nmag);
    b=-dGdp*rjk/nmag2;
    vec_scale(fl,b,nvec);
    p=-vec_dot(drij,drjk)/(rjk*rjk);
    q=-vec_dot(drkl,drjk)/(rjk*rjk);
    vec_scale(uvec,p,fi);
    vec_scale(vvec,q,fl);
    vec_subtract(uvec,vvec,svec);
    vec_subtract(fi,svec,fj);
    vec__add(fl,svec,fk);

    vec_inc(f+DIM3*ii,fi);
    vec_scaleinc(f+DIM3*jj,-1,fj);
    vec_scaleinc(f+DIM3*kk,-1,fk);
    vec_inc(f+DIM3*ll,fl);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_dihedral]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_dih+=(gmx_cycles_read()-start);
}


void getforce_pair1(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_pair1parms *pair1parms=md->parms->pair1parms;
  double C6,C12;
  double r2,r6,r12;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair1 * ID)/NID;
  imax=(md->parms->N_pair1 * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=pair1parms[i].i;
    jj=pair1parms[i].j;
    C6=pair1parms[i].C6;
    C12=pair1parms[i].C12;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r2=vec_mag2(dr);
    r6=r2*r2*r2;
    r12=r6*r6;
    Gt+=C12/r12-C6/r6;
    // assert(((12*(C12/r12)/r2-6*(C6/r6)/r2))>-1e6);
    // assert(f[DIM3*ii]>-1e30);
    vec_scaleinc(f+DIM3*ii, (12*(C12/r12)/r2-6*(C6/r6)/r2),dr);
    vec_scaleinc(f+DIM3*jj,-(12*(C12/r12)/r2-6*(C6/r6)/r2),dr);
    // assert(f[DIM3*ii]>-1e30);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_pair1]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_pair+=(gmx_cycles_read()-start);
}


void getforce_pair5(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_pair5parms *pair5parms=md->parms->pair5parms;
  double eps,r0,sigma;
  double r,r2;
  double Gauss,fGauss;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair5 * ID)/NID;
  imax=(md->parms->N_pair5 * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=pair5parms[i].i;
    jj=pair5parms[i].j;
    eps=pair5parms[i].eps;
    r0=pair5parms[i].r0;
    sigma=pair5parms[i].sigma;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    r2=r*r;
    Gauss=-eps*exp(-0.5*((r-r0)*(r-r0))/(sigma*sigma));
    if (r0==0) {
      fGauss=Gauss/(sigma*sigma);
    } else {
      fGauss=((r-r0)/r)*Gauss/(sigma*sigma);
    }
    Gt+=Gauss;
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
    vec_scaleinc(f+DIM3*ii, fGauss,dr);
    vec_scaleinc(f+DIM3*jj,-fGauss,dr);
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_pair5]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_pair+=(gmx_cycles_read()-start);
}


void getforce_pair6(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_pair6parms *pair6parms=md->parms->pair6parms;
  double eps,r0,sigma,eps12;
  double r,r2,r6,r12;
  double Repel,Gauss,fRepel,fGauss;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair6 * ID)/NID;
  imax=(md->parms->N_pair6 * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=pair6parms[i].i;
    jj=pair6parms[i].j;
    eps=pair6parms[i].eps;
    r0=pair6parms[i].r0;
    sigma=pair6parms[i].sigma;
    eps12=pair6parms[i].eps12;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    r2=r*r;
    r6=r2*r2*r2;
    r12=r6*r6;
    Repel=eps12/r12;
    fRepel=12.0*Repel/r2;
    Gauss=exp(-0.5*((r-r0)*(r-r0))/(sigma*sigma));
    fGauss=((r-r0)/r)*Gauss/(sigma*sigma);
    Gt+=Repel-eps*Gauss-Repel*Gauss;
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
    vec_scaleinc(f+DIM3*ii, (fRepel*(1-Gauss)-(eps+Repel)*fGauss),dr);
    vec_scaleinc(f+DIM3*jj,-(fRepel*(1-Gauss)-(eps+Repel)*fGauss),dr);
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_pair6]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_pair+=(gmx_cycles_read()-start);
}


void getforce_pair7(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_pair7parms *pair7parms=md->parms->pair7parms;
  double eps,r01,sigma1,r02,sigma2,eps12;
  double r,r2,r6,r12;
  double R, F, G ;
  double AF, AG, AFG, FR, GR, FGR ;
  double ffac, gfac, rfac ;
  double fval ;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair7 * ID)/NID;
  imax=(md->parms->N_pair7 * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=pair7parms[i].i;
    jj=pair7parms[i].j;
    eps=pair7parms[i].eps;
    r01=pair7parms[i].r01;
    sigma1=pair7parms[i].sigma1;
    r02=pair7parms[i].r02;
    sigma2=pair7parms[i].sigma2;
    eps12=pair7parms[i].eps12;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    r2=r*r;
    r6=r2*r2*r2;
    r12=r6*r6;
    R = eps12/r12;
    F = exp( -0.5*((r-r01)*(r-r01))/(sigma1*sigma1) );
    G = exp( -0.5*((r-r02)*(r-r02))/(sigma2*sigma2) );

    AF  = eps * F;
    AG  = eps * G;
    AFG = AF * G;
    FR  = F * R;
    GR  = G * R;
    FGR = F * GR;

    ffac = -(r-r01) / (sigma1*sigma1);
    gfac = -(r-r02) / (sigma2*sigma2);
    rfac = -12.0 / r;

    fval = ffac * AF + gfac * AG - ( ffac + gfac ) * AFG  \
         + ( ffac + rfac ) * FR + ( gfac + rfac ) * GR    \
         - ( ffac + gfac + rfac ) * FGR - rfac * R;
    fval /= r ;

    Gt += AFG - AF - AG + FGR - FR - GR + R;
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
    vec_scaleinc(f+DIM3*ii, (fval),dr);
    vec_scaleinc(f+DIM3*jj,-(fval),dr);
    // assert(f[DIM3*ii]>-1e4);
    // assert(f[DIM3*ii]<1e4);
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_pair7]+=Gt;
  // gmx_cycles_t start;
  // #pragma omp master
  //   start=gmx_cycles_read();
  #pragma omp master
    md->times->force_pair+=(gmx_cycles_read()-start);
}


#ifdef VIRTUAL
void getforce_virt2(struct_md* md)
{
  int i,vv,ii,jj; //,imin,imax;
  struct_virt2parms *virt2parms=md->parms->virt2parms;
  double Ci,Cj;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  // NID=omp_get_max_threads();
  // imin=(md->parms->N_pair * ID)/NID;
  // imax=(md->parms->N_pair * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  // for (i=imin; i<imax; i++) {
  for (i=0; i<md->parms->N_virt2; i++) {
    vv=virt2parms[i].v;
    ii=virt2parms[i].i;
    jj=virt2parms[i].j;
    Ci=virt2parms[i].Ci;
    Cj=virt2parms[i].Cj;
    vec_scaleinc(f+DIM3*ii,Ci,f+DIM3*vv);
    vec_scaleinc(f+DIM3*jj,Cj,f+DIM3*vv);
    // assert(f[DIM3*ii]>-1e30);
    // assert(f[DIM3*jj]>-1e30);
  }

  #pragma omp master
    md->times->force_virtual+=(gmx_cycles_read()-start);
}


void getforce_virt3(struct_md* md)
{
  int i,vv,ii,jj,kk; //,imin,imax;
  struct_virt3parms *virt3parms=md->parms->virt3parms;
  double Ci,Cj,Ck;
  double *f;
  int ID,NID;
  gmx_cycles_t start;
  #pragma omp master
    start=gmx_cycles_read();
  
  ID=omp_get_thread_num();
  // NID=omp_get_max_threads();
  // imin=(md->parms->N_pair * ID)/NID;
  // imax=(md->parms->N_pair * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  // for (i=imin; i<imax; i++) {
  for (i=0; i<md->parms->N_virt3; i++) {
    vv=virt3parms[i].v;
    ii=virt3parms[i].i;
    jj=virt3parms[i].j;
    kk=virt3parms[i].k;
    Ci=virt3parms[i].Ci;
    Cj=virt3parms[i].Cj;
    Ck=virt3parms[i].Ck;
    vec_scaleinc(f+DIM3*ii,Ci,f+DIM3*vv);
    vec_scaleinc(f+DIM3*jj,Cj,f+DIM3*vv);
    vec_scaleinc(f+DIM3*kk,Ck,f+DIM3*vv);
    // assert(f[DIM3*ii]>-1e30);
    // assert(f[DIM3*jj]>-1e30);
    // assert(f[DIM3*kk]>-1e30);
  }

  #pragma omp master
    md->times->force_virtual+=(gmx_cycles_read()-start);
}
#endif

