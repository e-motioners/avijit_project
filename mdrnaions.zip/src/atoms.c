
#include "atoms.h"

#include "defines.h"

#include "collate.h"

#include <stdlib.h>

struct_atoms* alloc_atoms(int N,int Ni,int Nf,double* x)
{
  struct_atoms *atoms;

  atoms=malloc(sizeof(struct_atoms));

  atoms->N=N;
  atoms->Ni=Ni;
  atoms->Nf=Nf;
  atoms->x=x;
  atoms->f=alloc_collate(N,Ni,Nf);
  atoms->v=calloc(N,sizeof(double));
  atoms->vhalf=calloc(N,sizeof(double));
  atoms->m=calloc(N,sizeof(double));
  atoms->msqrt=calloc(N,sizeof(double));
  atoms->Vs_delay=calloc(N,sizeof(double));

  return atoms;
}


void free_atoms(struct_atoms* atoms)
{
  free_collate(atoms->f);
  free(atoms->v);
  free(atoms->vhalf);
  free(atoms->m);
  free(atoms->msqrt);
  free(atoms->Vs_delay);
  free(atoms);
}

