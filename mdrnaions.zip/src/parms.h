#ifndef MD_RNA_IONS_PARMS_H
#define MD_RNA_IONS_PARMS_H


#include "times.h"

struct struct_tables;
struct struct_leapparms;
struct struct_bondparms;
struct struct_angleparms;
struct struct_dihparms;
struct struct_pair1parms;
struct struct_pair5parms;
struct struct_pair6parms;
struct struct_pair7parms;
struct struct_pair8parms;
#ifdef VIRTUAL
struct struct_virt2parms;
struct struct_virt3parms;
#endif
struct struct_exclparms;

typedef struct struct_parms
{
  int id;
  int offset;
  int phase;
  double maxh;
  gmx_cycles_t maxc;
  int flexible; // boolean flag
  double kB;
  double kT;
  double kTr;
  double kT0;
  double kTr0;
  double lB;
  double conc_KCl;
  double conc_K;
  double conc_Cl;
  int arg_N_mg;
  double arg_box;
  char *arg_topfile;
  char *arg_xyzqfile;
  char *arg_grofile;
  char *arg_outdir;
#ifdef VIRTUAL
  char *arg_ndxfile;
#endif
  int trajfmt; // 0 is gro file, 1 is xtc
  double outputguard; // approximate output limit for each MPI process
  double kappa;
  double gauss_00;
  double gauss_01;
  double gauss_02;
  double gauss_11;
  double gauss_12;
  double gauss_22;
  double V1;
  double V2;
  double k_prohibit;
  double k_soft;
  double rcelec;
  struct struct_tables *elec_tables;
  double k12;
  double s2[2][2];
  double rcother;
  int t_output;
  int t_ns;
  int anneal1lim;
  int anneal2lim;
  int steplim;
  double dt;
  struct struct_leapparms *leapparms;
  struct struct_leapparms *leapparms_anneal1;
  struct struct_leapparms *leapparms_anneal2;
  struct struct_leapparms *leapparms_mcc;
  int N_bond;
  int N_angle;
  int N_dih;
  int N_pair1;
  int N_pair5;
  int N_pair6;
  int N_pair7;
  int N_pair8;
#ifdef VIRTUAL
  int N_virt2;
  int N_virt3;
#endif
  int N_excl;
  struct struct_bondparms *bondparms;
  struct struct_angleparms *angleparms;
  struct struct_dihparms *dihparms;
  struct struct_pair1parms *pair1parms;
  struct struct_pair5parms *pair5parms;
  struct struct_pair6parms *pair6parms;
  struct struct_pair7parms *pair7parms;
  struct struct_pair8parms *pair8parms;
  struct struct_umbrella *umbrella;
#ifdef VIRTUAL
  struct struct_virt2parms *virt2parms;
  struct struct_virt3parms *virt3parms;
#endif
  struct struct_exclparms *exclparms;
#ifdef VIRTUAL
  int *groupndx;
#endif
} struct_parms;

struct_parms* alloc_parms(int argc, char *argv[]);

void free_parms(struct_parms* parms);

#endif

