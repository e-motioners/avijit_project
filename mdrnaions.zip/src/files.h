#ifndef MD_RNA_IONS_FILES_H
#define MD_RNA_IONS_FILES_H

#include "xdr/xdrfile.h"

#include <stdio.h>

typedef enum {
  eF_log,
  eF_gro,
//  eF_xtc,
  eF_theta,
  eF_theta_cl,
  eF_eta,
  eF_eta_cl,
#ifdef POLARIZE
  eF_polar,
  eF_polar_cl,
  eF_k_pk,
  eF_k_pcl,
#endif
  eF_Gt,
  eF_Gts,
  eF_Kt,
  eF_pot_t,
  eF_pot_e,
  eF_dens_tk,
  eF_dens_tcl,
  eF_dens_ek,
  eF_dens_ecl,
  eF_V1eff_inv,
  eF_V2eff_inv,
  eF_Q,
  eF_EQ,
//  eF_loclog,
//  eF_locend=eF_loclog+7,
// Example usage:
// fprintf(md->files->fps[eF_loclog+omp_get_thread_num()],"Node %d, step %d, cycle %lld, before barrier, line %d\n",omp_get_thread_num(),md->state->step,gmx_cycles_read(),__LINE__);
  eF_MAX
} eFILE;

typedef struct struct_files
{
  FILE **fps;
  XDRFILE *xtc;
  int N;
} struct_files;

struct_files* alloc_files(void);

void free_files(struct_files* files);

#endif

