#ifndef MD_RNA_IONS_FORCE_H
#define MD_RNA_IONS_FORCE_H

#include "md.h"

#include "defines.h"

void getforce(struct_md* md);

#endif

