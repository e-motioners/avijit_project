
#include "checkpt.h"

#include "defines.h"

#include "md.h"
#include "atoms.h"
#include "files.h"
#include "parms.h"
#include "state.h"

#include <stdio.h>

void printcheckpoint(struct_md *md)
{
  FILE *fp;
  char fnm[MAXLENGTH];
  struct_atoms *atoms;

  sprintf(fnm,"%s/state.%d.%d.cpt",md->parms->arg_outdir,md->parms->id,md->parms->phase);
  fp=fopen(fnm,"w");
  fprintf(md->files->fps[eF_log],"Writing checkpoint file %s\n",fnm);

  fwrite(&(md->state->step),sizeof(int),1,fp);
  
  atoms=md->state->atoms;
  fwrite(atoms->x,sizeof(double),atoms->N,fp);
  fwrite(atoms->v,sizeof(double),atoms->N,fp);
  fwrite(atoms->Vs_delay,sizeof(double),atoms->N,fp);
  
  atoms=md->state->manningcc_tk;
  fwrite(atoms->x,sizeof(double),atoms->N,fp);
  fwrite(atoms->v,sizeof(double),atoms->N,fp);
  fwrite(atoms->Vs_delay,sizeof(double),atoms->N,fp);

  atoms=md->state->manningcc_tcl;
  fwrite(atoms->x,sizeof(double),atoms->N,fp);
  fwrite(atoms->v,sizeof(double),atoms->N,fp);
  fwrite(atoms->Vs_delay,sizeof(double),atoms->N,fp);

  atoms=md->state->manningcc_ek;
  fwrite(atoms->x,sizeof(double),atoms->N,fp);
  fwrite(atoms->v,sizeof(double),atoms->N,fp);
  fwrite(atoms->Vs_delay,sizeof(double),atoms->N,fp);

  atoms=md->state->manningcc_ecl;
  fwrite(atoms->x,sizeof(double),atoms->N,fp);
  fwrite(atoms->v,sizeof(double),atoms->N,fp);
  fwrite(atoms->Vs_delay,sizeof(double),atoms->N,fp);

  fclose(fp);
}


int readcheckpoint(struct_md *md)
{
  FILE *fp;
  char fnm[MAXLENGTH];
  struct_atoms *atoms;
  
  md->parms->phase=0;
  sprintf(fnm,"%s/state.%d.%d.cpt",md->parms->arg_outdir,md->parms->id,md->parms->phase);
  fp=fopen(fnm,"r");
  while(fp != NULL) {
    fclose(fp);
    md->parms->phase++;
    sprintf(fnm,"%s/state.%d.%d.cpt",md->parms->arg_outdir,md->parms->id,md->parms->phase);
    fp=fopen(fnm,"r");
  }

  if (md->parms->phase>0) {
    sprintf(fnm,"%s/state.%d.%d.cpt",md->parms->arg_outdir,md->parms->id,md->parms->phase-1);
    fp=fopen(fnm,"r");
    // fprintf(md->files->fps[eF_log],"Reading checkpoint file %s\n",fnm);
    fprintf(stderr,"Reading checkpoint file %s\n",fnm);

    fread(&(md->state->step),sizeof(int),1,fp);
  
    atoms=md->state->atoms;
    fread(atoms->x,sizeof(double),atoms->N,fp);
    fread(atoms->v,sizeof(double),atoms->N,fp);
    fread(atoms->Vs_delay,sizeof(double),atoms->N,fp);
  
    atoms=md->state->manningcc_tk;
    fread(atoms->x,sizeof(double),atoms->N,fp);
    fread(atoms->v,sizeof(double),atoms->N,fp);
    fread(atoms->Vs_delay,sizeof(double),atoms->N,fp);

    atoms=md->state->manningcc_tcl;
    fread(atoms->x,sizeof(double),atoms->N,fp);
    fread(atoms->v,sizeof(double),atoms->N,fp);
    fread(atoms->Vs_delay,sizeof(double),atoms->N,fp);

    atoms=md->state->manningcc_ek;
    fread(atoms->x,sizeof(double),atoms->N,fp);
    fread(atoms->v,sizeof(double),atoms->N,fp);
    fread(atoms->Vs_delay,sizeof(double),atoms->N,fp);

    atoms=md->state->manningcc_ecl;
    fread(atoms->x,sizeof(double),atoms->N,fp);
    fread(atoms->v,sizeof(double),atoms->N,fp);
    fread(atoms->Vs_delay,sizeof(double),atoms->N,fp);

    fclose(fp);
  }
  
  // Returns current phase
  return md->parms->phase;
}

