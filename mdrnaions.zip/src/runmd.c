
#include "runmd.h"

#include "defines.h"

#include "md.h"
#include "atoms.h"
#include "state.h"
#include "collate.h"
#include "parms.h"
#include "leapparms.h"
#include "times.h"
#include "nlist.h"
#include "vec.h"

#include <omp.h>



void leapfrog(struct_md* md,struct_atoms* atoms,struct_leapparms* leapparms)
{
  int i,imin,imax;
  int ID,NID;
  double nu[2];
  double Vs, Vr, Xr, Xs;
  double *x=atoms->x;
  double *v=atoms->v;
  double *vhalf=atoms->vhalf;
  double *f=atoms->f->master;
  double *m=atoms->m;
  double *msqrt=atoms->msqrt;
  double *Vs_delay=atoms->Vs_delay;

  double SigmaVsVs=leapparms->SigmaVsVs;
  double XsVsCoeff=leapparms->XsVsCoeff;
  double CondSigmaXsXs=leapparms->CondSigmaXsXs;
  double SigmaVrVr=leapparms->SigmaVrVr;
  double XrVrCoeff=leapparms->XrVrCoeff;
  double CondSigmaXrXr=leapparms->CondSigmaXrXr;
  // double vhalf_vscale=leapparms->vhalf_vscale;
  // double vhalf_ascale=leapparms->vhalf_ascale;
  // double vhalf_Vsscale=leapparms->vhalf_Vsscale;
  double v_vscale=leapparms->v_vscale;
  double v_ascale=leapparms->v_ascale;
  double v_Vsscale=leapparms->v_Vsscale;
  double x_vscale=leapparms->x_vscale;
  double x_Xrscale=leapparms->x_Xrscale;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();

  imin=atoms->Ni+((atoms->Nf-atoms->Ni)*ID)/NID;
  imax=atoms->Ni+((atoms->Nf-atoms->Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    // assert(f[i]>-1e4 || md->state->atoms!=atoms);
    // assert(f[i]<1e4 || md->state->atoms!=atoms);
    /*if (isnan(f[i])) {
      arrested_development();
    }*/

    // Compute noise
    rand_normal(nu,md->state->mtstate[ID]);
    // Vs=SigmaVsVs*nu(:,:,1);
    Vs=Vs_delay[i];
    Vs_delay[i]=SigmaVsVs*nu[0]/msqrt[i];
    // Xs=CondSigmaXsXs*nu(:,:,2)+XsVsCoeff*[Vs(2:end,:);zeros([1,N])];
    // Correlate Xs with Velocity noise Vs from next leapfrog step
    Xs=CondSigmaXsXs*nu[1]/msqrt[i]+XsVsCoeff*Vs_delay[i];
    rand_normal(nu,md->state->mtstate[ID]);
    // Vr=SigmaVrVr*nu(:,:,3);
    Vr=SigmaVrVr*nu[0]/msqrt[i];
    // Xr=CondSigmaXrXr*nu(:,:,4)+XrVrCoeff*Vr;
    Xr=CondSigmaXrXr*nu[1]/msqrt[i]+XrVrCoeff*Vr;
  
    // vhalf[i]=vhalf_vscale*v[i]+vhalf_ascale*f[i]/m[i]+vhalf_Vsscale*Vs;
    // Update v from t-0.5*dt to t+0.5*dt
    v[i]=v_vscale*v[i]+v_ascale*f[i]/m[i]+v_Vsscale*Vs+Vr;
    // Update x from t to t+dt
    x[i]=x[i]+x_vscale*v[i]+x_Xrscale*Xr+Xs;
  }
}


#ifdef VIRTUAL
static
void position_virt2(struct_md *md) {
  int i,vv,ii,jj;
  double Cj;
  struct_virt2parms *virt2parms=md->parms->virt2parms;
  double *x=md->state->x;
  double *box=md->state->box;
  vec xprev, vdiff;
  int ID, NID;
  int imin,imax;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();
  imin=(md->parms->N_virt2*ID)/NID;
  imax=(md->parms->N_virt2*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    vv=virt2parms[i].v;
    ii=virt2parms[i].i;
    jj=virt2parms[i].j;
    Cj=virt2parms[i].Cj;
    // Save old position
    vec_copy(xprev,x+DIM3*vv);
    // Find new position
    vec_copy(x+DIM3*vv,x+DIM3*ii);
    vec_subpbc(x+DIM3*jj,x+DIM3*ii,box,vdiff);
    vec_scaleinc(x+DIM3*vv,Cj,vdiff);
    // Find closest image of new position to old position
    vec_subpbc(x+DIM3*vv,xprev,box,vdiff);
    vec__add(xprev,vdiff,x+DIM3*vv);
    // Reset velocity
    vec_reset(md->state->atoms->v+DIM3*vv);
  }
}


static
void position_virt3(struct_md *md) {
  int i,vv,ii,jj,kk;
  double Cj,Ck;
  struct_virt3parms *virt3parms=md->parms->virt3parms;
  double *x=md->state->x;
  double *box=md->state->box;
  vec xprev, vdiff;
  int ID, NID;
  int imin,imax;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();
  imin=(md->parms->N_virt3*ID)/NID;
  imax=(md->parms->N_virt3*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    vv=virt3parms[i].v;
    ii=virt3parms[i].i;
    jj=virt3parms[i].j;
    kk=virt3parms[i].k;
    Cj=virt3parms[i].Cj;
    Ck=virt3parms[i].Ck;
    // Save old position
    vec_copy(xprev,x+DIM3*vv);
    // Find new position
    vec_copy(x+DIM3*vv,x+DIM3*ii);
    vec_subpbc(x+DIM3*jj,x+DIM3*ii,box,vdiff);
    vec_scaleinc(x+DIM3*vv,Cj,vdiff);
    vec_subpbc(x+DIM3*kk,x+DIM3*ii,box,vdiff);
    vec_scaleinc(x+DIM3*vv,Ck,vdiff);
    // Find closest image of new position to old position
    vec_subpbc(x+DIM3*vv,xprev,box,vdiff);
    vec__add(xprev,vdiff,x+DIM3*vv);
    // Reset velocity
    vec_reset(md->state->atoms->v+DIM3*vv);
  }
}


void leapfrog_virt(struct_md *md)
{
  #pragma omp barrier
  position_virt2(md);
  position_virt3(md);
  #pragma omp barrier
}
#endif


void boundaryconditions(struct_md* md)
{
  int i,j;
  int N,imin,imax;
  int ID,NID;
  double x;
  double shiftbuf;
  double *box=md->state->box;
  struct_atoms *atoms;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();

  atoms=md->state->atoms;
  N=atoms->N;

  imin=atoms->Ni+((atoms->Nf-atoms->Ni)*ID)/NID;
  imax=atoms->Ni+((atoms->Nf-atoms->Ni)*(ID+1))/NID;
  for (i=imin; i<imax; i++) {
    j=i%DIM3;
    x=atoms->x[i];
    shiftbuf=-box[j]*floor(x/box[j]);
    atoms->shift[i]-=shiftbuf;
    atoms->x[i]+=shiftbuf;
  }
}


static
void incstep(struct_md* md)
{
  #pragma omp barrier
  #pragma omp master
  md->state->step++;
  #pragma omp barrier
}


void update_anneal(struct_md* md,struct_leapparms* leapparms)
{
  #pragma omp master
  md->times->start=gmx_cycles_read();

  leapfrog(md,md->state->manningcc_tk,leapparms);
  leapfrog(md,md->state->manningcc_tcl,leapparms);
  leapfrog(md,md->state->manningcc_ek,leapparms);
  leapfrog(md,md->state->manningcc_ecl,leapparms);
  #pragma omp master
    md->times->update+=(gmx_cycles_read()-md->times->start);
  incstep(md); // barrier wrapped
}


void update(struct_md* md)
{
  #pragma omp master
  md->times->start=gmx_cycles_read();

  leapfrog(md,md->state->atoms,md->parms->leapparms);

  leapfrog(md,md->state->manningcc_tk,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_tcl,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_ek,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_ecl,md->parms->leapparms_mcc);

#ifdef POLARIZE
  leapfrog(md,md->state->manningcc_pk,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_pcl,md->parms->leapparms_mcc);
#endif

#ifdef VIRTUAL
  leapfrog_virt(md);
#endif

  boundaryconditions(md);
  #pragma omp master
    md->times->update+=(gmx_cycles_read()-md->times->start);
  incstep(md); // barrier wrapped
}


void resetstep(struct_md* md)
{
  #pragma omp barrier
  #pragma omp master
    md->state->step=0;
  #pragma omp barrier
}


void eqtheta(struct_md* md,int lim,struct_leapparms* leapparms)
{
  resetstep(md);
  while (md->state->step < lim) {
    getforce(md);
    // if (md->state->step % md->parms->t_output == 0)
    //   printoutput(md);
    update_anneal(md,leapparms);
  }
}


void resetcumcycles(struct_md* md)
{
  int ID;
  ID=omp_get_thread_num();
  md->state->nlelec->cycles_sort[ID]=0;
  md->state->nlelec->cycles_check[ID]=0;
  md->state->nlelec->cycles_force[ID]=0;
  md->state->nlother->cycles_sort[ID]=0;
  md->state->nlother->cycles_check[ID]=0;
  md->state->nlother->cycles_force[ID]=0;
  md->state->nlelec->cumcycles_sort[ID]=0;
  md->state->nlelec->cumcycles_check[ID]=0;
  md->state->nlelec->cumcycles_force[ID]=0;
  md->state->nlother->cumcycles_sort[ID]=0;
  md->state->nlother->cumcycles_check[ID]=0;
  md->state->nlother->cumcycles_force[ID]=0;
#pragma omp barrier
}

