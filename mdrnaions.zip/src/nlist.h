#ifndef MD_RNA_IONS_NLIST_H
#define MD_RNA_IONS_NLIST_H

#include "vec.h"
#include "times.h"
#include "md.h"

struct struct_nldata;

typedef struct struct_sortatom
{
  int index;
  int bin[3];
  long long lbin;
  struct struct_sortatom *pless;
  struct struct_sortatom *pmore;
  int nless;
  int nmore;
} struct_sortatom;


typedef struct struct_nlist
{
// First index is particle i
  int *ii;
  int iimax; // Number of atoms
  int *iitype;
  int **jj; // jj[i][0] inclusive to jj[i][jjmax[i]] exclusive contains the neighbors of atom ii[i]. ij neighbor pairs are listed under i OR j, but not both.
  int *jjmax;// *jjind;
  int *jjsize; // number of entries available in jj
  vec **shiftij;
  struct struct_nldata **nldata;
  struct struct_sortatom *sort;
// First index is neither
  int *div; // int vector - box divisions in each direction
  double **rc2;
// First index is number of nodes
  int **checklist;
  vec **shiftlist;
  gmx_cycles_t *cycles_sort;
  gmx_cycles_t *cycles_check;
  gmx_cycles_t *cycles_force;
  gmx_cycles_t *cumcycles_sort;
  gmx_cycles_t *cumcycles_check;
  gmx_cycles_t *cumcycles_check1;
  gmx_cycles_t *cumcycles_check2;
  gmx_cycles_t *cumcycles_force;
  int *imin;
  int *imax;
  int *imin_f;
  int *imax_f;
} struct_nlist;


struct_nlist* alloc_nlist(int N,int *iitype,double **rc2);

void free_nlist(struct_nlist* nlist);

void neighborsearch(struct_md* md);

#endif

