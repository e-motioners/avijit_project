#ifndef MD_RNA_IONS_MERSENNE_H
#define MD_RNA_IONS_MERSENNE_H

typedef struct struct_mtstate
{
  unsigned long *mt; /* the array for the state vector  */
  int mti; /* mti==N+1 means mt[N] is not initialized */
} struct_mtstate;

struct_mtstate** alloc_mtstate(unsigned long s);

void rand_normal(double* r,struct_mtstate* mtstate);

void free_mtstate(struct_mtstate** mtstate);

#endif

