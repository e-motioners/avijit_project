#ifndef MD_RNA_IONS_RUNMD_H
#define MD_RNA_IONS_RUNMD_H

#include "md.h"
#include "atoms.h"
#include "leapparms.h"

void leapfrog(struct_md* md,struct_atoms* atoms,struct_leapparms* leapparms);

#ifdef VIRTUAL
void leapfrog_virt(struct_md *md);
#endif

void boundaryconditions(struct_md* md);

void update_anneal(struct_md* md,struct_leapparms* leapparms);

void update(struct_md* md);

void resetstep(struct_md* md);

void eqtheta(struct_md* md,int lim,struct_leapparms* leapparms);

void resetcumcycles(struct_md* md);

#endif
