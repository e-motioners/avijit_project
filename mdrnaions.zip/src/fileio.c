
#include "fileio.h"

#include "defines.h"

#include "state.h"
#include "vec.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Load gro
void read_gro(char *fnm,struct_state* state)
{
  FILE *fp;
  char s[MAXLENGTH];
  int i,N;

  fp=fopen(fnm,"r");

  if (fp==NULL) {
    fprintf(stderr,"Fatal error: grofile %s does not exist\n",fnm);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }

  fgets(s,MAXLENGTH,fp);
  fgets(s,MAXLENGTH,fp);
  sscanf(s,"%d",&N);

  for (i=0; i<N; i++) {
    fgets(s,MAXLENGTH,fp);
    // sscanf(s,"%5d%5c%5c%5d%8.3lg%8.3lg%8.3lg",
    sscanf(s,"%5d%5c%5c%5d%8lg%8lg%8lg",
      &(state->res_id[i]),&(state->res_name[i][0]),
      &(state->atom_name[i][0]),&(state->atom_id[i]),
      &(state->x[DIM3*i]),&(state->x[DIM3*i+1]),&(state->x[DIM3*i+2]));
  }
}


// Load data
int read_xyzq(char *fnm,struct_state* state,int N)
{  
  FILE *fp;
  char s[MAXLENGTH];
  int i;

  fp=fopen(fnm,"r");

  if (fp==NULL) {
    fprintf(stderr,"Fatal error: xyzqfile %s does not exist\n",fnm);
    #ifndef NOMPI
    MPI_Finalize();
    #endif
    exit(0);
  }

  if (N==0) {
    // Count the number of lines
    i=0;
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      i++;
    }
  } else {
    // Read in the data
    i=0;
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      // sscanf(s,"%lg %lg %lg %lg",&(state->x[DIM3*i]),&(state->x[DIM3*i+1]),&(state->x[DIM3*i+2]),&(state->q[i]));
      sscanf(s,"%*lg %*lg %*lg %lg",&(state->q[i]));
      // state->x[DIM3*i]+=25; // CONST
      // state->x[DIM3*i+1]+=25; // CONST
      // state->x[DIM3*i+2]+=25; // CONST
      i++;
    }
  }
    
  fclose(fp);
  return i;
}


void gen_xyzq(struct_state* state,double r01,double r11)
{
  int i,j;
  int accept;
  vec dr;
  double r;
  double *x=state->x;
  double *q=state->q;
  int *res_id=state->res_id;
  char (*res_name)[5]=state->res_name;
  int *atom_id=state->atom_id;
  char (*atom_name)[5]=state->atom_name;
  double *box=state->box;

  for (i=state->N_rna; i<state->N_all; i++) {
    accept=0;
    while (accept==0) {
      accept=1;
      x[DIM3*i]  =box[0]*(((double) rand())/RAND_MAX);
      x[DIM3*i+1]=box[1]*(((double) rand())/RAND_MAX);
      x[DIM3*i+2]=box[2]*(((double) rand())/RAND_MAX);
      q[i]=2;
      res_id[i]=(i+1)+(res_id[state->N_rna-1]-atom_id[state->N_rna-1]);
      strncpy(res_name[i],"   MG",5);
      atom_id[i]=i+1;
      strncpy(atom_name[i],"   MG",5);
      for (j=0; j<state->N_rna; j++) { // Make sure it's not too close to RNA
        vec_subpbc(x+DIM3*i,x+DIM3*j,box,dr);
        r=vec_mag(dr);
        if (r<r01) {
          accept=0;
        }
      }
      for (j=state->N_rna; j<i; j++) { // Or other Mg ions
        vec_subpbc(x+DIM3*i,x+DIM3*j,box,dr);
        r=vec_mag(dr);
        if (r<r11) {
          accept=0;
        }
      }
    }
  }
}

