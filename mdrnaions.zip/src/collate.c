
#include "collate.h"

# include "defines.h"

#include <omp.h>
#include <stdlib.h>

struct_collate* alloc_collate(int N,int Ni,int Nf)
{
  struct_collate *collate;
  int i;

  collate=malloc(sizeof(struct_collate));
  collate->N=N;
  collate->Ni=Ni;
  collate->Nf=Nf;
  collate->NID=omp_get_max_threads();
  collate->master=calloc(N,sizeof(double));
  collate->local=calloc(collate->NID,sizeof(double*));

  for (i=0; i<collate->NID; i++) {
    collate->local[i]=calloc(N,sizeof(double));
  }

  return collate;
}


double* resetlocal_collate(struct_collate* cl,int ID)
{
  int i;

  for (i=0; i<cl->N; i++) {
    cl->local[ID][i]=0;
  }

  return cl->local[ID];
}


double* sumlocal_collate(struct_collate* cl,int ID)
{
  int i,imin,imax,j;
  // volatile double buffer;
  double buffer;

  imin=cl->Ni+((cl->Nf-cl->Ni)*ID)/cl->NID;
  imax=cl->Ni+((cl->Nf-cl->Ni)*(ID+1))/cl->NID;

  for (i=0; i<ID; i++) {
    for (j=imin; j<imax; j++) {
      cl->local[ID][j]+=cl->local[i][j];
    }
  }
  for (i=ID+1; i<cl->NID; i++) {
    for (j=imin; j<imax; j++) {
      cl->local[ID][j]+=cl->local[i][j];
    }
  }

  for (i=imin; i<imax; i++) {
    cl->master[i]=cl->local[ID][i];
  }

  return cl->master;
}


void free_collate(struct_collate* collate)
{
  int i;

  free(collate->master);
  for (i=0; i<collate->NID; i++) {
    free(collate->local[i]);
  }
  free(collate->local);
  free(collate);
}

