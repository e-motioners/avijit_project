
#include "unspecific.h"

#include "defines.h"

#include "md.h"
#include "state.h"
#include "qlist.h"
#include "atoms.h"
#include "collate.h"
#include "gausstables.h"
#include "nlist.h"
#include "vec.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

static
double xlnxmx_soft(double x,double xc)
{
  if (x>xc) {
    return x*log(x)-x;
  } else {
    return 0.5*x*x/xc+(log(xc)-1)*x-0.5*xc;
  }
}


// lnx_soft = d/dx xlnxmx_soft
static
double lnx_soft(double x,double xc)
{
  if (x>xc) {
    return log(x);
  } else {
    return x/xc+(log(xc)-1);
  }
}


void getforce_elec(struct_md* md)
{
  struct_qlist *qqlist=md->state->qqlist;
  int ID,NID,imin,imax;
  int Ni=md->state->manningcc_tk->Ni;
  int Nf=md->state->manningcc_tk->Nf;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,Frij,cij,Pij;
  struct_nldata *data;
  double qi,qj,ti,tj,ei,ej;
  double tdev;
  double fr_buf,fti_buf,ftj_buf,fei_buf,fej_buf;
  double Gt=0;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=qqlist->theta;
  double *theta_cl=qqlist->theta_cl;
  double *eta=qqlist->eta;
  double *eta_cl=qqlist->eta_cl;
  double *bP=qqlist->bP;
  double *fx, *ft_k, *ft_cl, *fe_k, *fe_cl;
  double *pot_t, *pot_e;
  double *V1eff_inv,*V2eff_inv;
  double *condens_tk,*condens_tcl;
  double *condens_ek,*condens_ecl;
  double *dens_tk=qqlist->dens_tk;
  double *dens_tcl=qqlist->dens_tcl;
  double *dens_ek=qqlist->dens_ek;
  double *dens_ecl=qqlist->dens_ecl;
  double *dGsoftdt_tk=qqlist->dGsoftdt_tk;
  double *dGsoftdt_tcl=qqlist->dGsoftdt_tcl;
  double *dGsoftde_ek=qqlist->dGsoftde_ek;
  double *dGsoftde_ecl=qqlist->dGsoftde_ecl;
  double dV;
  double Gmix_tk,Gmix_tcl,dGmixdt_tk,dGmixdt_tcl;
  double Ghole_ek,Ghole_ecl,dGholede_ek,dGholede_ecl;
  double Gsoft_tk,Gsoft_tcl,Gsoft_ek,Gsoft_ecl,Gpot;
  double dGpotdpot,dGmixdpot,dGholedpot;
  double dGsoftdV1,dGsoftdV2,dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double *G=qqlist->G;
  double *dGdtk=qqlist->dGdtk;
  double *dGdtcl=qqlist->dGdtcl;
  double *dGdek=qqlist->dGdek;
  double *dGdecl=qqlist->dGdecl;
  double *dGdtpot=qqlist->dGdtpot;
  double *dGdepot=qqlist->dGdepot;
  double *dGdV1=qqlist->dGdV1;
  double *dGdV2=qqlist->dGdV2;
  int nqlist;
  int *qlist;
  // double lB,kappa,conc_KCl,f_KCl,V,kT,kT0,kTr0,rc,V1,V2;
  double lB,kappa,conc_KCl,conc_K,conc_Cl,V,kT,kT0,kTr0,rc,V1,V2;
  // double gauss_00=md->parms->gauss_00;
  // double gauss_01=md->parms->gauss_01;
  // double gauss_02=md->parms->gauss_02;
  // double gauss_11=md->parms->gauss_11;
  // double gauss_12=md->parms->gauss_12;
  // double gauss_22=md->parms->gauss_22;
  double k_prohibit=md->parms->k_prohibit;
  double k_soft=md->parms->k_soft;
  // Table variables
  struct_tables *tab=md->parms->elec_tables;
  // int Ntab=tab->N;
  // double hinv=tab->hinv;
  // int itab;
  // double xtab,xtab2,xtab3;
  gmx_cycles_t start,start0,stop;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;

  fx=md->state->atoms->f->local[ID];
  ft_k=md->state->manningcc_tk->f->local[ID];
  ft_cl=md->state->manningcc_tcl->f->local[ID];
  fe_k=md->state->manningcc_ek->f->local[ID];
  fe_cl=md->state->manningcc_ecl->f->local[ID];

  condens_tk=resetlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=resetlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=resetlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=resetlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=resetlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=resetlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=resetlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=resetlocal_collate(md->state->qqlist->V2eff_inv,ID);

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_KCl=md->parms->conc_KCl;
  // f_KCl=md->parms->f_KCl;
  conc_K=md->parms->conc_K;
  conc_Cl=md->parms->conc_Cl;
  V1=md->parms->V1;
  V2=md->parms->V2;
  kT=md->parms->kT;
  kT0=md->parms->kT0;
  kTr0=md->parms->kTr0;
  rc=md->parms->rcelec;

  start=gmx_cycles_read();
  start0=start;

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    if (bP[ii]) {
      Eij=tab->point[0][eT_DH01].A0;
      Gt+=qi*ti*Eij;
      pot_t[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH11].A0;
      Gt+=0.5*ti*ti*Eij;
      pot_t[ii]+=ti*Eij;
      
      Eij=tab->point[0][eT_DH02].A0;
      Gt+=qi*ei*Eij;
      pot_e[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      Gt+=ti*ei*Eij;
      pot_t[ii]+=ei*Eij;
      pot_e[ii]+=ti*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      Gt+=0.5*ei*ei*Eij;
      pot_e[ii]+=ei*Eij;

      // Pij=1.0/V1;
      Pij=tab->point[0][eT_G1].A0;
      condens_tk[ii]+=theta[ii]*Pij;
      condens_tcl[ii]+=theta_cl[ii]*Pij;
      V1eff_inv[ii]+=Pij;

      // Pij=1.0/V2;
      Pij=tab->point[0][eT_G2].A0;
      condens_ek[ii]+=eta[ii]*Pij;
      condens_ecl[ii]+=eta_cl[ii]*Pij;
      V2eff_inv[ii]+=Pij;
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,data->dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,data->dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(data->dr);
      // if (r<=rc) { // TRY
        // itab=((int) (r*hinv));
        // xtab=r*hinv-itab;
        // xtab2=xtab*xtab;
        // xtab3=xtab2*xtab;
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;

        data->r=r;
        // tables_interp(tab,data,md);
        if (tables_interp(tab,data)) {
          md->state->abortflag=1;
          break;
        }
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&(data->Eij00),&(data->Frij00));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&(data->Eij01),&(data->Frij01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&(data->Eij11),&(data->Frij11));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&(data->Eij02),&(data->Frij02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&(data->Eij12),&(data->Frij12));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&(data->Eij22),&(data->Frij22));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&(data->Pij1),&(data->Qrij1));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&(data->Pij2),&(data->Qrij2));

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&Eij,&Frij);
        Eij=data->Eij[eT_DH00];
        Frij=data->Frij[eT_DH00];
        Gt+=qi*qj*Eij;
        fr_buf+=qi*qj*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        Gt+=(ti*qj+tj*qi)*Eij;
        fr_buf+=(ti*qj+tj*qi)*Frij;
        pot_t[ii]+=qj*Eij;
        pot_t[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        Gt+=ti*tj*Eij;
        fr_buf+=ti*tj*Frij;
        pot_t[ii]+=tj*Eij;
        pot_t[jj]+=ti*Eij;
       
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        Gt+=(qi*ej+qj*ei)*Eij;
        fr_buf+=(qi*ej+qj*ei)*Frij;
        pot_e[ii]+=qj*Eij;
        pot_e[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        Gt+=(ti*ej+tj*ei)*Eij;
        fr_buf+=(ti*ej+tj*ei)*Frij;
        pot_t[ii]+=ej*Eij;
        pot_t[jj]+=ei*Eij;
        pot_e[ii]+=tj*Eij;
        pot_e[jj]+=ti*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        Gt+=ei*ej*Eij;
        fr_buf+=ei*ej*Frij;
        pot_e[ii]+=ej*Eij;
        pot_e[jj]+=ei*Eij;

        // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        condens_tk[ii]+=theta[jj]*Pij;
        condens_tk[jj]+=theta[ii]*Pij;
        condens_tcl[ii]+=theta_cl[jj]*Pij;
        condens_tcl[jj]+=theta_cl[ii]*Pij;
        V1eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V1eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V1eff_inv[ii]+=Pij;
        // V1eff_inv[jj]+=Pij;

        // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        condens_ek[ii]+=eta[jj]*Pij;
        condens_ek[jj]+=eta[ii]*Pij;
        condens_ecl[ii]+=eta_cl[jj]*Pij;
        condens_ecl[jj]+=eta_cl[ii]*Pij;
        V2eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V2eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V2eff_inv[ii]+=Pij;
        // V2eff_inv[jj]+=Pij;

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
      // }
    }
    if (md->state->abortflag) {
      break;
    }
  }
  
  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);

#pragma omp barrier
  if (md->state->abortflag) {
    #pragma omp master
    {
      fprintf(stderr,"Fatal error: neighbor interaction distance is longer than table cutoff\n");
      printgroframe(md,"crash");
      #ifndef NOMPI
      MPI_Finalize();
      #endif
      exit(0);
    }
  }

  // Wait for all nodes to finish, and coallate things required to compute free energy of mixing
  start=gmx_cycles_read();
  
  condens_tk=sumlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=sumlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=sumlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=sumlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=sumlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=sumlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=sumlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=sumlocal_collate(md->state->qqlist->V2eff_inv,ID);

  // imin=(qqlist->nqlist * ID)/NID;
  // imax=(qqlist->nqlist * (ID+1))/NID;
  imin=Ni+((Nf-Ni)*ID)/NID;
  imax=Ni+((Nf-Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    if (bP[i]) { // Otherwise, all these things stay zero.
      dV=(1/V1eff_inv[i]-1/V2eff_inv[i]);

      tdev=condens_tk[i] /V1eff_inv[i]-theta[i];
      Gsoft_tk =0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tk[i] =k_soft*kT0*tdev/V1eff_inv[i];

      tdev=condens_tcl[i]/V1eff_inv[i]-theta_cl[i];
      Gsoft_tcl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tcl[i]=k_soft*kT0*tdev/V1eff_inv[i];

      dGsoftdV1=(dGsoftdt_tk[i]*condens_tk[i]+dGsoftdt_tcl[i]*condens_tcl[i])/(-V1eff_inv[i]);

      tdev=condens_ek[i] /V2eff_inv[i]-eta[i];
      Gsoft_ek =0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ek[i] =k_soft*kT0*tdev/V2eff_inv[i];

      tdev=condens_ecl[i]/V2eff_inv[i]-eta_cl[i];
      Gsoft_ecl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ecl[i]=k_soft*kT0*tdev/V2eff_inv[i];

      dGsoftdV2=(dGsoftde_ek[i]*condens_ek[i]+dGsoftde_ecl[i]*condens_ecl[i])/(-V2eff_inv[i]);

      dens_tk[i] =condens_tk[i] +conc_KCl-conc_K *pot_t[i]/kT;
      Gmix_tk =kT*dV*conc_K*xlnxmx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);
      dGmixdt_tk =kT*dV*lnx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);

      dens_tcl[i]=condens_tcl[i]+conc_KCl+conc_Cl*pot_t[i]/kT;
      Gmix_tcl=kT*dV*conc_Cl*xlnxmx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);
      dGmixdt_tcl=kT*dV*lnx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);

      dGmixdpot=-(dGmixdt_tk*conc_K-dGmixdt_tcl*conc_Cl)/kT;
      dGmixdV1= (Gmix_tk+Gmix_tcl)/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGmixdV2=-(Gmix_tk+Gmix_tcl)/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      dens_ek[i] =condens_ek[i] +condens_tk[i] +conc_KCl-conc_K *pot_e[i]/kT;
      Ghole_ek =0.5*k_prohibit*kT0*V2*V2*dens_ek[i] *dens_ek[i];
      dGholede_ek =k_prohibit*kT0*V2*V2*dens_ek[i];

      dens_ecl[i]=condens_ecl[i]+condens_tcl[i]+conc_KCl+conc_Cl*pot_e[i]/kT;
      Ghole_ecl=0.5*k_prohibit*kT0*V2*V2*dens_ecl[i]*dens_ecl[i];
      dGholede_ecl=k_prohibit*kT0*V2*V2*dens_ecl[i];

      dGholedpot=-(dGholede_ek*conc_K-dGholede_ecl*conc_Cl)/kT;

      Gpot=-0.5*dV*(conc_K+conc_Cl)/kT*pot_t[i]*pot_t[i];
      dGpotdpot=-dV*(conc_K+conc_Cl)/kT*pot_t[i];

      dGpotdV1= Gpot/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGpotdV2=-Gpot/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gsoft_tk+Gsoft_tcl+Gsoft_ek+Gsoft_ecl+Gpot;
      dGdtk[i] =dGmixdt_tk +dGholede_ek +dGsoftdt_tk[i];
      dGdtcl[i]=dGmixdt_tcl+dGholede_ecl+dGsoftdt_tcl[i];
      dGdek[i] =dGholede_ek +dGsoftde_ek[i];
      dGdecl[i]=dGholede_ecl+dGsoftde_ecl[i];
      dGdtpot[i]=dGmixdpot+dGpotdpot;
      dGdepot[i]=dGholedpot;
      dGdV1[i]=dGmixdV1+dGsoftdV1+dGpotdV1;
      dGdV2[i]=dGmixdV2+dGsoftdV2+dGpotdV2;
    }
  }

  // stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);

#pragma omp barrier

  // Wait for collation to finish and compute free energy of mixing
  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    fti_buf=0;
    fei_buf=0;
    if (bP[ii]) {
      Gt+=G[ii];
      // Gt+=Gmix_tk[ii]+Gmix_tcl[ii]+Ghole_ek[ii]+Ghole_ecl[ii];
      // Gt+=Gsoft_tk[ii]+Gsoft_tcl[ii]+Gsoft_ek[ii]+Gsoft_ecl[ii];
      // Gt+=Gpot[ii];

      fti_buf+=-pot_t[ii];
      fei_buf+=-pot_e[ii];

      Eij=tab->point[0][eT_DH11].A0;
      // fti_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      // fti_buf+=-dGholedpot[ii]*Eij;
      // fei_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdepot[ii]*Eij;
      fei_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      // fei_buf+=-dGholedpot[ii]*Eij;
      fei_buf+=-dGdepot[ii]*Eij;
      
      // Pij=1/V1;
      Pij=tab->point[0][eT_G1].A0;
      // ft_k[ii] +=-dGmixdt_tk[ii]*Pij;
      // ft_cl[ii]+=-dGmixdt_tcl[ii]*Pij;
      // ft_k[ii] +=-dGholede_ek[ii]*Pij;
      // ft_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // ft_k[ii] +=-dGsoftdt_tk[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_cl[ii]+=-dGsoftdt_tcl[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      ft_k[ii] +=-dGdtk[ii]*Pij +dGsoftdt_tk[ii]*V1eff_inv[ii];
      ft_cl[ii]+=-dGdtcl[ii]*Pij+dGsoftdt_tcl[ii]*V1eff_inv[ii];

      // Pij=1/V2;
      Pij=tab->point[0][eT_G2].A0;
      // fe_k[ii] +=-dGholede_ek[ii]*Pij;
      // fe_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // fe_k[ii] +=-dGsoftde_ek[ii]*(Pij-V2eff_inv[ii]);
      // fe_cl[ii]+=-dGsoftde_ecl[ii]*(Pij-V2eff_inv[ii]);
      fe_k[ii] +=-dGdek[ii]*Pij +dGsoftde_ek[ii]*V2eff_inv[ii];
      fe_cl[ii]+=-dGdecl[ii]*Pij+dGsoftde_ecl[ii]*V2eff_inv[ii];
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      // shiftij=md->state->nlelec[ID]->shiftij[j];
      // vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // r=vec_mag(dr);
      // if (data->r<=rc) { // TRY
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;
        ftj_buf=0;
        fej_buf=0;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        // fr_buf+=(qi*dGmixdpot[jj]+qj*dGmixdpot[ii]+
        //          qi*dGpotdpot[jj]+qj*dGpotdpot[ii])*Frij;
        fr_buf+=(qi*dGdtpot[jj]+qj*dGdtpot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        // fr_buf+=(ti*dGmixdpot[jj]+tj*dGmixdpot[ii]+
        //          ti*dGpotdpot[jj]+tj*dGpotdpot[ii])*Frij;
        // fti_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // ftj_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ti*dGdtpot[jj]+tj*dGdtpot[ii])*Frij;
        fti_buf+=-(dGdtpot[jj])*Eij;
        ftj_buf+=-(dGdtpot[ii])*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        // fr_buf+=(qi*dGholedpot[jj]+qj*dGholedpot[ii])*Frij;
        fr_buf+=(qi*dGdepot[jj]+qj*dGdepot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        // fr_buf+=(ei*dGmixdpot[jj]+ej*dGmixdpot[ii]+
        //          ti*dGholedpot[jj]+tj*dGholedpot[ii]+
        //          ei*dGpotdpot[jj]+ej*dGpotdpot[ii])*Frij;
        // fti_buf+=-dGholedpot[jj]*Eij;
        // ftj_buf+=-dGholedpot[ii]*Eij;
        // fei_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // fej_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ei*dGdtpot[jj]+ej*dGdtpot[ii]+ti*dGdepot[jj]+tj*dGdepot[ii])*Frij;
        fti_buf+=-dGdepot[jj]*Eij;
        ftj_buf+=-dGdepot[ii]*Eij;
        fei_buf+=-dGdtpot[jj]*Eij;
        fej_buf+=-dGdtpot[ii]*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        // fr_buf+=(ei*dGholedpot[jj]+ej*dGholedpot[ii])*Frij;
        // fei_buf+=-dGholedpot[jj]*Eij;
        // fej_buf+=-dGholedpot[ii]*Eij;
        fr_buf+=(ei*dGdepot[jj]+ej*dGdepot[ii])*Frij;
        fei_buf+=-dGdepot[jj]*Eij;
        fej_buf+=-dGdepot[ii]*Eij;

        // if (bP[ii] && bP[jj]) { // TRY
          // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
          // Frij=Pij/(gauss_01*gauss_01);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G1];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G1];
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // fr_buf+=(dGmixdt_tk[jj]*theta[ii]+dGmixdt_tk[ii]*theta[jj]+dGmixdt_tcl[jj]*theta_cl[ii]+dGmixdt_tcl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGholede_ek[jj]*theta[ii]+dGholede_ek[ii]*theta[jj]+dGholede_ecl[jj]*theta_cl[ii]+dGholede_ecl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGsoftdt_tk[jj]*theta[ii]+dGsoftdt_tcl[jj]*theta_cl[ii]+dGsoftdt_tk[ii]*theta[jj]+dGsoftdt_tcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGmixdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGmixdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGmixdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGmixdt_tcl[ii]*Pij;
          // ft_k[ii] +=-dGholede_ek[jj]*Pij;
          // ft_k[jj] +=-dGholede_ek[ii]*Pij;
          // ft_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // ft_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // ft_k[ii] +=-dGsoftdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGsoftdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGsoftdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGsoftdt_tcl[ii]*Pij;
          // fr_buf+=(dGmixdV1[jj]+dGmixdV1[ii])*Frij;
          // fr_buf+=(dGsoftdV1[jj]+dGsoftdV1[ii])*Frij;
          // fr_buf+=(dGpotdV1[jj]+dGpotdV1[ii])*Frij;
          fr_buf+=(dGdtk[jj]*theta[ii]+dGdtk[ii]*theta[jj]+dGdtcl[jj]*theta_cl[ii]+dGdtcl[ii]*theta_cl[jj])*Frij;
          ft_k[ii] +=-dGdtk[jj]*Pij;
          ft_k[jj] +=-dGdtk[ii]*Pij;
          ft_cl[ii]+=-dGdtcl[jj]*Pij;
          ft_cl[jj]+=-dGdtcl[ii]*Pij;
          fr_buf+=(dGdV1[jj]+dGdV1[ii])*Frij;

          // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
          // Frij=Pij/(gauss_02*gauss_02);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G2];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G2];
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // fr_buf+=(dGholede_ek[jj]*eta[ii]+dGholede_ek[ii]*eta[jj]+dGholede_ecl[jj]*eta_cl[ii]+dGholede_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGholede_ek[jj]*Pij;
          // fe_k[jj] +=-dGholede_ek[ii]*Pij;
          // fe_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // fr_buf+=(dGsoftde_ek[jj]*eta[ii]+dGsoftde_ecl[jj]*eta_cl[ii]+dGsoftde_ek[ii]*eta[jj]+dGsoftde_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGsoftde_ek[jj]*Pij;
          // fe_k[jj] +=-dGsoftde_ek[ii]*Pij;
          // fe_cl[ii]+=-dGsoftde_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGsoftde_ecl[ii]*Pij;
          // fr_buf+=(dGmixdV2[jj]+dGmixdV2[ii])*Frij;
          // fr_buf+=(dGsoftdV2[jj]+dGsoftdV2[ii])*Frij;
          // fr_buf+=(dGpotdV2[jj]+dGpotdV2[ii])*Frij;
          fr_buf+=(dGdek[jj]*eta[ii]+dGdek[ii]*eta[jj]+dGdecl[jj]*eta_cl[ii]+dGdecl[ii]*eta_cl[jj])*Frij;
          fe_k[ii] +=-dGdek[jj]*Pij;
          fe_k[jj] +=-dGdek[ii]*Pij;
          fe_cl[ii]+=-dGdecl[jj]*Pij;
          fe_cl[jj]+=-dGdecl[ii]*Pij;
          fr_buf+=(dGdV2[jj]+dGdV2[ii])*Frij;
        // }

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units

        ft_k[jj] += ftj_buf;
        ft_cl[jj]+=-ftj_buf;
        fe_k[jj] += fej_buf;
        fe_cl[jj]+=-fej_buf;
      // }
    }
    ft_k[ii] += fti_buf;
    ft_cl[ii]+=-fti_buf;
    fe_k[ii] += fei_buf;
    fe_cl[ii]+=-fei_buf;
  }

  md->state->Gt->local[ID][0]+=Gt*(kTr0/kT0); // Convert units
  md->state->Gts->local[ID][eE_elec]+=Gt*(kTr0/kT0); // Convert units

  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);
  #pragma omp master
    md->times->force_elec+=(gmx_cycles_read()-start0);
}


void getforce_elec_v2(struct_md* md)
{
  struct_qlist *qqlist=md->state->qqlist;
  int ID,NID,imin,imax;
  int Ni=md->state->manningcc_tk->Ni;
  int Nf=md->state->manningcc_tk->Nf;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,Frij,cij,Pij;
  struct_nldata *data;
  double qi,qj,ti,tj,ei,ej;
  double tdev;
  double fr_buf,fti_buf,ftj_buf,fei_buf,fej_buf;
  double Gt=0;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=qqlist->theta;
  double *theta_cl=qqlist->theta_cl;
  double *eta=qqlist->eta;
  double *eta_cl=qqlist->eta_cl;
  double *bP=qqlist->bP;
  double *fx, *ft_k, *ft_cl, *fe_k, *fe_cl;
  double *pot_t, *pot_e;
  double *V1eff_inv,*V2eff_inv;
  // double *condens_tk,*condens_tcl;
  // double *condens_ek,*condens_ecl;
  double *dens_tk=qqlist->dens_tk;
  double *dens_tcl=qqlist->dens_tcl;
  double *dens_ek=qqlist->dens_ek;
  double *dens_ecl=qqlist->dens_ecl;
  double *dGsoftdt_tk=qqlist->dGsoftdt_tk;
  double *dGsoftdt_tcl=qqlist->dGsoftdt_tcl;
  double *dGsoftde_ek=qqlist->dGsoftde_ek;
  double *dGsoftde_ecl=qqlist->dGsoftde_ecl;
  double dV;
  double Gmix_tk,Gmix_tcl,dGmixdt_tk,dGmixdt_tcl;
  double Ghole_ek,Ghole_ecl,dGholede_ek,dGholede_ecl;
  // double Gsoft_tk,Gsoft_tcl,Gsoft_ek,Gsoft_ecl,Gpot;
  double Gpot;
  double dGpotdpot,dGmixdpot,dGholedpot;
  // double dGsoftdV1,dGsoftdV2,dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double dGholedV1,dGholedV2;
  double *G=qqlist->G;
  double *dGdtk=qqlist->dGdtk;
  double *dGdtcl=qqlist->dGdtcl;
  double *dGdek=qqlist->dGdek;
  double *dGdecl=qqlist->dGdecl;
  double *dGdtpot=qqlist->dGdtpot;
  double *dGdepot=qqlist->dGdepot;
  double *dGdV1=qqlist->dGdV1;
  double *dGdV2=qqlist->dGdV2;
  int nqlist;
  int *qlist;
  // double lB,kappa,conc_KCl,f_KCl,V,kT,kT0,kTr0,rc,V1,V2;
  double lB,kappa,conc_KCl,conc_K,conc_Cl,V,kT,kT0,kTr0,rc,V1,V2;
  // double gauss_00=md->parms->gauss_00;
  // double gauss_01=md->parms->gauss_01;
  // double gauss_02=md->parms->gauss_02;
  // double gauss_11=md->parms->gauss_11;
  // double gauss_12=md->parms->gauss_12;
  // double gauss_22=md->parms->gauss_22;
  double k_prohibit=md->parms->k_prohibit;
  double k_soft=md->parms->k_soft;
  // Table variables
  struct_tables *tab=md->parms->elec_tables;
  // int Ntab=tab->N;
  // double hinv=tab->hinv;
  // int itab;
  // double xtab,xtab2,xtab3;
  gmx_cycles_t start,stop;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;

  fx=md->state->atoms->f->local[ID];
  ft_k=md->state->manningcc_tk->f->local[ID];
  ft_cl=md->state->manningcc_tcl->f->local[ID];
  fe_k=md->state->manningcc_ek->f->local[ID];
  fe_cl=md->state->manningcc_ecl->f->local[ID];

  // condens_tk=resetlocal_collate(md->state->qqlist->condens_tk,ID);
  // condens_tcl=resetlocal_collate(md->state->qqlist->condens_tcl,ID);
  // condens_ek=resetlocal_collate(md->state->qqlist->condens_ek,ID);
  // condens_ecl=resetlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=resetlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=resetlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=resetlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=resetlocal_collate(md->state->qqlist->V2eff_inv,ID);

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_KCl=md->parms->conc_KCl;
  // f_KCl=md->parms->f_KCl;
  conc_K=md->parms->conc_K;
  conc_Cl=md->parms->conc_Cl;
  V1=md->parms->V1;
  V2=md->parms->V2;
  kT=md->parms->kT;
  kT0=md->parms->kT0;
  kTr0=md->parms->kTr0;
  rc=md->parms->rcelec;

  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    if (bP[ii]) {
      Eij=tab->point[0][eT_DH01].A0;
      Gt+=qi*ti*Eij;
      pot_t[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH11].A0;
      Gt+=0.5*ti*ti*Eij;
      pot_t[ii]+=ti*Eij;
      
      Eij=tab->point[0][eT_DH02].A0;
      Gt+=qi*ei*Eij;
      pot_e[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      Gt+=ti*ei*Eij;
      pot_t[ii]+=ei*Eij;
      pot_e[ii]+=ti*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      Gt+=0.5*ei*ei*Eij;
      pot_e[ii]+=ei*Eij;

      // Pij=1.0/V1;
      Pij=tab->point[0][eT_G1].A0;
      // condens_tk[ii]+=theta[ii]*Pij;
      // condens_tcl[ii]+=theta_cl[ii]*Pij;
      V1eff_inv[ii]+=Pij;

      // Pij=1.0/V2;
      Pij=tab->point[0][eT_G2].A0;
      // condens_ek[ii]+=eta[ii]*Pij;
      // condens_ecl[ii]+=eta_cl[ii]*Pij;
      V2eff_inv[ii]+=Pij;
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,data->dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,data->dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(data->dr);
      // if (r<=rc) { // TRY
        // itab=((int) (r*hinv));
        // xtab=r*hinv-itab;
        // xtab2=xtab*xtab;
        // xtab3=xtab2*xtab;
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;

        data->r=r;
        // tables_interp(tab,data,md);
        if (tables_interp(tab,data)) {
          md->state->abortflag=1;
          break;
        }
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&(data->Eij00),&(data->Frij00));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&(data->Eij01),&(data->Frij01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&(data->Eij11),&(data->Frij11));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&(data->Eij02),&(data->Frij02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&(data->Eij12),&(data->Frij12));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&(data->Eij22),&(data->Frij22));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&(data->Pij1),&(data->Qrij1));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&(data->Pij2),&(data->Qrij2));

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&Eij,&Frij);
        Eij=data->Eij[eT_DH00];
        Frij=data->Frij[eT_DH00];
        Gt+=qi*qj*Eij;
        fr_buf+=qi*qj*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        Gt+=(ti*qj+tj*qi)*Eij;
        fr_buf+=(ti*qj+tj*qi)*Frij;
        pot_t[ii]+=qj*Eij;
        pot_t[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        Gt+=ti*tj*Eij;
        fr_buf+=ti*tj*Frij;
        pot_t[ii]+=tj*Eij;
        pot_t[jj]+=ti*Eij;
       
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        Gt+=(qi*ej+qj*ei)*Eij;
        fr_buf+=(qi*ej+qj*ei)*Frij;
        pot_e[ii]+=qj*Eij;
        pot_e[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        Gt+=(ti*ej+tj*ei)*Eij;
        fr_buf+=(ti*ej+tj*ei)*Frij;
        pot_t[ii]+=ej*Eij;
        pot_t[jj]+=ei*Eij;
        pot_e[ii]+=tj*Eij;
        pot_e[jj]+=ti*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        Gt+=ei*ej*Eij;
        fr_buf+=ei*ej*Frij;
        pot_e[ii]+=ej*Eij;
        pot_e[jj]+=ei*Eij;

        // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        // condens_tk[ii]+=theta[jj]*Pij;
        // condens_tk[jj]+=theta[ii]*Pij;
        // condens_tcl[ii]+=theta_cl[jj]*Pij;
        // condens_tcl[jj]+=theta_cl[ii]*Pij;
        V1eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V1eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V1eff_inv[ii]+=Pij;
        // V1eff_inv[jj]+=Pij;

        // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        // condens_ek[ii]+=eta[jj]*Pij;
        // condens_ek[jj]+=eta[ii]*Pij;
        // condens_ecl[ii]+=eta_cl[jj]*Pij;
        // condens_ecl[jj]+=eta_cl[ii]*Pij;
        V2eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V2eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V2eff_inv[ii]+=Pij;
        // V2eff_inv[jj]+=Pij;

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
      // }
    }
    if (md->state->abortflag) {
      break;
    }
  }
  
  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);

#pragma omp barrier
  if (md->state->abortflag) {
    #pragma omp master
    {
      fprintf(stderr,"Fatal error: neighbor interaction distance is longer than table cutoff\n");
      printgroframe(md,"crash");
      #ifndef NOMPI
      MPI_Finalize();
      #endif
      exit(0);
    }
  }

  // Wait for all nodes to finish, and coallate things required to compute free energy of mixing
  start=gmx_cycles_read();
  
  // condens_tk=sumlocal_collate(md->state->qqlist->condens_tk,ID);
  // condens_tcl=sumlocal_collate(md->state->qqlist->condens_tcl,ID);
  // condens_ek=sumlocal_collate(md->state->qqlist->condens_ek,ID);
  // condens_ecl=sumlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=sumlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=sumlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=sumlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=sumlocal_collate(md->state->qqlist->V2eff_inv,ID);

  // imin=(qqlist->nqlist * ID)/NID;
  // imax=(qqlist->nqlist * (ID+1))/NID;
  imin=Ni+((Nf-Ni)*ID)/NID;
  imax=Ni+((Nf-Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    if (bP[i]) { // Otherwise, all these things stay zero.
      dV=(1/V1eff_inv[i]-1/V2eff_inv[i]);

      // tdev=condens_tk[i] /V1eff_inv[i]-theta[i];
      // Gsoft_tk =0.5*k_soft*kT0*tdev*tdev;
      // dGsoftdt_tk[i] =k_soft*kT0*tdev/V1eff_inv[i];

      // tdev=condens_tcl[i]/V1eff_inv[i]-theta_cl[i];
      // Gsoft_tcl=0.5*k_soft*kT0*tdev*tdev;
      // dGsoftdt_tcl[i]=k_soft*kT0*tdev/V1eff_inv[i];

      // dGsoftdV1=(dGsoftdt_tk[i]*condens_tk[i]+dGsoftdt_tcl[i]*condens_tcl[i])/(-V1eff_inv[i]);

      // tdev=condens_ek[i] /V2eff_inv[i]-eta[i];
      // Gsoft_ek =0.5*k_soft*kT0*tdev*tdev;
      // dGsoftde_ek[i] =k_soft*kT0*tdev/V2eff_inv[i];

      // tdev=condens_ecl[i]/V2eff_inv[i]-eta_cl[i];
      // Gsoft_ecl=0.5*k_soft*kT0*tdev*tdev;
      // dGsoftde_ecl[i]=k_soft*kT0*tdev/V2eff_inv[i];

      // dGsoftdV2=(dGsoftde_ek[i]*condens_ek[i]+dGsoftde_ecl[i]*condens_ecl[i])/(-V2eff_inv[i]);

      dens_tk[i] =theta[i]   *V1eff_inv[i]+conc_KCl-conc_K *pot_t[i]/kT;
      Gmix_tk =kT*dV*conc_K*xlnxmx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);
      dGmixdt_tk =kT*dV*lnx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);

      dens_tcl[i]=theta_cl[i]*V1eff_inv[i]+conc_KCl+conc_Cl*pot_t[i]/kT;
      Gmix_tcl=kT*dV*conc_Cl*xlnxmx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);
      dGmixdt_tcl=kT*dV*lnx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);

      dGmixdpot=-(dGmixdt_tk*conc_K-dGmixdt_tcl*conc_Cl)/kT;
      dGmixdV1= (Gmix_tk+Gmix_tcl)/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGmixdV1+=(dGmixdt_tk*theta[i]+dGmixdt_tcl*theta_cl[i]);
      dGmixdV2=-(Gmix_tk+Gmix_tcl)/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      dens_ek[i] =eta[i]   *V2eff_inv[i]+theta[i] *V1eff_inv[i]+conc_KCl-conc_K *pot_e[i]/kT;
      Ghole_ek =0.5*k_prohibit*kT0*V2*V2*dens_ek[i] *dens_ek[i];
      dGholede_ek =k_prohibit*kT0*V2*V2*dens_ek[i];

      dens_ecl[i]=eta_cl[i]*V2eff_inv[i]+theta_cl[i]*V1eff_inv[i]+conc_KCl+conc_Cl*pot_e[i]/kT;
      Ghole_ecl=0.5*k_prohibit*kT0*V2*V2*dens_ecl[i]*dens_ecl[i];
      dGholede_ecl=k_prohibit*kT0*V2*V2*dens_ecl[i];

      dGholedpot=-(dGholede_ek*conc_K-dGholede_ecl*conc_Cl)/kT;
      dGholedV1=dGholede_ek*theta[i]+dGholede_ecl*theta_cl[i];
      dGholedV2=dGholede_ek*eta[i]  +dGholede_ecl*eta_cl[i];

      Gpot=-0.5*dV*(conc_K+conc_Cl)/kT*pot_t[i]*pot_t[i];
      dGpotdpot=-dV*(conc_K+conc_Cl)/kT*pot_t[i];

      dGpotdV1= Gpot/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGpotdV2=-Gpot/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      // G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gsoft_tk+Gsoft_tcl+Gsoft_ek+Gsoft_ecl+Gpot;
      G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gpot;
      // dGdtk[i] =dGmixdt_tk +dGholede_ek +dGsoftdt_tk[i];
      // dGdtcl[i]=dGmixdt_tcl+dGholede_ecl+dGsoftdt_tcl[i];
      dGdtk[i] =(dGmixdt_tk +dGholede_ek )*V1eff_inv[i];
      dGdtcl[i]=(dGmixdt_tcl+dGholede_ecl)*V1eff_inv[i];
      // dGdek[i] =dGholede_ek +dGsoftde_ek[i];
      // dGdecl[i]=dGholede_ecl+dGsoftde_ecl[i];
      dGdek[i] =dGholede_ek *V2eff_inv[i];
      dGdecl[i]=dGholede_ecl*V2eff_inv[i];
      dGdtpot[i]=dGmixdpot+dGpotdpot;
      dGdepot[i]=dGholedpot;
      // dGdV1[i]=dGmixdV1+dGsoftdV1+dGpotdV1;
      // dGdV2[i]=dGmixdV2+dGsoftdV2+dGpotdV2;
      dGdV1[i]=dGmixdV1+dGholedV1+dGpotdV1;
      dGdV2[i]=dGmixdV2+dGholedV2+dGpotdV2;
    }
  }

  // stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);

#pragma omp barrier

  // Wait for collation to finish and compute free energy of mixing
  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    fti_buf=0;
    fei_buf=0;
    if (bP[ii]) {
      Gt+=G[ii];
      // Gt+=Gmix_tk[ii]+Gmix_tcl[ii]+Ghole_ek[ii]+Ghole_ecl[ii];
      // Gt+=Gsoft_tk[ii]+Gsoft_tcl[ii]+Gsoft_ek[ii]+Gsoft_ecl[ii];
      // Gt+=Gpot[ii];

      fti_buf+=-pot_t[ii];
      fei_buf+=-pot_e[ii];

      Eij=tab->point[0][eT_DH11].A0;
      // fti_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      // fti_buf+=-dGholedpot[ii]*Eij;
      // fei_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdepot[ii]*Eij;
      fei_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      // fei_buf+=-dGholedpot[ii]*Eij;
      fei_buf+=-dGdepot[ii]*Eij;
      
      // Pij=1/V1;
      // Pij=tab->point[0][eT_G1].A0;
      // ft_k[ii] +=-dGmixdt_tk[ii]*Pij;
      // ft_cl[ii]+=-dGmixdt_tcl[ii]*Pij;
      // ft_k[ii] +=-dGholede_ek[ii]*Pij;
      // ft_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // ft_k[ii] +=-dGsoftdt_tk[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_cl[ii]+=-dGsoftdt_tcl[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_k[ii] +=-dGdtk[ii]*Pij +dGsoftdt_tk[ii]*V1eff_inv[ii];
      // ft_cl[ii]+=-dGdtcl[ii]*Pij+dGsoftdt_tcl[ii]*V1eff_inv[ii];
      ft_k[ii] +=-dGdtk[ii];
      ft_cl[ii]+=-dGdtcl[ii];

      // Pij=1/V2;
      // Pij=tab->point[0][eT_G2].A0;
      // fe_k[ii] +=-dGholede_ek[ii]*Pij;
      // fe_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // fe_k[ii] +=-dGsoftde_ek[ii]*(Pij-V2eff_inv[ii]);
      // fe_cl[ii]+=-dGsoftde_ecl[ii]*(Pij-V2eff_inv[ii]);
      // fe_k[ii] +=-dGdek[ii]*Pij +dGsoftde_ek[ii]*V1eff_inv[ii];
      // fe_cl[ii]+=-dGdecl[ii]*Pij+dGsoftde_ecl[ii]*V1eff_inv[ii];
      fe_k[ii] +=-dGdek[ii];
      fe_cl[ii]+=-dGdecl[ii];
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      // shiftij=md->state->nlelec[ID]->shiftij[j];
      // vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // r=vec_mag(dr);
      // if (data->r<=rc) { // TRY
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;
        ftj_buf=0;
        fej_buf=0;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        // fr_buf+=(qi*dGmixdpot[jj]+qj*dGmixdpot[ii]+
        //          qi*dGpotdpot[jj]+qj*dGpotdpot[ii])*Frij;
        fr_buf+=(qi*dGdtpot[jj]+qj*dGdtpot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        // fr_buf+=(ti*dGmixdpot[jj]+tj*dGmixdpot[ii]+
        //          ti*dGpotdpot[jj]+tj*dGpotdpot[ii])*Frij;
        // fti_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // ftj_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ti*dGdtpot[jj]+tj*dGdtpot[ii])*Frij;
        fti_buf+=-(dGdtpot[jj])*Eij;
        ftj_buf+=-(dGdtpot[ii])*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        // fr_buf+=(qi*dGholedpot[jj]+qj*dGholedpot[ii])*Frij;
        fr_buf+=(qi*dGdepot[jj]+qj*dGdepot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        // fr_buf+=(ei*dGmixdpot[jj]+ej*dGmixdpot[ii]+
        //          ti*dGholedpot[jj]+tj*dGholedpot[ii]+
        //          ei*dGpotdpot[jj]+ej*dGpotdpot[ii])*Frij;
        // fti_buf+=-dGholedpot[jj]*Eij;
        // ftj_buf+=-dGholedpot[ii]*Eij;
        // fei_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // fej_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ei*dGdtpot[jj]+ej*dGdtpot[ii]+ti*dGdepot[jj]+tj*dGdepot[ii])*Frij;
        fti_buf+=-dGdepot[jj]*Eij;
        ftj_buf+=-dGdepot[ii]*Eij;
        fei_buf+=-dGdtpot[jj]*Eij;
        fej_buf+=-dGdtpot[ii]*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        // fr_buf+=(ei*dGholedpot[jj]+ej*dGholedpot[ii])*Frij;
        // fei_buf+=-dGholedpot[jj]*Eij;
        // fej_buf+=-dGholedpot[ii]*Eij;
        fr_buf+=(ei*dGdepot[jj]+ej*dGdepot[ii])*Frij;
        fei_buf+=-dGdepot[jj]*Eij;
        fej_buf+=-dGdepot[ii]*Eij;

        // if (bP[ii] && bP[jj]) { // TRY
          // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
          // Frij=Pij/(gauss_01*gauss_01);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // Pij=bP[ii]*bP[jj]*data->Eij[eT_G1];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G1];
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // fr_buf+=(dGmixdt_tk[jj]*theta[ii]+dGmixdt_tk[ii]*theta[jj]+dGmixdt_tcl[jj]*theta_cl[ii]+dGmixdt_tcl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGholede_ek[jj]*theta[ii]+dGholede_ek[ii]*theta[jj]+dGholede_ecl[jj]*theta_cl[ii]+dGholede_ecl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGsoftdt_tk[jj]*theta[ii]+dGsoftdt_tcl[jj]*theta_cl[ii]+dGsoftdt_tk[ii]*theta[jj]+dGsoftdt_tcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGmixdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGmixdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGmixdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGmixdt_tcl[ii]*Pij;
          // ft_k[ii] +=-dGholede_ek[jj]*Pij;
          // ft_k[jj] +=-dGholede_ek[ii]*Pij;
          // ft_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // ft_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // ft_k[ii] +=-dGsoftdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGsoftdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGsoftdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGsoftdt_tcl[ii]*Pij;
          // fr_buf+=(dGmixdV1[jj]+dGmixdV1[ii])*Frij;
          // fr_buf+=(dGsoftdV1[jj]+dGsoftdV1[ii])*Frij;
          // fr_buf+=(dGpotdV1[jj]+dGpotdV1[ii])*Frij;
          // fr_buf+=(dGdtk[jj]*theta[ii]+dGdtk[ii]*theta[jj]+dGdtcl[jj]*theta_cl[ii]+dGdtcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGdtk[jj]*Pij;
          // ft_k[jj] +=-dGdtk[ii]*Pij;
          // ft_cl[ii]+=-dGdtcl[jj]*Pij;
          // ft_cl[jj]+=-dGdtcl[ii]*Pij;
          fr_buf+=(dGdV1[jj]+dGdV1[ii])*Frij;

          // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
          // Frij=Pij/(gauss_02*gauss_02);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // Pij=bP[ii]*bP[jj]*data->Eij[eT_G2];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G2];
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // fr_buf+=(dGholede_ek[jj]*eta[ii]+dGholede_ek[ii]*eta[jj]+dGholede_ecl[jj]*eta_cl[ii]+dGholede_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGholede_ek[jj]*Pij;
          // fe_k[jj] +=-dGholede_ek[ii]*Pij;
          // fe_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // fr_buf+=(dGsoftde_ek[jj]*eta[ii]+dGsoftde_ecl[jj]*eta_cl[ii]+dGsoftde_ek[ii]*eta[jj]+dGsoftde_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGsoftde_ek[jj]*Pij;
          // fe_k[jj] +=-dGsoftde_ek[ii]*Pij;
          // fe_cl[ii]+=-dGsoftde_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGsoftde_ecl[ii]*Pij;
          // fr_buf+=(dGmixdV2[jj]+dGmixdV2[ii])*Frij;
          // fr_buf+=(dGsoftdV2[jj]+dGsoftdV2[ii])*Frij;
          // fr_buf+=(dGpotdV2[jj]+dGpotdV2[ii])*Frij;
          // fr_buf+=(dGdek[jj]*eta[ii]+dGdek[ii]*eta[jj]+dGdecl[jj]*eta_cl[ii]+dGdecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGdek[jj]*Pij;
          // fe_k[jj] +=-dGdek[ii]*Pij;
          // fe_cl[ii]+=-dGdecl[jj]*Pij;
          // fe_cl[jj]+=-dGdecl[ii]*Pij;
          fr_buf+=(dGdV2[jj]+dGdV2[ii])*Frij;
        // }

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units

        ft_k[jj] += ftj_buf;
        ft_cl[jj]+=-ftj_buf;
        fe_k[jj] += fej_buf;
        fe_cl[jj]+=-fej_buf;
      // }
    }
    ft_k[ii] += fti_buf;
    ft_cl[ii]+=-fti_buf;
    fe_k[ii] += fei_buf;
    fe_cl[ii]+=-fei_buf;
  }

  md->state->Gt->local[ID][0]+=Gt*(kTr0/kT0); // Convert units
  md->state->Gts->local[ID][eE_elec]+=Gt*(kTr0/kT0); // Convert units

  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);
}


void getforce_elec_v3(struct_md* md)
{
  struct_qlist *qqlist=md->state->qqlist;
  int ID,NID,imin,imax;
  int Ni=md->state->manningcc_tk->Ni;
  int Nf=md->state->manningcc_tk->Nf;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,Frij,cij,Pij;
  struct_nldata *data;
  double qi,qj,ti,tj,ei,ej;
#ifdef POLARIZE
  double pi[DIM3],pj[DIM3];
#endif
  double tdev;
  double fr_buf,fti_buf,ftj_buf,fei_buf,fej_buf;
#ifdef POLARIZE
  double fpi_buf,fpj_buf;
#endif
  double Gt=0;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=qqlist->theta;
  double *theta_cl=qqlist->theta_cl;
  double *eta=qqlist->eta;
  double *eta_cl=qqlist->eta_cl;
#ifdef POLARIZE
  double *polar=qqlist->polar;
  double *polar_cl=qqlist->polar_cl;
#endif
  double *bP=qqlist->bP;
  double *fx, *ft_k, *ft_cl, *fe_k, *fe_cl;
#ifdef POLARIZE
  double *fp_k, *fp_cl;
#endif
  double *pot_t, *pot_e;
  double *V1eff_inv,*V2eff_inv;
  double *condens_tk,*condens_tcl;
  double *condens_ek,*condens_ecl;
#ifdef POLARIZE
  double *condens_pk,*condens_pcl;
#endif
#ifdef POLARIZE_LATER
  double *condens_vpk,*condens_vpcl;
#endif
  double *dens_tk=qqlist->dens_tk;
  double *dens_tcl=qqlist->dens_tcl;
  double *dens_ek=qqlist->dens_ek;
  double *dens_ecl=qqlist->dens_ecl;
  double *dGsoftdt_tk=qqlist->dGsoftdt_tk;
  double *dGsoftdt_tcl=qqlist->dGsoftdt_tcl;
  double *dGsoftde_ek=qqlist->dGsoftde_ek;
  double *dGsoftde_ecl=qqlist->dGsoftde_ecl;
  double dV;
  double Gmix_tk,Gmix_tcl,dGmixdt_tk,dGmixdt_tcl;
  double Ghole_ek,Ghole_ecl,dGholede_ek,dGholede_ecl;
  double Gsoft_tk,Gsoft_tcl,Gsoft_ek,Gsoft_ecl,Gpot;
#ifdef POLARIZE
  double Gpolar_k,Gpolar_cl,dGpoldV1,dGpoldpot;
#endif
  double dGpotdpot,dGmixdpot,dGholedpot;
  double dGsoftdV1,dGsoftdV2,dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double *G=qqlist->G;
  double *dGdtk=qqlist->dGdtk;
  double *dGdtcl=qqlist->dGdtcl;
  double *dGdek=qqlist->dGdek;
  double *dGdecl=qqlist->dGdecl;
  double *dGdtpot=qqlist->dGdtpot;
  double *dGdepot=qqlist->dGdepot;
  double *dGdV1=qqlist->dGdV1;
  double *dGdV2=qqlist->dGdV2;
#ifdef POLARIZE
  double *dGdpk=qqlist->dGdpk;
  double *dGdpcl=qqlist->dGdpcl;
#endif
#ifdef POLARIZE_LATER
  double *gGdvpk=qqlist->gGvdpk;
  double *gGdvpcl=qqlist->gGdvpcl;
#endif
  int nqlist;
  int *qlist;
  // double lB,kappa,conc_KCl,f_KCl,V,kT,kT0,kTr0,rc,V1,V2;
  double lB,kappa,conc_KCl,conc_K,conc_Cl,V,kT,kT0,kTr0,rc,V1,V2;
#ifdef POLARIZE
  double s1=md->parms->gauss_01;
  double s2=md->parms->gauss_02;
#endif
  // double gauss_00=md->parms->gauss_00;
  // double gauss_01=md->parms->gauss_01;
  // double gauss_02=md->parms->gauss_02;
  // double gauss_11=md->parms->gauss_11;
  // double gauss_12=md->parms->gauss_12;
  // double gauss_22=md->parms->gauss_22;
  double k_prohibit=md->parms->k_prohibit;
  double k_soft=md->parms->k_soft;
#ifdef POLARIZE
  double *polar_0=md->state->qqlist->polar_0;
  double *polar_cl_0=md->state->qqlist->polar_cl_0;
  double *k_pk=md->state->qqlist->k_polar;
  double *k_pcl=md->state->qqlist->k_polar_cl;
#endif
  // Table variables
  struct_tables *tab=md->parms->elec_tables;
  // int Ntab=tab->N;
  // double hinv=tab->hinv;
  // int itab;
  // double xtab,xtab2,xtab3;
  gmx_cycles_t start,start0,stop;

  // PHASE 3.0

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;

  fx=md->state->atoms->f->local[ID];
  ft_k=md->state->manningcc_tk->f->local[ID];
  ft_cl=md->state->manningcc_tcl->f->local[ID];
  fe_k=md->state->manningcc_ek->f->local[ID];
  fe_cl=md->state->manningcc_ecl->f->local[ID];
#ifdef POLARIZE
  fp_k=md->state->manningcc_pk->f->local[ID];
  fp_cl=md->state->manningcc_pcl->f->local[ID];
#endif

  condens_tk=resetlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=resetlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=resetlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=resetlocal_collate(md->state->qqlist->condens_ecl,ID);
#ifdef POLARIZE
  condens_pk=resetlocal_collate(md->state->qqlist->condens_pk,ID);
  condens_pcl=resetlocal_collate(md->state->qqlist->condens_pcl,ID);
#endif
#ifdef POLARIZE_LATER
  condens_vpk=resetlocal_collate(md->state->qqlist->condens_vpk,ID);
  condens_vpcl=resetlocal_collate(md->state->qqlist->condens_vpcl,ID);
#endif
  pot_t=resetlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=resetlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=resetlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=resetlocal_collate(md->state->qqlist->V2eff_inv,ID);

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_KCl=md->parms->conc_KCl;
  // f_KCl=md->parms->f_KCl;
  conc_K=md->parms->conc_K;
  conc_Cl=md->parms->conc_Cl;
  V1=md->parms->V1;
  V2=md->parms->V2;
  kT=md->parms->kT;
  kT0=md->parms->kT0;
  kTr0=md->parms->kTr0;
  rc=md->parms->rcelec;

  // PHASE 3.1

  start=gmx_cycles_read();
  start0=start;

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
#ifdef POLARIZE
    vec_subtract(polar+DIM3*ii,polar_cl+DIM3*ii,pi);
#endif
    if (bP[ii]) {
      Eij=tab->point[0][eT_DH01].A0;
      Gt+=qi*ti*Eij;
      pot_t[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH11].A0;
      Gt+=0.5*ti*ti*Eij;
      pot_t[ii]+=ti*Eij;
      
      Eij=tab->point[0][eT_DH02].A0;
      Gt+=qi*ei*Eij;
      pot_e[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      Gt+=ti*ei*Eij;
      pot_t[ii]+=ei*Eij;
      pot_e[ii]+=ti*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      Gt+=0.5*ei*ei*Eij;
      pot_e[ii]+=ei*Eij;

      // Pij=1.0/V1;
      Pij=tab->point[0][eT_G1].A0;
      condens_tk[ii]+=theta[ii]*Pij;
      condens_tcl[ii]+=theta_cl[ii]*Pij;
      V1eff_inv[ii]+=Pij;

      // Pij=1.0/V2;
      Pij=tab->point[0][eT_G2].A0;
      condens_ek[ii]+=eta[ii]*Pij;
      condens_ecl[ii]+=eta_cl[ii]*Pij;
      V2eff_inv[ii]+=Pij;

#ifdef POLARIZE_LATER
      Pij=tab->point[0][eT_G1].A0;
      vec_scaleinc(condens_vpk+DIM3*ii,Pij,polar+DIM3*ii);
      vec_scaleinc(condens_vpcl+DIM3*ii,Pij,polar_cl+DIM3*ii);

      // Particle polarize
      // Eij=0

      // Mix polarize
      // Eij=0

      // Hole polarize
      // Eij=0

      // Polarize polarize
      Eij=tab->point[0][eT_gG1].A0; // Eish, division by 0...
#endif

#ifdef POLARIZE
      Eij=(s1*s1*s1*s1)*tab->point[0][eT_gDH11].A0;
      Gt+=-0.5*vec_dot(pi,pi)*Eij;
      vec_scaleinc(fp_k+DIM3*ii,  Eij,pi);
      vec_scaleinc(fp_cl+DIM3*ii,-Eij,pi); // sign error corrected
#endif
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,data->dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,data->dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(data->dr);
      // if (r<=rc) { // TRY
        // itab=((int) (r*hinv));
        // xtab=r*hinv-itab;
        // xtab2=xtab*xtab;
        // xtab3=xtab2*xtab;
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
#ifdef POLARIZE
        vec_subtract(polar+DIM3*jj,polar_cl+DIM3*jj,pj);
        fpi_buf=0;
        fpj_buf=0;
#endif
        fr_buf=0;

        data->r=r;
        // tables_interp(tab,data,md);
        if (tables_interp(tab,data)) {
          md->state->abortflag=1;
          break;
        }
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&(data->Eij00),&(data->Frij00));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&(data->Eij01),&(data->Frij01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&(data->Eij11),&(data->Frij11));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&(data->Eij02),&(data->Frij02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&(data->Eij12),&(data->Frij12));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&(data->Eij22),&(data->Frij22));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&(data->Pij1),&(data->Qrij1));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&(data->Pij2),&(data->Qrij2));

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&Eij,&Frij);
        Eij=data->Eij[eT_DH00];
        Frij=data->Frij[eT_DH00];
        Gt+=qi*qj*Eij;
        fr_buf+=qi*qj*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        Gt+=(ti*qj+tj*qi)*Eij;
        fr_buf+=(ti*qj+tj*qi)*Frij;
        pot_t[ii]+=qj*Eij;
        pot_t[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        Gt+=ti*tj*Eij;
        fr_buf+=ti*tj*Frij;
        pot_t[ii]+=tj*Eij;
        pot_t[jj]+=ti*Eij;
       
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        Gt+=(qi*ej+qj*ei)*Eij;
        fr_buf+=(qi*ej+qj*ei)*Frij;
        pot_e[ii]+=qj*Eij;
        pot_e[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        Gt+=(ti*ej+tj*ei)*Eij;
        fr_buf+=(ti*ej+tj*ei)*Frij;
        pot_t[ii]+=ej*Eij;
        pot_t[jj]+=ei*Eij;
        pot_e[ii]+=tj*Eij;
        pot_e[jj]+=ti*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        Gt+=ei*ej*Eij;
        fr_buf+=ei*ej*Frij;
        pot_e[ii]+=ej*Eij;
        pot_e[jj]+=ei*Eij;

        // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        condens_tk[ii]+=theta[jj]*Pij;
        condens_tk[jj]+=theta[ii]*Pij;
        condens_tcl[ii]+=theta_cl[jj]*Pij;
        condens_tcl[jj]+=theta_cl[ii]*Pij;
        V1eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V1eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V1eff_inv[ii]+=Pij;
        // V1eff_inv[jj]+=Pij;

        // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        condens_ek[ii]+=eta[jj]*Pij;
        condens_ek[jj]+=eta[ii]*Pij;
        condens_ecl[ii]+=eta_cl[jj]*Pij;
        condens_ecl[jj]+=eta_cl[ii]*Pij;
        V2eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V2eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V2eff_inv[ii]+=Pij;
        // V2eff_inv[jj]+=Pij;

#ifdef POLARIZE
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        condens_pk[ii]+= vec_dot(polar+DIM3*jj,data->dr)*Pij;
        condens_pk[jj]+=-vec_dot(polar+DIM3*ii,data->dr)*Pij;
        condens_pcl[ii]+= vec_dot(polar_cl+DIM3*jj,data->dr)*Pij;
        condens_pcl[jj]+=-vec_dot(polar_cl+DIM3*ii,data->dr)*Pij;

#ifdef POLARIZE_LATER
errors? y:n;
        vec_scaleinc(condens_vpk+DIM3*ii,-theta[jj]*Pij/(s1*s1),data->dr);
        vec_scaleinc(condens_vpk+DIM3*jj,-theta[ii]*Pij/(s1*s1),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*ii,-theta_cl[jj]*Pij/(s1*s1),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*jj,-theta_cl[ii]*Pij/(s1*s1),data->dr);

        vec_scaleinc(condens_vpk+DIM3*ii,Pij,polar+DIM3*jj);
        vec_scaleinc(condens_vpk+DIM3*ii,-Pij*vec_dot(data->dr,polar+DIM3*jj)/(s1*s1),data->dr);
        vec_scaleinc(condens_vpk+DIM3*jj,Pij,polar+DIM3*ii);
        vec_scaleinc(condens_vpk+DIM3*jj,-Pij*vec_dot(data->dr,polar+DIM3*ii)/(s1*s1),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*ii,Pij,polar_cl+DIM3*jj);
        vec_scaleinc(condens_vpcl+DIM3*ii,-Pij*vec_dot(data->dr,polar_cl+DIM3*jj)/(s1*s1),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*jj,Pij,polar_cl+DIM3*ii);
        vec_scaleinc(condens_vpcl+DIM3*jj,-Pij*vec_dot(data->dr,polar_cl+DIM3*ii)/(s1*s1),data->dr);

        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        vec_scaleinc(condens_vpk+DIM3*ii,-eta[jj]*Pij/(s2*s2),data->dr);
        vec_scaleinc(condens_vpk+DIM3*jj,-eta[ii]*Pij/(s2*s2),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*ii,-eta_cl[jj]*Pij/(s2*s2),data->dr);
        vec_scaleinc(condens_vpcl+DIM3*jj,-eta_cl[ii]*Pij/(s2*s2),data->dr);
#endif
#endif

#ifdef POLARIZE
        // Point - Polarize
        Eij=(s1*s1)*data->Eij[eT_gDH01];
        Frij=(s1*s1)*data->Frij[eT_gDH01];
        Gt+=(qi*vec_dot(data->dr,pj)-qj*vec_dot(data->dr,pi))*Eij;
        fr_buf+=(qi*vec_dot(data->dr,pj)-qj*vec_dot(data->dr,pi))*Frij;
        fpi_buf+=-qj*-Eij;
        fpj_buf+= qi*-Eij;
        
        // Mix - Polarize
        Eij=(s1*s1)*data->Eij[eT_gDH11];
        Frij=(s1*s1)*data->Frij[eT_gDH11];
        Gt+=(ti*vec_dot(data->dr,pj)-tj*vec_dot(data->dr,pi))*Eij;
        fr_buf+=(ti*vec_dot(data->dr,pj)-tj*vec_dot(data->dr,pi))*Frij;
        fpi_buf+=-tj*-Eij;
        fpj_buf+= ti*-Eij;
        pot_t[ii]+= vec_dot(data->dr,pj)*Eij;
        pot_t[jj]+=-vec_dot(data->dr,pi)*Eij;
        
        // Hole - Polarize
        Eij=(s1*s1)*data->Eij[eT_gDH12];
        Frij=(s1*s1)*data->Frij[eT_gDH12];
        Gt+=(ei*vec_dot(data->dr,pj)-ej*vec_dot(data->dr,pi))*Eij;
        fr_buf+=(ei*vec_dot(data->dr,pj)-ej*vec_dot(data->dr,pi))*Frij;
        fpi_buf+=-ej*-Eij;
        fpj_buf+= ei*-Eij;
        pot_e[ii]+= vec_dot(data->dr,pj)*Eij;
        pot_e[jj]+=-vec_dot(data->dr,pi)*Eij;
        
        // Polarize - Polarize
        Eij=(s1*s1*s1*s1)*data->Eij[eT_gDH11];
        Frij=(s1*s1*s1*s1)*data->Frij[eT_gDH11];
        Gt+=-vec_dot(pi,pj)*Eij;
        fr_buf+=-vec_dot(pi,pj)*Frij;
        vec_scaleinc(fx+DIM3*iii,-vec_dot(pi,data->dr)*Frij*(kTr0/kT0),pj);//CU
        vec_scaleinc(fx+DIM3*iii,-vec_dot(pj,data->dr)*Frij*(kTr0/kT0),pi);//CU
        vec_scaleinc(fx+DIM3*jjj, vec_dot(pi,data->dr)*Frij*(kTr0/kT0),pj);//CU
        vec_scaleinc(fx+DIM3*jjj, vec_dot(pj,data->dr)*Frij*(kTr0/kT0),pi);//CU
        vec_scaleinc(fp_k+DIM3*ii,  Eij,pj);
        vec_scaleinc(fp_cl+DIM3*ii,-Eij,pj);
        vec_scaleinc(fp_k+DIM3*jj,  Eij,pi);
        vec_scaleinc(fp_cl+DIM3*jj,-Eij,pi);

        Eij=(s1*s1*s1*s1)*data->Eij[eT_ggDH11];
        Frij=(s1*s1*s1*s1)*data->Frij[eT_ggDH11];
        Gt+=-vec_dot(pi,data->dr)*vec_dot(pj,data->dr)*Eij;
        fr_buf+=-vec_dot(pi,data->dr)*vec_dot(pj,data->dr)*Frij;
        vec_scaleinc(fp_k+DIM3*ii,  vec_dot(pj,data->dr)*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*ii,-vec_dot(pj,data->dr)*Eij,data->dr);
        vec_scaleinc(fp_k+DIM3*jj,  vec_dot(pi,data->dr)*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*jj,-vec_dot(pi,data->dr)*Eij,data->dr);
#endif

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
#ifdef POLARIZE
        vec_scaleinc(fx+DIM3*iii, fpi_buf*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fx+DIM3*iii, fpj_buf*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fpi_buf*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fpj_buf*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fp_k+DIM3*ii,  fpi_buf,data->dr);
        vec_scaleinc(fp_cl+DIM3*ii,-fpi_buf,data->dr);
        vec_scaleinc(fp_k+DIM3*jj,  fpj_buf,data->dr);
        vec_scaleinc(fp_cl+DIM3*jj,-fpj_buf,data->dr);
#endif
      // }
    }
    if (md->state->abortflag) {
      break;
    }
  }
  
  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);

#pragma omp barrier
  if (md->state->abortflag) {
    #pragma omp master
    {
      fprintf(stderr,"Fatal error: neighbor interaction distance is longer than table cutoff\n");
      printgroframe(md,"crash");
      #ifndef NOMPI
      MPI_Finalize();
      #endif
      exit(0);
    }
  }

  // PHASE 3.2

  // Wait for all nodes to finish, and coallate things required to compute free energy of mixing
  start=gmx_cycles_read();
  
  condens_tk=sumlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=sumlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=sumlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=sumlocal_collate(md->state->qqlist->condens_ecl,ID);
#ifdef POLARIZE
  condens_pk=sumlocal_collate(md->state->qqlist->condens_pk,ID);
  condens_pcl=sumlocal_collate(md->state->qqlist->condens_pcl,ID);
#endif
#ifdef POLARIZE_LATER
  condens_vpk=sumlocal_collate(md->state->qqlist->condens_vpk,ID);
  condens_vpcl=sumlocal_collate(md->state->qqlist->condens_vpcl,ID);
#endif
  pot_t=sumlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=sumlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=sumlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=sumlocal_collate(md->state->qqlist->V2eff_inv,ID);

  // imin=(qqlist->nqlist * ID)/NID;
  // imax=(qqlist->nqlist * (ID+1))/NID;
  imin=Ni+((Nf-Ni)*ID)/NID;
  imax=Ni+((Nf-Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    if (bP[i]) { // Otherwise, all these things stay zero.
      dV=(1/V1eff_inv[i]-1/V2eff_inv[i]);

      tdev=condens_tk[i] /V1eff_inv[i]-theta[i];
      Gsoft_tk =0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tk[i] =k_soft*kT0*tdev/V1eff_inv[i];

      tdev=condens_tcl[i]/V1eff_inv[i]-theta_cl[i];
      Gsoft_tcl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tcl[i]=k_soft*kT0*tdev/V1eff_inv[i];

      dGsoftdV1=(dGsoftdt_tk[i]*condens_tk[i]+dGsoftdt_tcl[i]*condens_tcl[i])/(-V1eff_inv[i]);

      tdev=condens_ek[i] /V2eff_inv[i]-eta[i];
      Gsoft_ek =0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ek[i] =k_soft*kT0*tdev/V2eff_inv[i];

      tdev=condens_ecl[i]/V2eff_inv[i]-eta_cl[i];
      Gsoft_ecl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ecl[i]=k_soft*kT0*tdev/V2eff_inv[i];

      dGsoftdV2=(dGsoftde_ek[i]*condens_ek[i]+dGsoftde_ecl[i]*condens_ecl[i])/(-V2eff_inv[i]);

      dens_tk[i] =condens_tk[i] +conc_KCl-conc_K *pot_t[i]/kT;
#ifdef POLARIZE
      dens_tk[i] +=condens_pk[i];
#endif
      Gmix_tk =kT*dV*conc_K*xlnxmx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);
      dGmixdt_tk =kT*dV*lnx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);

      dens_tcl[i]=condens_tcl[i]+conc_KCl+conc_Cl*pot_t[i]/kT;
#ifdef POLARIZE
      dens_tcl[i]+=condens_pcl[i];
#endif
      Gmix_tcl=kT*dV*conc_Cl*xlnxmx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);
      dGmixdt_tcl=kT*dV*lnx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);

      dGmixdpot=-(dGmixdt_tk*conc_K-dGmixdt_tcl*conc_Cl)/kT;
      dGmixdV1= (Gmix_tk+Gmix_tcl)/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGmixdV2=-(Gmix_tk+Gmix_tcl)/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      dens_ek[i] =condens_ek[i] +condens_tk[i] +conc_KCl-conc_K *pot_e[i]/kT;
#ifdef POLARIZE
      dens_ek[i] +=condens_pk[i];
#endif
      Ghole_ek =0.5*k_prohibit*kT0*V2*V2*dens_ek[i] *dens_ek[i];
      dGholede_ek =k_prohibit*kT0*V2*V2*dens_ek[i];

      dens_ecl[i]=condens_ecl[i]+condens_tcl[i]+conc_KCl+conc_Cl*pot_e[i]/kT;
#ifdef POLARIZE
      dens_ecl[i]+=condens_pcl[i];
#endif
      Ghole_ecl=0.5*k_prohibit*kT0*V2*V2*dens_ecl[i]*dens_ecl[i];
      dGholede_ecl=k_prohibit*kT0*V2*V2*dens_ecl[i];

      dGholedpot=-(dGholede_ek*conc_K-dGholede_ecl*conc_Cl)/kT;

      Gpot=-0.5*dV*(conc_K+conc_Cl)/kT*pot_t[i]*pot_t[i];
      dGpotdpot=-dV*(conc_K+conc_Cl)/kT*pot_t[i];

      dGpotdV1= Gpot/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGpotdV2=-Gpot/(-dV*V2eff_inv[i]*V2eff_inv[i]);

#ifdef POLARIZE_LATER
may be redundant with harmonic constraints later
      Gpolar_k=0.5*kT*vec_mag2(condens_vpk+DIM3*i)*vec_mag2(condens_vpk+DIM3*i);
      vec_scale(gGdvpk+DIM3*i,2.0*kT*vec_mag2(condens_vpk+DIM3*i),condens_vpk+DIM3*i);

      Gpolar_cl=0.5*kT*vec_mag2(condens_vpcl+DIM3*i)*vec_mag2(condens_vpcl+DIM3*i);
      vec_scale(gGdvpcl+DIM3*i,2.0*kT*vec_mag2(condens_vpcl+DIM3*i),condens_vpcl+DIM3*i);
#endif

#ifdef POLARIZE
#ifdef POLARIZE_NOW
      for (j=0; j<DIM3; j++) {
        polar_0[DIM3*i+j]=0;
        polar_cl_0[DIM3*i+j]=0;
      }

      // k_pk[i] =(s1/2.0)*V1eff_inv[i]/(conc_K *exp(-pot_t[i]/kT));
      // k_pcl[i]=(s1/2.0)*V1eff_inv[i]/(conc_Cl*exp( pot_t[i]/kT));
      k_pk[i] =(0.5*s1/conc_K )*V1eff_inv[i]*exp( pot_t[i]/kT);
      k_pcl[i]=(0.5*s1/conc_Cl)*V1eff_inv[i]*exp(-pot_t[i]/kT);

      Gpolar_k=0;
      Gpolar_cl=0;
      dGpoldV1=0;
      dGpoldpot=0;
      for (j=0; j<DIM3; j++) {
        tdev=k_pk[i]*(polar[DIM3*i+j]-polar_0[DIM3*i+j]);
        fp_k[DIM3*i+j]+=-(kT0*k_pk[i]*tdev);
        Gpolar_k+=0.5*(kT0*tdev*tdev);
        dGpoldV1+=(kT0*tdev*tdev)/V1eff_inv[i];
        dGpoldpot+=(kT0*tdev*tdev)/kT;

        tdev=k_pcl[i]*(polar_cl[DIM3*i+j]-polar_cl_0[DIM3*i+j]);
        fp_cl[DIM3*i+j]+=-(kT0*k_pcl[i]*tdev);
        Gpolar_cl+=0.5*(kT0*tdev*tdev);
        dGpoldV1+=(kT0*tdev*tdev)/V1eff_inv[i];
        dGpoldpot+=-(kT0*tdev*tdev)/kT;
      }
#else
      for (j=0; j<DIM3; j++) {
        polar_0[DIM3*i+j]=0;
        polar_cl_0[DIM3*i+j]=0;
      }

      k_pk[ii]=1.0;
      k_pcl[ii]=1.0;

      Gpolar_k=0;
      Gpolar_cl=0;
      dGpoldV1=0;
      dGpoldpot=0;
      for (j=0; j<DIM3; j++) {
        tdev=k_pk[i]*(polar[DIM3*i+j]-polar_0[DIM3*i+j]);
        fp_k[DIM3*i+j]+=-kT0*k_pk[i]*tdev;
        Gpolar_k+=0.5*kT0*tdev*tdev;

        tdev=k_pcl[i]*(polar_cl[DIM3*i+j]-polar_cl_0[DIM3*i+j]);
        fp_cl[DIM3*i+j]+=-kT0*k_pcl[i]*tdev;
        Gpolar_cl+=0.5*kT0*tdev*tdev;
      }
#endif
#endif

      G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gsoft_tk+Gsoft_tcl+Gsoft_ek+Gsoft_ecl+Gpot;
#ifdef POLARIZE
      G[i]+=Gpolar_k+Gpolar_cl;
#endif
      dGdtk[i] =dGmixdt_tk +dGholede_ek +dGsoftdt_tk[i];
      dGdtcl[i]=dGmixdt_tcl+dGholede_ecl+dGsoftdt_tcl[i];
      dGdek[i] =dGholede_ek +dGsoftde_ek[i];
      dGdecl[i]=dGholede_ecl+dGsoftde_ecl[i];
      dGdtpot[i]=dGmixdpot+dGpotdpot;
      dGdepot[i]=dGholedpot;
      dGdV1[i]=dGmixdV1+dGsoftdV1+dGpotdV1;
      dGdV2[i]=dGmixdV2+dGsoftdV2+dGpotdV2;
#ifdef POLARIZE
      dGdpk[i]=dGmixdt_tk+dGholede_ek;
      dGdpcl[i]=dGmixdt_tcl+dGholede_ecl;
      dGdtpot[i]+=dGpoldpot;
      dGdV1[i]+=dGpoldV1;
#endif
    }
  }

  // stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);

#pragma omp barrier

  // PHASE 3.3

  // Wait for collation to finish and compute free energy of mixing
  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
#ifdef POLARIZE_LATER
    vec_subtract(polar+DIM3*ii,polar_cl+DIM3*ii,pi);
#endif
    fti_buf=0;
    fei_buf=0;
    if (bP[ii]) {
      Gt+=G[ii];
      // Gt+=Gmix_tk[ii]+Gmix_tcl[ii]+Ghole_ek[ii]+Ghole_ecl[ii];
      // Gt+=Gsoft_tk[ii]+Gsoft_tcl[ii]+Gsoft_ek[ii]+Gsoft_ecl[ii];
      // Gt+=Gpot[ii];

      fti_buf+=-pot_t[ii];
      fei_buf+=-pot_e[ii];

      Eij=tab->point[0][eT_DH11].A0;
      // fti_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      // fti_buf+=-dGholedpot[ii]*Eij;
      // fei_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdepot[ii]*Eij;
      fei_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      // fei_buf+=-dGholedpot[ii]*Eij;
      fei_buf+=-dGdepot[ii]*Eij;
      
      // Pij=1/V1;
      Pij=tab->point[0][eT_G1].A0;
      // ft_k[ii] +=-dGmixdt_tk[ii]*Pij;
      // ft_cl[ii]+=-dGmixdt_tcl[ii]*Pij;
      // ft_k[ii] +=-dGholede_ek[ii]*Pij;
      // ft_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // ft_k[ii] +=-dGsoftdt_tk[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_cl[ii]+=-dGsoftdt_tcl[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      ft_k[ii] +=-dGdtk[ii]*Pij +dGsoftdt_tk[ii]*V1eff_inv[ii];
      ft_cl[ii]+=-dGdtcl[ii]*Pij+dGsoftdt_tcl[ii]*V1eff_inv[ii];

      // Pij=1/V2;
      Pij=tab->point[0][eT_G2].A0;
      // fe_k[ii] +=-dGholede_ek[ii]*Pij;
      // fe_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // fe_k[ii] +=-dGsoftde_ek[ii]*(Pij-V2eff_inv[ii]);
      // fe_cl[ii]+=-dGsoftde_ecl[ii]*(Pij-V2eff_inv[ii]);
      fe_k[ii] +=-dGdek[ii]*Pij +dGsoftde_ek[ii]*V1eff_inv[ii];
      fe_cl[ii]+=-dGdecl[ii]*Pij+dGsoftde_ecl[ii]*V1eff_inv[ii];
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      // shiftij=md->state->nlelec[ID]->shiftij[j];
      // vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // r=vec_mag(dr);
      // if (data->r<=rc) { // TRY
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
#ifdef POLARIZE_LATER
        vec_subtract(polar+DIM3*jj,polar_cl+DIM3*jj,pj);
#endif
        fr_buf=0;
        ftj_buf=0;
        fej_buf=0;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        // fr_buf+=(qi*dGmixdpot[jj]+qj*dGmixdpot[ii]+
        //          qi*dGpotdpot[jj]+qj*dGpotdpot[ii])*Frij;
        fr_buf+=(qi*dGdtpot[jj]+qj*dGdtpot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        // fr_buf+=(ti*dGmixdpot[jj]+tj*dGmixdpot[ii]+
        //          ti*dGpotdpot[jj]+tj*dGpotdpot[ii])*Frij;
        // fti_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // ftj_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ti*dGdtpot[jj]+tj*dGdtpot[ii])*Frij;
        fti_buf+=-(dGdtpot[jj])*Eij;
        ftj_buf+=-(dGdtpot[ii])*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        // fr_buf+=(qi*dGholedpot[jj]+qj*dGholedpot[ii])*Frij;
        fr_buf+=(qi*dGdepot[jj]+qj*dGdepot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        // fr_buf+=(ei*dGmixdpot[jj]+ej*dGmixdpot[ii]+
        //          ti*dGholedpot[jj]+tj*dGholedpot[ii]+
        //          ei*dGpotdpot[jj]+ej*dGpotdpot[ii])*Frij;
        // fti_buf+=-dGholedpot[jj]*Eij;
        // ftj_buf+=-dGholedpot[ii]*Eij;
        // fei_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // fej_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ei*dGdtpot[jj]+ej*dGdtpot[ii]+ti*dGdepot[jj]+tj*dGdepot[ii])*Frij;
        fti_buf+=-dGdepot[jj]*Eij;
        ftj_buf+=-dGdepot[ii]*Eij;
        fei_buf+=-dGdtpot[jj]*Eij;
        fej_buf+=-dGdtpot[ii]*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        // fr_buf+=(ei*dGholedpot[jj]+ej*dGholedpot[ii])*Frij;
        // fei_buf+=-dGholedpot[jj]*Eij;
        // fej_buf+=-dGholedpot[ii]*Eij;
        fr_buf+=(ei*dGdepot[jj]+ej*dGdepot[ii])*Frij;
        fei_buf+=-dGdepot[jj]*Eij;
        fej_buf+=-dGdepot[ii]*Eij;

        // if (bP[ii] && bP[jj]) { // TRY
          // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
          // Frij=Pij/(gauss_01*gauss_01);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G1];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G1];
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // fr_buf+=(dGmixdt_tk[jj]*theta[ii]+dGmixdt_tk[ii]*theta[jj]+dGmixdt_tcl[jj]*theta_cl[ii]+dGmixdt_tcl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGholede_ek[jj]*theta[ii]+dGholede_ek[ii]*theta[jj]+dGholede_ecl[jj]*theta_cl[ii]+dGholede_ecl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGsoftdt_tk[jj]*theta[ii]+dGsoftdt_tcl[jj]*theta_cl[ii]+dGsoftdt_tk[ii]*theta[jj]+dGsoftdt_tcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGmixdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGmixdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGmixdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGmixdt_tcl[ii]*Pij;
          // ft_k[ii] +=-dGholede_ek[jj]*Pij;
          // ft_k[jj] +=-dGholede_ek[ii]*Pij;
          // ft_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // ft_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // ft_k[ii] +=-dGsoftdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGsoftdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGsoftdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGsoftdt_tcl[ii]*Pij;
          // fr_buf+=(dGmixdV1[jj]+dGmixdV1[ii])*Frij;
          // fr_buf+=(dGsoftdV1[jj]+dGsoftdV1[ii])*Frij;
          // fr_buf+=(dGpotdV1[jj]+dGpotdV1[ii])*Frij;
          fr_buf+=(dGdtk[jj]*theta[ii]+dGdtk[ii]*theta[jj]+dGdtcl[jj]*theta_cl[ii]+dGdtcl[ii]*theta_cl[jj])*Frij;
          ft_k[ii] +=-dGdtk[jj]*Pij;
          ft_k[jj] +=-dGdtk[ii]*Pij;
          ft_cl[ii]+=-dGdtcl[jj]*Pij;
          ft_cl[jj]+=-dGdtcl[ii]*Pij;
          fr_buf+=(dGdV1[jj]+dGdV1[ii])*Frij;

          // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
          // Frij=Pij/(gauss_02*gauss_02);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G2];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G2];
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // fr_buf+=(dGholede_ek[jj]*eta[ii]+dGholede_ek[ii]*eta[jj]+dGholede_ecl[jj]*eta_cl[ii]+dGholede_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGholede_ek[jj]*Pij;
          // fe_k[jj] +=-dGholede_ek[ii]*Pij;
          // fe_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // fr_buf+=(dGsoftde_ek[jj]*eta[ii]+dGsoftde_ecl[jj]*eta_cl[ii]+dGsoftde_ek[ii]*eta[jj]+dGsoftde_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGsoftde_ek[jj]*Pij;
          // fe_k[jj] +=-dGsoftde_ek[ii]*Pij;
          // fe_cl[ii]+=-dGsoftde_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGsoftde_ecl[ii]*Pij;
          // fr_buf+=(dGmixdV2[jj]+dGmixdV2[ii])*Frij;
          // fr_buf+=(dGsoftdV2[jj]+dGsoftdV2[ii])*Frij;
          // fr_buf+=(dGpotdV2[jj]+dGpotdV2[ii])*Frij;
          fr_buf+=(dGdek[jj]*eta[ii]+dGdek[ii]*eta[jj]+dGdecl[jj]*eta_cl[ii]+dGdecl[ii]*eta_cl[jj])*Frij;
          fe_k[ii] +=-dGdek[jj]*Pij;
          fe_k[jj] +=-dGdek[ii]*Pij;
          fe_cl[ii]+=-dGdecl[jj]*Pij;
          fe_cl[jj]+=-dGdecl[ii]*Pij;
          fr_buf+=(dGdV2[jj]+dGdV2[ii])*Frij;
        // }

#ifdef POLARIZE
          Pij=data->Eij[eT_G1];
          Frij=data->Frij[eT_G1];
          fr_buf+=(dGdpk[ii] *vec_dot(polar+DIM3*jj   ,data->dr)-dGdpk[jj] *vec_dot(polar+DIM3*ii   ,data->dr))*Frij;
          fr_buf+=(dGdpcl[ii]*vec_dot(polar_cl+DIM3*jj,data->dr)-dGdpcl[jj]*vec_dot(polar_cl+DIM3*ii,data->dr))*Frij;
          vec_scaleinc(fx+DIM3*iii,-dGdpk[ii] *Pij*(kTr0/kT0),polar+DIM3*jj); // Convert units
          vec_scaleinc(fx+DIM3*jjj, dGdpk[ii] *Pij*(kTr0/kT0),polar+DIM3*jj); // Convert units
          vec_scaleinc(fx+DIM3*iii, dGdpk[jj] *Pij*(kTr0/kT0),polar+DIM3*ii); // Convert units
          vec_scaleinc(fx+DIM3*jjj,-dGdpk[jj] *Pij*(kTr0/kT0),polar+DIM3*ii); // Convert units
          vec_scaleinc(fx+DIM3*iii,-dGdpcl[ii]*Pij*(kTr0/kT0),polar_cl+DIM3*jj); // Convert units
          vec_scaleinc(fx+DIM3*jjj, dGdpcl[ii]*Pij*(kTr0/kT0),polar_cl+DIM3*jj); // Convert units
          vec_scaleinc(fx+DIM3*iii, dGdpcl[jj]*Pij*(kTr0/kT0),polar_cl+DIM3*ii); // Convert units
          vec_scaleinc(fx+DIM3*jjj,-dGdpcl[jj]*Pij*(kTr0/kT0),polar_cl+DIM3*ii); // Convert units
          vec_scaleinc(fp_k+DIM3*ii,  dGdpk[jj] *Pij,data->dr);
          vec_scaleinc(fp_k+DIM3*jj, -dGdpk[ii] *Pij,data->dr);
          vec_scaleinc(fp_cl+DIM3*ii, dGdpcl[jj]*Pij,data->dr);
          vec_scaleinc(fp_cl+DIM3*jj,-dGdpcl[ii]*Pij,data->dr);
          // condens_pk[ii]+= vec_dot(polar+DIM3*jj,data->dr)*Pij;
          // condens_pk[jj]+=-vec_dot(polar+DIM3*ii,data->dr)*Pij;
          // condens_pcl[ii]+= vec_dot(polar_cl+DIM3*jj,data->dr)*Pij;
          // condens_pcl[jj]+=-vec_dot(polar_cl+DIM3*ii,data->dr)*Pij;
#endif

#ifdef POLARIZE
        // Mix - Polarize
        Eij=(s1*s1)*data->Eij[eT_gDH11];
        Frij=(s1*s1)*data->Frij[eT_gDH11];
        fr_buf+=(dGdtpot[ii]*vec_dot(data->dr,pj)-dGdtpot[jj]*vec_dot(data->dr,pi))*Frij;
        vec_scaleinc(fx+DIM3*iii,-dGdtpot[ii]*Eij*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fx+DIM3*jjj, dGdtpot[ii]*Eij*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fx+DIM3*iii, dGdtpot[jj]*Eij*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-dGdtpot[jj]*Eij*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fp_k+DIM3*ii,  dGdtpot[jj]*Eij,data->dr);
        vec_scaleinc(fp_k+DIM3*jj, -dGdtpot[ii]*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*ii,-dGdtpot[jj]*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*jj, dGdtpot[ii]*Eij,data->dr);
        // pot_t[ii]+= vec_dot(data->dr,pj)*Eij;
        // pot_t[jj]+=-vec_dot(data->dr,pi)*Eij;

        // Hole - Polarize
        Eij=(s1*s1)*data->Eij[eT_gDH12];
        Frij=(s1*s1)*data->Frij[eT_gDH12];
        fr_buf+=(dGdepot[ii]*vec_dot(data->dr,pj)-dGdepot[jj]*vec_dot(data->dr,pi))*Frij;
        vec_scaleinc(fx+DIM3*iii,-dGdepot[ii]*Eij*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fx+DIM3*jjj, dGdepot[ii]*Eij*(kTr0/kT0),pj); // Convert units
        vec_scaleinc(fx+DIM3*iii, dGdepot[jj]*Eij*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-dGdepot[jj]*Eij*(kTr0/kT0),pi); // Convert units
        vec_scaleinc(fp_k+DIM3*ii,  dGdepot[jj]*Eij,data->dr);
        vec_scaleinc(fp_k+DIM3*jj, -dGdepot[ii]*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*ii,-dGdepot[jj]*Eij,data->dr);
        vec_scaleinc(fp_cl+DIM3*jj, dGdepot[ii]*Eij,data->dr);
        // pot_e[ii]+= vec_dot(data->dr,pj)*Eij;
        // pot_e[jj]+=-vec_dot(data->dr,pi)*Eij;
#endif

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
// #ifdef POLARIZE
//         vec_scaleinc(fx+DIM3*iii, fpi_buf*(kTr0/kT0),pi); // Convert units
//         vec_scaleinc(fx+DIM3*iii, fpj_buf*(kTr0/kT0),pj); // Convert units
//         vec_scaleinc(fx+DIM3*jjj,-fpi_buf*(kTr0/kT0),pi); // Convert units
//         vec_scaleinc(fx+DIM3*jjj,-fpj_buf*(kTr0/kT0),pj); // Convert units
//         vec_scaleinc(fp_k+DIM3*ii,  fpi_buf,data->dr);
//         vec_scaleinc(fp_cl+DIM3*ii,-fpi_buf,data->dr);
//         vec_scaleinc(fp_k+DIM3*jj,  fpj_buf,data->dr);
//         vec_scaleinc(fp_cl+DIM3*jj,-fpj_buf,data->dr);
// #endif

        ft_k[jj] += ftj_buf;
        ft_cl[jj]+=-ftj_buf;
        fe_k[jj] += fej_buf;
        fe_cl[jj]+=-fej_buf;
      // }
    }
    ft_k[ii] += fti_buf;
    ft_cl[ii]+=-fti_buf;
    fe_k[ii] += fei_buf;
    fe_cl[ii]+=-fei_buf;
  }

  md->state->Gt->local[ID][0]+=Gt*(kTr0/kT0); // Convert units
  md->state->Gts->local[ID][eE_elec]+=Gt*(kTr0/kT0); // Convert units

  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);
  #pragma omp master
    md->times->force_elec+=(gmx_cycles_read()-start0);
}


void getforce_other(struct_md* md)
{
  int ID,imin,imax;
  int i,j,ii,jj;
  double r2,sor2,r6,Eij;
  double Gt=0;
  vec dr;
  double *x=md->state->x;
  double *shift=md->state->shift;
  double *box=md->state->box;
  double *f;
  double *shiftij;

  double k12=md->parms->k12;
  double rc2;
  double (*s2)[2][2]=&(md->parms->s2);
#ifdef VIRTUAL
  int *g=md->parms->groupndx;
  double r,r12,Repel,fRepel,Gauss,fGauss;
#endif

  gmx_cycles_t start,stop;

  start=gmx_cycles_read();

  ID=omp_get_thread_num();
  imin=md->state->nlother->imin_f[ID];
  imax=md->state->nlother->imax_f[ID];
  f=md->state->atoms->f->local[ID];

  rc2=md->parms->rcother*md->parms->rcother;

  for (i=imin; i<imax; i++) {
    ii=md->state->nlother->ii[i];
    for (j=0; j<md->state->nlother->jjmax[i]; j++) {
      jj=md->state->nlother->jj[i][j];
      shiftij=md->state->nlother->shiftij[i][j];
      vec_subshift(x+DIM3*ii,x+DIM3*jj,shift+DIM3*ii,shift+DIM3*jj,shiftij,dr);
      // vec_subquick(x+DIM3*ii,x+DIM3*jj,box,dr);
      r2=vec_mag2(dr);
      if (r2<=rc2) {
      // KLUDGE
#ifdef VIRTUAL
      if (((g[ii]==2) || (g[ii]==3)) && ((g[jj]==2) || (g[jj]==3))) {
#define E_BSTACK 0.05
#define S_BSTACK 0.06
#define S2_BSTACK (S_BSTACK*S_BSTACK)
#define E12_BSTACK 5.96046448e-8
#define R0_BSTACK 0.32
      r=sqrt(r2);
      r6=r2*r2*r2;
      r12=r6*r6;
      Repel=E12_BSTACK/r12;
      fRepel=12.0*Repel/r2;
      Gauss=exp(-0.5*((r-R0_BSTACK)*(r-R0_BSTACK))/S2_BSTACK);
      fGauss=((r-R0_BSTACK)/r)*Gauss/S2_BSTACK;
      Gt+=Repel-E_BSTACK*Gauss-Repel*Gauss;
      vec_scaleinc(f+DIM3*ii, (fRepel*(1-Gauss)-(E_BSTACK+Repel)*fGauss),dr);
      vec_scaleinc(f+DIM3*jj,-(fRepel*(1-Gauss)-(E_BSTACK+Repel)*fGauss),dr);
      } else if (!((g[ii]==1) || (g[jj]==1))) {
#endif
      sor2=(*s2)[ii < md->state->N_rna ? 0 : 1][jj < md->state->N_rna ? 0 : 1]/r2; // CONST
      r6=sor2*sor2*sor2;
      Eij=k12*r6*r6;
      Gt+=Eij;
      // assert(Eij>-1e6);
      vec_scaleinc(f+DIM3*ii, 12*Eij/r2,dr);
      vec_scaleinc(f+DIM3*jj,-12*Eij/r2,dr);
#ifdef VIRTUAL
      } else if (((g[ii]==1) && (g[jj]==2)) || ((g[ii]==2) && (g[jj]==1))) {
#define E_HBOND 3
#define S_HBOND 0.02
#define S2_HBOND (S_HBOND*S_HBOND)
      Eij=-E_HBOND*exp(-r2/(2.0*S2_HBOND));
      Gt+=Eij;
      vec_scaleinc(f+DIM3*ii, Eij/S2_HBOND,dr);
      vec_scaleinc(f+DIM3*jj,-Eij/S2_HBOND,dr);
      }
#endif
      }
    }
  }

  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_lj]+=Gt;
  
  stop=gmx_cycles_read();
  md->state->nlother->cycles_force[ID]+=(stop-start);
  #pragma omp master
    md->times->force_other+=(gmx_cycles_read()-start);
}


void getforce_elec_v4_mohanty_v32(struct_md* md)
{
  int ID,imin,imax;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,cij;
  double Gt=0;
  double dt_min,dt_max;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=md->state->qqlist->theta;
  double *bP=md->state->qqlist->bP;
  double *ft,*fx; // Forces
  double *Gij,*Gij_rna;
  int nqlist;
  int *qlist;
  double lB,kappa,conc_K,f_KCl,b,V,kT,rc;
  double k_prohibit=md->parms->k_prohibit;

  gmx_cycles_t start,stop;

  ID=omp_get_thread_num();
  // imin=md->state->nlelec[ID]->imin;
  // imax=md->state->nlelec[ID]->imax;
  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;
  // ft=md->state->manningcc->f;
  // fx=md->state->f;
  // ft=md->state->forces[ID]->ft;
  // fx=md->state->forces[ID]->fx;
  fx=md->state->atoms->f->local[ID];
  ft=md->state->manningcc_tk->f->local[ID];
  // MIN
  // Gij=md->state->forces[ID]->Gij;
  // Gij_rna=md->state->forces[ID]->Gij_rna;

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_K=md->parms->conc_K;
  kT=md->parms->kT;
  rc=md->parms->rcelec;

  // No longer defined in alloc_parms
  // V=md->parms->V;
  f_KCl=2; // dimensionless factor entering into Debye length. 2 for KCl, 6 for MgCl2, sum(z^2*n) where z is the charge and n is the stochiometric ratio
  b=0.167; // in nm
  V=4*M_PI*exp(1)*f_KCl*(md->parms->lB-b)*b*b; // in nm^3

  start=gmx_cycles_read();

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    if (bP[ii]) {
      // These derivatives are singular at zero, and undefined for x<0, I made a function that puts in a very strong harmonic correct near 0 for numerical stability. Uncomment these lines to switch it back
      // Gt+=kT*theta[ii]*log(theta[ii]/(conc_KCl*V));
      // ft[ii]+=-kT*(log(theta[ii]/(conc_KCl*V))+1);
      // Note also these two definitions of the potential are slightly different, they differ by a factor of exp(1) that has been shuffled into V.
      Gt+=kT*(conc_K*V)*xlnxmx_soft(theta[ii]/(conc_K*V),1.0/k_prohibit);
      ft[ii]+=-kT*lnx_soft(theta[ii]/(conc_K*V),1.0/k_prohibit);
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(dr);
      if (r<=rc) {
      Eij=kT*q[iii]*q[jjj]*lB/r*exp(-kappa*r); // including exp seems to go from 1.2 ms to 1.4 ms
      cij=(1-theta[ii])*(1-theta[jj])+0.5*bP[ii]*bP[jj]*(theta[ii]-theta[jj])*(theta[ii]-theta[jj]);
      Gt+=cij*Eij;
      vec_scaleinc(fx+DIM3*iii, cij*Eij*(kappa+1/r)/r,dr);
      vec_scaleinc(fx+DIM3*jjj,-cij*Eij*(kappa+1/r)/r,dr);
      ft[ii]+=(1-bP[jj]*theta[ii])*Eij;
      ft[jj]+=(1-bP[ii]*theta[jj])*Eij;
      // Gij[ii]+=Eij;
      // Gij[jj]+=Eij;
      // Gij_rna[ii]+=bP[jj]*Eij;
      // Gij_rna[jj]+=bP[ii]*Eij;
      }
    }
  }
// #pragma omp critical
//   md->state->qqlist->Gt+=Gt;
// #pragma omp critical
  md->state->Gt->local[ID][0]+=Gt;
  md->state->Gts->local[ID][eE_elec]+=Gt;

  stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);
  md->state->nlelec->cycles_force[ID]+=(stop-start);
  #pragma omp master
    md->times->force_elec+=(gmx_cycles_read()-start);
  // fprintf(stderr,"No neighbor list Gt_elec %d cycles\n",(int) (stop-start));
  // fprintf(stderr,"No neighbor list Gt_elec=%g\n",md->state->qqlist->Gt);
}

