#ifndef MD_RNA_IONS_UNSPECIFIC_H
#define MD_RNA_IONS_UNSPECIFIC_H

#include "md.h"

void getforce_elec(struct_md* md);

void getforce_elec_v2(struct_md* md);

void getforce_elec_v3(struct_md* md);

void getforce_other(struct_md* md);

void getforce_elec_v4_mohanty_v32(struct_md* md);

#endif

