#ifndef MD_RNA_IONS_UMBRELLA_H
#define MD_RNA_IONS_UMBRELLA_H

#include "md.h" 
#include "collate.h"

typedef struct struct_umbrella
{
double Q_ref ;
double k_umb ;
double kappa ;
double Q_start ;

int Q_nc ;
double Q_steps ;

int *first ;
int *second ;
double *r_native ;
double *factor ;

struct_collate *Q_act ;
} struct_umbrella ;

struct_umbrella* alloc_umbrella() ;
void free_umbrella(struct_umbrella* umbrella) ;

void start_umbrella( struct_md* const md ) ;
void calc_umbrella( struct_md* const md ) ;
void apply_umbrella( struct_md* const md ) ;
void getforce_umbrella(struct_md* md);

#endif
