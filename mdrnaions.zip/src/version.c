// Private version V42.4 = Public version 1.0
// Private version V42.16 = Public version 1.1

#include <stdio.h> 

#include "version.h"

void printversion(FILE *fp)
{
  fprintf(fp,"%s","Public version 1.1+\n"
    "Private version 43.7\n"
    "Modified from private version 43.6 on 2016-04-13 18:34\n");
}
